-- 0002 RLS policies + reference data (no prices, costs or stock are invented)

alter table public.profiles enable row level security;
alter table public.audit_logs enable row level security;
alter table public.company_settings enable row level security;
alter table public.brands enable row level security;
alter table public.product_categories enable row level security;
alter table public.units enable row level security;
alter table public.payment_terms enable row level security;
alter table public.payment_methods enable row level security;
alter table public.products enable row level security;
alter table public.inventory_lots enable row level security;
alter table public.customers enable row level security;
alter table public.visits enable row level security;
alter table public.order_templates enable row level security;
alter table public.order_template_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_status_history enable row level security;
alter table public.order_transitions enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.invoices enable row level security;
alter table public.receivables enable row level security;
alter table public.receivable_installments enable row level security;
alter table public.payments enable row level security;
alter table public.deliveries enable row level security;
alter table public.delivery_items enable row level security;
alter table public.delivery_status_history enable row level security;

create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_role(array['admin','gerente','comercial','estoque','faturamento']::public.app_role[]));

create policy audit_select on public.audit_logs for select to authenticated
  using (public.has_role(array['admin']::public.app_role[]));

create policy settings_select on public.company_settings for select to authenticated using (public.my_role() is not null);
create policy settings_update on public.company_settings for update to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create policy brands_select on public.brands for select to authenticated using (public.my_role() is not null);

create policy categories_select on public.product_categories for select to authenticated using (public.my_role() is not null);
create policy categories_write on public.product_categories for all to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create policy units_select on public.units for select to authenticated using (public.my_role() is not null);
create policy units_write on public.units for all to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create policy terms_select on public.payment_terms for select to authenticated using (public.my_role() is not null);
create policy terms_write on public.payment_terms for all to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create policy methods_select on public.payment_methods for select to authenticated using (public.my_role() is not null);
create policy methods_write on public.payment_methods for all to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create policy products_select on public.products for select to authenticated
  using (public.has_role(array['admin','gerente','comercial','estoque','faturamento']::public.app_role[]));
create policy products_insert on public.products for insert to authenticated
  with check (public.has_role(array['admin']::public.app_role[]) and stock_physical = 0 and stock_reserved = 0);
create policy products_update on public.products for update to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create or replace function public.protect_stock_columns()
returns trigger language plpgsql set search_path = '' as $$
begin
  if current_setting('app.stock_rpc', true) is distinct from 'on'
     and (new.stock_physical <> old.stock_physical or new.stock_reserved <> old.stock_reserved) then
    raise exception 'Estoque só pode ser alterado por movimentações registradas.';
  end if;
  return new;
end;
$$;
create trigger products_protect_stock before update on public.products for each row execute function public.protect_stock_columns();

create policy lots_select on public.inventory_lots for select to authenticated
  using (public.has_role(array['admin','gerente','estoque']::public.app_role[]));

create policy customers_select on public.customers for select to authenticated
  using (
    public.has_role(array['admin','gerente','faturamento','estoque']::public.app_role[])
    or (public.has_role(array['comercial']::public.app_role[]) and (sales_rep_id = auth.uid() or sales_rep_id is null))
  );
create policy customers_insert on public.customers for insert to authenticated
  with check (
    public.has_role(array['admin','gerente']::public.app_role[])
    or (public.has_role(array['comercial']::public.app_role[]) and sales_rep_id = auth.uid())
  );
create policy customers_update on public.customers for update to authenticated
  using (
    public.has_role(array['admin','gerente']::public.app_role[])
    or (public.has_role(array['comercial']::public.app_role[]) and (sales_rep_id = auth.uid() or sales_rep_id is null))
  )
  with check (
    public.has_role(array['admin','gerente']::public.app_role[])
    or (public.has_role(array['comercial']::public.app_role[]) and sales_rep_id = auth.uid())
  );

create policy visits_select on public.visits for select to authenticated
  using (public.has_role(array['admin','gerente']::public.app_role[]) or rep_id = auth.uid());
create policy visits_insert on public.visits for insert to authenticated
  with check (rep_id = auth.uid() and public.has_role(array['admin','gerente','comercial']::public.app_role[]));

create policy templates_select on public.order_templates for select to authenticated
  using (public.has_role(array['admin','gerente','comercial']::public.app_role[]));
create policy templates_write on public.order_templates for all to authenticated
  using (public.has_role(array['admin','gerente']::public.app_role[])) with check (public.has_role(array['admin','gerente']::public.app_role[]));
create policy template_items_select on public.order_template_items for select to authenticated
  using (public.has_role(array['admin','gerente','comercial']::public.app_role[]));
create policy template_items_write on public.order_template_items for all to authenticated
  using (public.has_role(array['admin','gerente']::public.app_role[])) with check (public.has_role(array['admin','gerente']::public.app_role[]));

create or replace function public.can_view_order(p_order_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.orders o
    where o.id = p_order_id and (
      public.has_role(array['admin','gerente','estoque','faturamento']::public.app_role[])
      or (public.has_role(array['comercial']::public.app_role[]) and (o.rep_id = auth.uid() or o.created_by = auth.uid()))
    )
  )
$$;

create policy orders_select on public.orders for select to authenticated using (public.can_view_order(id));
create policy order_items_select on public.order_items for select to authenticated using (public.can_view_order(order_id));
create policy order_history_select on public.order_status_history for select to authenticated using (public.can_view_order(order_id));
create policy transitions_select on public.order_transitions for select to authenticated using (public.my_role() is not null);
create policy transitions_write on public.order_transitions for all to authenticated
  using (public.has_role(array['admin']::public.app_role[])) with check (public.has_role(array['admin']::public.app_role[]));

create policy movements_select on public.inventory_movements for select to authenticated
  using (public.has_role(array['admin','gerente','estoque']::public.app_role[]));

create policy invoices_select on public.invoices for select to authenticated
  using (public.has_role(array['admin','gerente','faturamento']::public.app_role[]) or public.can_view_order(order_id));
create policy receivables_select on public.receivables for select to authenticated
  using (public.has_role(array['admin','gerente','faturamento']::public.app_role[]));
create policy installments_select on public.receivable_installments for select to authenticated
  using (public.has_role(array['admin','gerente','faturamento']::public.app_role[]));
create policy payments_select on public.payments for select to authenticated
  using (public.has_role(array['admin','gerente','faturamento']::public.app_role[]));

create policy deliveries_select on public.deliveries for select to authenticated
  using (
    public.has_role(array['admin','gerente','estoque','faturamento']::public.app_role[])
    or (public.has_role(array['entregador']::public.app_role[]) and driver_id = auth.uid())
    or (public.has_role(array['comercial']::public.app_role[]) and public.can_view_order(order_id))
  );
create policy delivery_items_select on public.delivery_items for select to authenticated
  using (exists (select 1 from public.deliveries d where d.id = delivery_id));
create policy delivery_history_select on public.delivery_status_history for select to authenticated
  using (exists (select 1 from public.deliveries d where d.id = delivery_id));

-- ============ REFERENCE DATA ============
insert into public.company_settings (id, company_name, phone, email, website_pimentera, website_mixx, instagram_pimentera, instagram_mixx)
values (1, 'Pimentera Foods + Mixx Condimentos', '(62) 99414-5714', 'mixxcondimentos@gmail.com',
        'pimentera.com.br', 'mixxcondimentos.com.br', '@pimenterafoods', '@mixxcondimentos');

insert into public.brands (id, code, name) values (1, 'pimentera', 'Pimentera'), (2, 'mixx', 'Mixx Condimentos');

insert into public.units (code, description) values ('UN','Unidade'), ('CX','Caixa'), ('FD','Fardo'), ('DP','Display'), ('KG','Quilograma');

insert into public.product_categories (name) values ('Molhos de pimenta'), ('Condimentos');

insert into public.payment_terms (name, days) values
  ('À vista', '{0}'), ('7 dias', '{7}'), ('14 dias', '{14}'), ('21 dias', '{21}'), ('28 dias', '{28}'),
  ('30 dias', '{30}'), ('30/60 dias', '{30,60}'), ('30/60/90 dias', '{30,60,90}');

insert into public.payment_methods (name) values ('PIX'), ('Boleto'), ('Dinheiro'), ('Transferência'), ('Cartão de crédito'), ('Cartão de débito');

insert into public.products (sku, name, brand_id, category_id, net_content, unit)
select v.sku, v.name, v.brand, c.id, v.content, 'UN'
from (values
  ('PIM-001','Molho de Pimenta Tradicional',1,'Molhos de pimenta','150 ml'),
  ('PIM-002','Molho Agridoce de Pimenta com Manga',1,'Molhos de pimenta','220 ml'),
  ('PIM-003','Molho Extra Picante',1,'Molhos de pimenta','220 ml'),
  ('MIX-001','Açafrão',2,'Condimentos','60 g'),
  ('MIX-002','Alecrim',2,'Condimentos','25 g'),
  ('MIX-003','Alho Frito',2,'Condimentos','60 g'),
  ('MIX-004','Canela',2,'Condimentos','80 g'),
  ('MIX-005','Chimichurri',2,'Condimentos','60 g'),
  ('MIX-006','Colorau',2,'Condimentos','80 g'),
  ('MIX-007','Cominho',2,'Condimentos','60 g'),
  ('MIX-008','Curry',2,'Condimentos','60 g'),
  ('MIX-009','Ervas Finas',2,'Condimentos','60 g'),
  ('MIX-010','Lemon Pepper',2,'Condimentos','80 g'),
  ('MIX-011','Manjericão',2,'Condimentos','30 g'),
  ('MIX-012','Orégano',2,'Condimentos','60 g'),
  ('MIX-013','Páprica Picante',2,'Condimentos','70 g'),
  ('MIX-014','Páprica Doce',2,'Condimentos','70 g'),
  ('MIX-015','Pimenta Calabresa',2,'Condimentos','40 g'),
  ('MIX-016','Pimenta-do-Reino',2,'Condimentos','60 g'),
  ('MIX-017','Sal de Parrilla',2,'Condimentos','140 g'),
  ('MIX-018','Sal Rosa do Himalaia',2,'Condimentos','140 g'),
  ('MIX-019','Tempero Baiano',2,'Condimentos','60 g'),
  ('MIX-020','Vinagrete',2,'Condimentos','60 g')
) as v(sku, name, brand, cat, content)
join public.product_categories c on c.name = v.cat;

insert into public.order_templates (name, description)
values ('Primeiro Pedido — 200 unidades', 'Modelo padrão de prospecção: 40 molhos Pimentera + 160 condimentos Mixx.');

insert into public.order_template_items (template_id, product_id, quantity)
select t.id, p.id,
  case p.sku when 'PIM-001' then 14 when 'PIM-002' then 13 when 'PIM-003' then 13 else 8 end
from public.order_templates t cross join public.products p
where t.name = 'Primeiro Pedido — 200 unidades';

insert into public.order_transitions (from_status, to_status, allowed_roles) values
  ('rascunho','aguardando_aprovacao','{admin,gerente,comercial}'),
  ('rascunho','cancelado','{admin,gerente,comercial}'),
  ('aguardando_aprovacao','aprovado','{admin,gerente}'),
  ('aguardando_aprovacao','rascunho','{admin,gerente}'),
  ('aguardando_aprovacao','cancelado','{admin,gerente}'),
  ('aguardando_estoque','aprovado','{admin,gerente,estoque}'),
  ('aguardando_estoque','cancelado','{admin,gerente}'),
  ('aprovado','em_separacao','{admin,estoque}'),
  ('aprovado','cancelado','{admin,gerente}'),
  ('em_separacao','separado','{admin,estoque}'),
  ('em_separacao','cancelado','{admin,gerente}'),
  ('separado','aguardando_faturamento','{admin,estoque}'),
  ('separado','cancelado','{admin,gerente}'),
  ('aguardando_faturamento','cancelado','{admin,gerente}');

insert into storage.buckets (id, name, public) values ('arquivos', 'arquivos', false) on conflict (id) do nothing;
