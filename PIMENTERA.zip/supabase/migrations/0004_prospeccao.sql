-- Prospecção: leads (supermercados), geocodificação, check-in, visitas e rotas.
-- Perfis: admin/gerente = gestor (tudo); comercial = vendedor (leads atribuídos a ele ou sem responsável).

create type public.prospect_geo_status as enum ('pendente','aproximado','ok','confirmado_vendedor','falha');
create type public.prospect_geo_fonte as enum ('cep','google','vendedor');
create type public.prospect_funil as enum ('novo','visitado','interessado','negociando','cliente','sem_interesse','retornar');
create type public.prospect_resultado as enum ('fechado_nao_atendeu','falou_comprador','interessado','pediu_proposta','pedido_fechado','sem_interesse','retornar');
create type public.rota_status as enum ('planejada','em_andamento','concluida');
create type public.rota_parada_status as enum ('pendente','visitada','pulada');

create table public.prospects (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (length(trim(nome)) > 0),
  nome_norm text generated always as (lower(trim(nome))) stored,
  cnpj text check (cnpj is null or cnpj ~ '^\d{14}$'),
  endereco text,
  numero text,
  bairro text,
  cidade text,
  uf text check (uf is null or uf ~ '^[A-Z]{2}$'),
  cep text not null check (cep ~ '^\d{8}$'),
  telefone text,
  lat double precision check (lat is null or lat between -90 and 90),
  lng double precision check (lng is null or lng between -180 and 180),
  geo_status public.prospect_geo_status not null default 'pendente',
  geo_fonte public.prospect_geo_fonte,
  geo_tentativas int not null default 0,
  geo_lock_at timestamptz,
  geo_erro text,
  status_funil public.prospect_funil not null default 'novo',
  vendedor_id uuid references public.profiles(id) on delete set null,
  ultima_visita_em timestamptz,
  importado_por uuid references public.profiles(id) on delete set null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create unique index prospects_cnpj_uniq on public.prospects (cnpj) where cnpj is not null;
create unique index prospects_nome_cep_uniq on public.prospects (nome_norm, cep);
create index prospects_cep_idx on public.prospects (cep);
create index prospects_funil_idx on public.prospects (status_funil);
create index prospects_latlng_idx on public.prospects (lat, lng);
create index prospects_cidade_idx on public.prospects (cidade);
create index prospects_uf_idx on public.prospects (uf);
create index prospects_geo_idx on public.prospects (geo_status);
create index prospects_vendedor_idx on public.prospects (vendedor_id);

create or replace function public.touch_atualizado_em() returns trigger language plpgsql set search_path = '' as $$
begin new.atualizado_em := now(); return new; end $$;
create trigger prospects_touch before update on public.prospects for each row execute function public.touch_atualizado_em();

create table public.prospect_localizacoes_hist (
  id uuid primary key default gen_random_uuid(),
  prospect_id uuid not null references public.prospects(id) on delete cascade,
  lat_antiga double precision,
  lng_antiga double precision,
  lat_nova double precision not null,
  lng_nova double precision not null,
  vendedor_id uuid references public.profiles(id) on delete set null,
  data timestamptz not null default now()
);
create index prospect_loc_hist_idx on public.prospect_localizacoes_hist (prospect_id, data desc);

create table public.visitas_prospeccao (
  id uuid primary key default gen_random_uuid(),  -- gerado no aparelho: idempotência no envio offline
  prospect_id uuid not null references public.prospects(id) on delete cascade,
  vendedor_id uuid not null references public.profiles(id),
  data_hora timestamptz not null default now(),
  checkin_lat double precision,
  checkin_lng double precision,
  checkin_precisao_m numeric(10,1),
  distancia_do_cadastro_m numeric(12,1),
  resultado public.prospect_resultado not null,
  observacoes text,
  contato_nome text,
  contato_telefone text,
  proxima_acao text,
  data_retorno date,
  foto_url text,
  rota_id uuid,
  recebido_em timestamptz not null default now()
);
create index visitas_prosp_lead_idx on public.visitas_prospeccao (prospect_id, data_hora desc);
create index visitas_prosp_vend_idx on public.visitas_prospeccao (vendedor_id, data_hora desc);

create table public.rotas (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  vendedor_id uuid not null references public.profiles(id),
  criada_por uuid not null references public.profiles(id),
  centro_lat double precision not null,
  centro_lng double precision not null,
  lado_km numeric(6,2) not null check (lado_km between 1 and 50),
  origem_lat double precision,
  origem_lng double precision,
  distancia_total_km numeric(10,2),
  duracao_total_min numeric(10,1),
  polyline text,
  data_prevista date,
  status public.rota_status not null default 'planejada',
  criada_em timestamptz not null default now()
);
create index rotas_vendedor_idx on public.rotas (vendedor_id, criada_em desc);

create table public.rota_paradas (
  id uuid primary key default gen_random_uuid(),
  rota_id uuid not null references public.rotas(id) on delete cascade,
  prospect_id uuid not null references public.prospects(id) on delete cascade,
  ordem int not null,
  status public.rota_parada_status not null default 'pendente',
  visitada_em timestamptz,
  unique (rota_id, prospect_id),
  unique (rota_id, ordem) deferrable initially deferred
);
create index rota_paradas_prospect_idx on public.rota_paradas (prospect_id);

alter table public.visitas_prospeccao
  add constraint visitas_prosp_rota_fk foreign key (rota_id) references public.rotas(id) on delete set null;

-- Cache de geocodificação (mesma consulta nunca é cobrada duas vezes) e contador de requisições pagas.
create table public.geocode_cache (
  query_key text primary key,
  lat double precision,
  lng double precision,
  precisa boolean not null default false,
  location_type text,
  formatted_address text,
  sucesso boolean not null,
  criado_em timestamptz not null default now()
);
create table public.google_api_uso (
  api text primary key,
  requisicoes bigint not null default 0,
  atualizado_em timestamptz not null default now()
);
insert into public.google_api_uso (api) values ('geocoding'), ('routes') on conflict do nothing;

-- ============ RLS ============
alter table public.prospects enable row level security;
alter table public.prospect_localizacoes_hist enable row level security;
alter table public.visitas_prospeccao enable row level security;
alter table public.rotas enable row level security;
alter table public.rota_paradas enable row level security;
alter table public.geocode_cache enable row level security;
alter table public.google_api_uso enable row level security;

create or replace function public.prospect_visivel(p_vendedor uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select public.has_role(array['admin','gerente']::public.app_role[])
      or (public.has_role(array['comercial']::public.app_role[]) and (p_vendedor is null or p_vendedor = auth.uid()))
$$;

create policy prospects_select on public.prospects for select using (public.prospect_visivel(vendedor_id));
create policy prospects_admin_write on public.prospects for all
  using (public.has_role(array['admin','gerente']::public.app_role[]))
  with check (public.has_role(array['admin','gerente']::public.app_role[]));

create policy loc_hist_select on public.prospect_localizacoes_hist for select
  using (exists (select 1 from public.prospects p where p.id = prospect_id));

create policy visitas_prosp_select on public.visitas_prospeccao for select
  using (public.has_role(array['admin','gerente']::public.app_role[]) or vendedor_id = auth.uid());

create policy rotas_select on public.rotas for select
  using (public.has_role(array['admin','gerente']::public.app_role[]) or vendedor_id = auth.uid() or criada_por = auth.uid());
create policy rota_paradas_select on public.rota_paradas for select
  using (exists (select 1 from public.rotas r where r.id = rota_id));

create policy api_uso_select on public.google_api_uso for select
  using (public.has_role(array['admin','gerente']::public.app_role[]));
-- geocode_cache: sem políticas (somente service role no servidor).

-- ============ FUNÇÕES ============

-- Importação em lote: insere ignorando duplicadas (CNPJ ou nome+CEP). Retorna índices duplicados.
create or replace function public.prospects_importar(p_rows jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  r jsonb; i int := 0; v_inserted int := 0; v_dups jsonb := '[]'::jsonb;
  v_cnpj text; v_nome text; v_cep text;
begin
  if not public.has_role(array['admin','gerente']::public.app_role[]) then
    raise exception 'Sem permissão para importar leads.';
  end if;
  if jsonb_array_length(p_rows) > 500 then raise exception 'Envie no máximo 500 linhas por lote.'; end if;
  for r in select * from jsonb_array_elements(p_rows) loop
    v_cnpj := nullif(r->>'cnpj','');
    v_nome := trim(r->>'nome');
    v_cep := r->>'cep';
    if exists (select 1 from public.prospects p
               where (v_cnpj is not null and p.cnpj = v_cnpj)
                  or (p.nome_norm = lower(v_nome) and p.cep = v_cep)) then
      v_dups := v_dups || to_jsonb(i);
    else
      begin
        insert into public.prospects (nome, cnpj, endereco, numero, bairro, cidade, uf, cep, telefone, importado_por)
        values (v_nome, v_cnpj, nullif(r->>'endereco',''), nullif(r->>'numero',''), nullif(r->>'bairro',''),
                nullif(r->>'cidade',''), nullif(upper(r->>'uf'),''), v_cep, nullif(r->>'telefone',''), auth.uid());
        v_inserted := v_inserted + 1;
      exception when unique_violation then
        v_dups := v_dups || to_jsonb(i);
      end;
    end if;
    i := i + 1;
  end loop;
  return jsonb_build_object('inserted', v_inserted, 'duplicates', v_dups);
end $$;

-- Reserva leads para geocodificar (evita que duas abas processem o mesmo lead).
create or replace function public.prospects_reservar_geocode(p_limit int, p_incluir_falhas boolean)
returns setof public.prospects language plpgsql security definer set search_path = '' as $$
begin
  if not public.has_role(array['admin','gerente']::public.app_role[]) then
    raise exception 'Sem permissão para geocodificar.';
  end if;
  return query
  update public.prospects p set geo_lock_at = now()
  where p.id in (
    select id from public.prospects
    where (geo_status = 'pendente' or (p_incluir_falhas and geo_status = 'falha'))
      and (geo_lock_at is null or geo_lock_at < now() - interval '3 minutes')
    order by criado_em
    limit least(greatest(p_limit,1), 50)
    for update skip locked
  )
  returning p.*;
end $$;

create or replace function public.google_api_incrementar(p_api text, p_qtd int)
returns void language sql security definer set search_path = '' as $$
  update public.google_api_uso set requisicoes = requisicoes + p_qtd, atualizado_em = now() where api = p_api;
$$;
revoke execute on function public.google_api_incrementar(text, int) from public, anon, authenticated;

-- Registro de visita (idempotente pelo id gerado no aparelho), com confirmação opcional de localização
-- e avanço da rota. Tudo em uma transação.
create or replace function public.prospect_registrar_visita(p jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_lead public.prospects%rowtype;
  v_id uuid := (p->>'id')::uuid;
  v_res public.prospect_resultado := (p->>'resultado')::public.prospect_resultado;
  v_funil public.prospect_funil;
  v_rota uuid := nullif(p->>'rota_id','')::uuid;
  v_conf jsonb := p->'confirmar_localizacao';
  v_data timestamptz := coalesce(nullif(p->>'data_hora','')::timestamptz, now());
  v_next jsonb;
begin
  if not public.has_role(array['admin','gerente','comercial']::public.app_role[]) then
    raise exception 'Sem permissão para registrar visitas.';
  end if;
  if exists (select 1 from public.visitas_prospeccao where id = v_id) then
    return jsonb_build_object('duplicada', true);
  end if;
  select * into v_lead from public.prospects where id = (p->>'prospect_id')::uuid for update;
  if not found or not public.prospect_visivel(v_lead.vendedor_id) then
    raise exception 'Lead não encontrado ou sem permissão.';
  end if;
  if v_data > now() + interval '10 minutes' then v_data := now(); end if;

  if v_conf is not null and jsonb_typeof(v_conf) = 'object' then
    if (v_conf->>'lat')::float8 not between -34 and 6 or (v_conf->>'lng')::float8 not between -74 and -28 then
      raise exception 'Localização fora do Brasil.';
    end if;
    insert into public.prospect_localizacoes_hist (prospect_id, lat_antiga, lng_antiga, lat_nova, lng_nova, vendedor_id)
    values (v_lead.id, v_lead.lat, v_lead.lng, (v_conf->>'lat')::float8, (v_conf->>'lng')::float8, v_uid);
    update public.prospects set lat = (v_conf->>'lat')::float8, lng = (v_conf->>'lng')::float8,
      geo_status = 'confirmado_vendedor', geo_fonte = 'vendedor', geo_erro = null
    where id = v_lead.id;
  end if;

  if v_rota is not null and not exists (
    select 1 from public.rotas r where r.id = v_rota and (r.vendedor_id = v_uid or public.has_role(array['admin','gerente']::public.app_role[]))
  ) then v_rota := null; end if;

  insert into public.visitas_prospeccao (id, prospect_id, vendedor_id, data_hora, checkin_lat, checkin_lng, checkin_precisao_m,
    distancia_do_cadastro_m, resultado, observacoes, contato_nome, contato_telefone, proxima_acao, data_retorno, rota_id)
  values (v_id, v_lead.id, v_uid, v_data, nullif(p->>'checkin_lat','')::float8, nullif(p->>'checkin_lng','')::float8,
    nullif(p->>'checkin_precisao_m','')::numeric, nullif(p->>'distancia_do_cadastro_m','')::numeric, v_res,
    nullif(left(p->>'observacoes', 4000),''), nullif(left(p->>'contato_nome',200),''), nullif(left(p->>'contato_telefone',30),''),
    nullif(left(p->>'proxima_acao',500),''), nullif(p->>'data_retorno','')::date, v_rota);

  v_funil := case v_res
    when 'fechado_nao_atendeu' then 'retornar'
    when 'falou_comprador' then 'visitado'
    when 'interessado' then 'interessado'
    when 'pediu_proposta' then 'negociando'
    when 'pedido_fechado' then 'cliente'
    when 'sem_interesse' then 'sem_interesse'
    when 'retornar' then 'retornar' end;
  update public.prospects set status_funil = v_funil,
    ultima_visita_em = greatest(coalesce(ultima_visita_em, v_data), v_data)
  where id = v_lead.id;

  if v_rota is not null then
    update public.rota_paradas set status = 'visitada', visitada_em = v_data
      where rota_id = v_rota and prospect_id = v_lead.id and status <> 'visitada';
    update public.rotas set status = case
        when not exists (select 1 from public.rota_paradas where rota_id = v_rota and status = 'pendente') then 'concluida'
        else 'em_andamento' end
      where id = v_rota;
    select jsonb_build_object('prospect_id', rp.prospect_id, 'ordem', rp.ordem) into v_next
      from public.rota_paradas rp where rp.rota_id = v_rota and rp.status = 'pendente' order by rp.ordem limit 1;
  end if;

  return jsonb_build_object('duplicada', false, 'status_funil', v_funil, 'proxima', v_next);
end $$;

-- Salvar rota com paradas (transacional).
create or replace function public.rota_salvar(p jsonb)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_vend uuid := coalesce(nullif(p->>'vendedor_id','')::uuid, auth.uid());
  v_id uuid; v_stop jsonb; v_i int := 0;
begin
  if not public.has_role(array['admin','gerente','comercial']::public.app_role[]) then
    raise exception 'Sem permissão para criar rotas.';
  end if;
  if v_vend <> v_uid and not public.has_role(array['admin','gerente']::public.app_role[]) then
    raise exception 'Vendedores só podem criar rotas para si mesmos.';
  end if;
  if jsonb_array_length(p->'paradas') = 0 or jsonb_array_length(p->'paradas') > 25 then
    raise exception 'A rota deve ter entre 1 e 25 paradas.';
  end if;
  insert into public.rotas (nome, vendedor_id, criada_por, centro_lat, centro_lng, lado_km, origem_lat, origem_lng,
    distancia_total_km, duracao_total_min, polyline, data_prevista)
  values (left(trim(p->>'nome'),120), v_vend, v_uid, (p->>'centro_lat')::float8, (p->>'centro_lng')::float8,
    (p->>'lado_km')::numeric, nullif(p->>'origem_lat','')::float8, nullif(p->>'origem_lng','')::float8,
    nullif(p->>'distancia_total_km','')::numeric, nullif(p->>'duracao_total_min','')::numeric,
    nullif(p->>'polyline',''), nullif(p->>'data_prevista','')::date)
  returning id into v_id;
  for v_stop in select * from jsonb_array_elements(p->'paradas') loop
    v_i := v_i + 1;
    if not exists (select 1 from public.prospects pr where pr.id = (v_stop#>>'{}')::uuid and public.prospect_visivel(pr.vendedor_id)) then
      raise exception 'Lead inválido na rota.';
    end if;
    insert into public.rota_paradas (rota_id, prospect_id, ordem) values (v_id, (v_stop#>>'{}')::uuid, v_i);
  end loop;
  return v_id;
end $$;

create or replace function public.rota_pular_parada(p_rota uuid, p_prospect uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not exists (select 1 from public.rotas r where r.id = p_rota
     and (r.vendedor_id = auth.uid() or public.has_role(array['admin','gerente']::public.app_role[]))) then
    raise exception 'Rota não encontrada.';
  end if;
  update public.rota_paradas set status = 'pulada' where rota_id = p_rota and prospect_id = p_prospect and status = 'pendente';
  update public.rotas set status = case
      when not exists (select 1 from public.rota_paradas where rota_id = p_rota and status = 'pendente') then 'concluida'
      else 'em_andamento' end
    where id = p_rota;
end $$;

create or replace function public.rota_excluir(p_rota uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not exists (select 1 from public.rotas r where r.id = p_rota
     and (r.criada_por = auth.uid() or r.vendedor_id = auth.uid() or public.has_role(array['admin','gerente']::public.app_role[]))) then
    raise exception 'Rota não encontrada.';
  end if;
  delete from public.rotas where id = p_rota;
end $$;

-- Painel: números agregados (respeita a visibilidade do usuário).
create or replace function public.prospeccao_resumo()
returns jsonb language sql stable security definer set search_path = '' as $$
  with v as (select * from public.prospects p where public.prospect_visivel(p.vendedor_id))
  select jsonb_build_object(
    'total', (select count(*) from v),
    'geocodificados', (select count(*) from v where geo_status in ('ok','aproximado','confirmado_vendedor')),
    'confirmados', (select count(*) from v where geo_status = 'confirmado_vendedor'),
    'pendentes_geo', (select count(*) from v where geo_status = 'pendente'),
    'falhas_geo', (select count(*) from v where geo_status = 'falha'),
    'visitados', (select count(*) from v where ultima_visita_em is not null),
    'interessados', (select count(*) from v where status_funil in ('interessado','negociando')),
    'clientes', (select count(*) from v where status_funil = 'cliente'),
    'funil', (select coalesce(jsonb_object_agg(status_funil, n), '{}'::jsonb)
              from (select status_funil, count(*) n from v group by 1) f)
  )
$$;

grant execute on function public.prospects_importar(jsonb) to authenticated;
grant execute on function public.prospects_reservar_geocode(int, boolean) to authenticated;
grant execute on function public.prospect_registrar_visita(jsonb) to authenticated;
grant execute on function public.rota_salvar(jsonb) to authenticated;
grant execute on function public.rota_pular_parada(uuid, uuid) to authenticated;
grant execute on function public.rota_excluir(uuid) to authenticated;
grant execute on function public.prospeccao_resumo() to authenticated;
