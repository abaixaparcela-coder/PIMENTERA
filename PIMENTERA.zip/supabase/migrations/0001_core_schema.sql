-- CRM Pimentera + Mixx Condimentos — 0001 core schema
create extension if not exists pgcrypto;

-- ============ ENUMS ============
create type public.app_role as enum ('admin','comercial','estoque','faturamento','entregador','gerente');

create type public.order_status as enum (
  'rascunho','aguardando_aprovacao','aprovado','aguardando_estoque','em_separacao','separado',
  'aguardando_faturamento','faturado','pronto_expedicao','em_rota','entregue','entrega_parcial',
  'entrega_nao_realizada','cancelado'
);

create type public.delivery_status as enum (
  'aguardando_expedicao','pronta','em_rota','entregue','entrega_parcial','cliente_ausente',
  'endereco_incorreto','recusada','reagendada'
);

-- ============ PROFILES / USERS ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  phone text,
  role public.app_role not null default 'comercial',
  active boolean not null default true,
  max_discount_pct numeric(5,2) not null default 5 check (max_discount_pct between 0 and 100),
  allow_negative_stock boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.my_role()
returns public.app_role language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = auth.uid() and active
$$;

create or replace function public.has_role(roles public.app_role[])
returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce((select p.role = any(roles) from public.profiles p where p.id = auth.uid() and p.active), false)
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_role public.app_role;
  v_active boolean := true;
begin
  if not exists (select 1 from public.profiles) then
    v_role := 'admin';
  elsif (new.raw_app_meta_data ->> 'role') is not null then
    v_role := (new.raw_app_meta_data ->> 'role')::public.app_role;
  else
    -- self sign-ups never receive access until an admin activates them
    v_role := 'comercial';
    v_active := false;
  end if;
  insert into public.profiles (id, email, full_name, role, active)
  values (new.id, coalesce(new.email,''), coalesce(new.raw_user_meta_data ->> 'full_name', ''), v_role, v_active)
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============ AUDIT ============
create table public.audit_logs (
  id bigint generated always as identity primary key,
  user_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text,
  details jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_entity_idx on public.audit_logs (entity, entity_id);
create index audit_logs_created_idx on public.audit_logs (created_at desc);

create or replace function public.log_audit(p_action text, p_entity text, p_entity_id text, p_details jsonb)
returns void language sql security definer set search_path = '' as $$
  insert into public.audit_logs (user_id, action, entity, entity_id, details)
  values (auth.uid(), p_action, p_entity, p_entity_id, p_details);
$$;
revoke execute on function public.log_audit(text,text,text,jsonb) from public, anon, authenticated;

create or replace function public.audit_trigger()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_changes jsonb := '{}'::jsonb;
  k text;
begin
  if tg_op = 'UPDATE' then
    for k in select jsonb_object_keys(to_jsonb(new)) loop
      if k not in ('updated_at') and (to_jsonb(new) -> k) is distinct from (to_jsonb(old) -> k) then
        v_changes := v_changes || jsonb_build_object(k, jsonb_build_object('de', to_jsonb(old) -> k, 'para', to_jsonb(new) -> k));
      end if;
    end loop;
    if v_changes = '{}'::jsonb then return new; end if;
    insert into public.audit_logs (user_id, action, entity, entity_id, details)
    values (auth.uid(), 'update', tg_table_name, (to_jsonb(new) ->> 'id'), v_changes);
    return new;
  elsif tg_op = 'INSERT' then
    insert into public.audit_logs (user_id, action, entity, entity_id, details)
    values (auth.uid(), 'insert', tg_table_name, (to_jsonb(new) ->> 'id'), null);
    return new;
  else
    insert into public.audit_logs (user_id, action, entity, entity_id, details)
    values (auth.uid(), 'delete', tg_table_name, (to_jsonb(old) ->> 'id'), to_jsonb(old));
    return old;
  end if;
end;
$$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end;
$$;

-- ============ SETTINGS / AUX ============
create table public.company_settings (
  id smallint primary key default 1 check (id = 1),
  company_name text not null default 'Pimentera Foods + Mixx Condimentos',
  legal_name text,
  cnpj text,
  state_registration text,
  address text,
  city text,
  state text,
  phone text,
  email text,
  website_pimentera text,
  website_mixx text,
  instagram_pimentera text,
  instagram_mixx text,
  logo_pimentera_path text,
  logo_mixx_path text,
  order_footer_notes text,
  default_freight numeric(12,2) not null default 0,
  updated_at timestamptz not null default now()
);

create table public.brands (
  id smallint primary key,
  code text not null unique,
  name text not null
);

create table public.product_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

create table public.units (
  code text primary key,
  description text not null
);

create table public.payment_terms (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  days integer[] not null default '{0}',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint payment_terms_days_chk check (cardinality(days) between 1 and 24)
);

create table public.payment_methods (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  active boolean not null default true
);

-- ============ PRODUCTS ============
create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique,
  name text not null,
  brand_id smallint not null references public.brands(id),
  category_id uuid references public.product_categories(id) on delete set null,
  description text,
  net_content text,
  unit text not null default 'UN' references public.units(code),
  barcode text,
  cost numeric(12,2) check (cost is null or cost >= 0),
  price numeric(12,2) check (price is null or price >= 0),
  min_price numeric(12,2) check (min_price is null or min_price >= 0),
  stock_physical integer not null default 0,
  stock_reserved integer not null default 0 check (stock_reserved >= 0),
  stock_min integer not null default 0 check (stock_min >= 0),
  active boolean not null default true,
  image_path text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_brand_idx on public.products (brand_id);
create unique index products_barcode_uq on public.products (barcode) where barcode is not null and barcode <> '';

create table public.inventory_lots (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  lot text not null,
  expiry_date date,
  quantity integer not null default 0,
  created_at timestamptz not null default now(),
  unique (product_id, lot)
);

-- ============ CUSTOMERS ============
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  code bigint generated always as identity unique,
  person_type text not null default 'PJ' check (person_type in ('PJ','PF')),
  legal_name text not null,
  trade_name text,
  document text,
  state_registration text,
  ie_indicator text check (ie_indicator in ('contribuinte','isento','nao_contribuinte')),
  buyer_name text,
  phone text,
  whatsapp text,
  email text,
  cep text,
  street text,
  number text,
  complement text,
  district text,
  city text,
  state text check (state is null or char_length(state) = 2),
  billing_address text,
  delivery_address text,
  receiver_name text,
  receiver_phone text,
  sales_rep_id uuid references public.profiles(id) on delete set null,
  channel text not null default 'supermercado' check (channel in ('supermercado','restaurante','bar','mercearia','distribuidor','outro')),
  payment_term_id uuid references public.payment_terms(id) on delete set null,
  credit_limit numeric(12,2) check (credit_limit is null or credit_limit >= 0),
  commercial_notes text,
  status text not null default 'prospect' check (status in ('prospect','ativo','inativo','bloqueado')),
  brands text[] not null default '{}',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index customers_document_uq on public.customers (document) where document is not null and document <> '';
create index customers_rep_idx on public.customers (sales_rep_id);
create index customers_city_idx on public.customers (city);

create table public.visits (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete cascade,
  rep_id uuid not null references public.profiles(id),
  visited_at timestamptz not null default now(),
  result text not null check (result in ('pedido','retorno','sem_interesse','prospeccao','outro')),
  notes text,
  next_action text,
  next_action_date date,
  created_at timestamptz not null default now()
);
create index visits_customer_idx on public.visits (customer_id, visited_at desc);

-- ============ ORDER TEMPLATES ============
create table public.order_templates (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.order_template_items (
  template_id uuid not null references public.order_templates(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  quantity integer not null check (quantity > 0),
  primary key (template_id, product_id)
);

-- ============ ORDERS ============
create sequence public.order_number_seq start 1;

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  number bigint not null unique default nextval('public.order_number_seq'),
  idempotency_key uuid not null unique,
  customer_id uuid not null references public.customers(id),
  customer_snapshot jsonb not null,
  delivery_address text,
  rep_id uuid not null references public.profiles(id),
  status public.order_status not null default 'rascunho',
  subtotal numeric(12,2) not null default 0,
  discount_total numeric(12,2) not null default 0,
  freight numeric(12,2) not null default 0 check (freight >= 0),
  tax_total numeric(12,2) not null default 0 check (tax_total >= 0),
  total numeric(12,2) not null default 0,
  payment_term_id uuid references public.payment_terms(id),
  payment_term_snapshot jsonb,
  expected_delivery date,
  notes text,
  requires_approval_reason text,
  stock_reserved boolean not null default false,
  stock_issued boolean not null default false,
  created_by uuid not null references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  cancel_reason text,
  cancelled_by uuid references public.profiles(id),
  cancelled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index orders_status_idx on public.orders (status);
create index orders_customer_idx on public.orders (customer_id, created_at desc);
create index orders_rep_idx on public.orders (rep_id, created_at desc);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  sku text not null,
  product_name text not null,
  brand_code text not null,
  unit text not null,
  quantity integer not null check (quantity > 0),
  list_price numeric(12,2) not null,
  min_price numeric(12,2),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  discount_pct numeric(5,2) not null default 0 check (discount_pct between 0 and 100),
  line_total numeric(12,2) not null,
  picked_qty integer not null default 0 check (picked_qty >= 0),
  lot text,
  delivered_qty integer not null default 0 check (delivered_qty >= 0),
  position smallint not null default 0
);
create index order_items_order_idx on public.order_items (order_id);
create index order_items_product_idx on public.order_items (product_id);

create table public.order_status_history (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders(id) on delete cascade,
  from_status public.order_status,
  to_status public.order_status not null,
  changed_by uuid references public.profiles(id),
  notes text,
  created_at timestamptz not null default now()
);
create index order_status_history_order_idx on public.order_status_history (order_id, created_at);

create table public.order_transitions (
  from_status public.order_status not null,
  to_status public.order_status not null,
  allowed_roles public.app_role[] not null,
  primary key (from_status, to_status)
);

-- ============ INVENTORY MOVEMENTS ============
create table public.inventory_movements (
  id bigint generated always as identity primary key,
  product_id uuid not null references public.products(id),
  type text not null check (type in ('entrada','saida','ajuste','reserva','liberacao','estorno')),
  quantity integer not null,
  physical_after integer not null,
  reserved_after integer not null,
  lot text,
  expiry_date date,
  reason text,
  order_id uuid references public.orders(id),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create index inventory_movements_product_idx on public.inventory_movements (product_id, created_at desc);

-- ============ INVOICES / RECEIVABLES ============
create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  doc_type text not null default 'NF-e' check (doc_type in ('NF-e','NFC-e','Recibo','Outro')),
  number text not null,
  series text,
  access_key text check (access_key is null or access_key ~ '^[0-9]{44}$'),
  issue_date date not null,
  amount numeric(12,2) not null check (amount > 0),
  status text not null default 'emitida' check (status in ('emitida','cancelada')),
  notes text,
  idempotency_key uuid not null unique,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  cancelled_by uuid references public.profiles(id),
  cancelled_at timestamptz,
  cancel_reason text
);
create unique index invoices_active_order_uq on public.invoices (order_id) where status = 'emitida';
create unique index invoices_number_uq on public.invoices (doc_type, coalesce(series,''), number) where status = 'emitida';

create table public.receivables (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  order_id uuid not null references public.orders(id),
  invoice_id uuid references public.invoices(id),
  original_amount numeric(12,2) not null check (original_amount > 0),
  issue_date date not null,
  payment_method text,
  status text not null default 'pendente' check (status in ('pendente','parcial','pago','cancelado')),
  created_at timestamptz not null default now()
);
create index receivables_customer_idx on public.receivables (customer_id);

create table public.receivable_installments (
  id uuid primary key default gen_random_uuid(),
  receivable_id uuid not null references public.receivables(id) on delete cascade,
  number smallint not null,
  due_date date not null,
  amount numeric(12,2) not null check (amount > 0),
  interest numeric(12,2) not null default 0 check (interest >= 0),
  discount numeric(12,2) not null default 0 check (discount >= 0),
  paid_amount numeric(12,2) not null default 0 check (paid_amount >= 0),
  status text not null default 'pendente' check (status in ('pendente','parcial','pago','cancelado')),
  unique (receivable_id, number)
);
create index receivable_installments_due_idx on public.receivable_installments (due_date) where status in ('pendente','parcial');

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  installment_id uuid not null references public.receivable_installments(id),
  receivable_id uuid not null references public.receivables(id),
  amount numeric(12,2) not null check (amount > 0),
  interest numeric(12,2) not null default 0 check (interest >= 0),
  discount numeric(12,2) not null default 0 check (discount >= 0),
  paid_at date not null,
  method text not null,
  notes text,
  idempotency_key uuid not null unique,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create index payments_paid_at_idx on public.payments (paid_at);

-- ============ DELIVERIES ============
create sequence public.delivery_number_seq start 1;

create table public.deliveries (
  id uuid primary key default gen_random_uuid(),
  number bigint not null unique default nextval('public.delivery_number_seq'),
  order_id uuid not null references public.orders(id),
  customer_name text not null,
  address text not null,
  contact text,
  scheduled_date date,
  driver_id uuid references public.profiles(id),
  status public.delivery_status not null default 'aguardando_expedicao',
  notes text,
  departed_at timestamptz,
  completed_at timestamptz,
  received_by text,
  proof_path text,
  result_notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index deliveries_driver_idx on public.deliveries (driver_id, status);
create index deliveries_order_idx on public.deliveries (order_id);

create table public.delivery_items (
  id uuid primary key default gen_random_uuid(),
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  order_item_id uuid not null references public.order_items(id),
  sku text not null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  delivered_qty integer not null default 0 check (delivered_qty >= 0)
);

create table public.delivery_status_history (
  id bigint generated always as identity primary key,
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  from_status public.delivery_status,
  to_status public.delivery_status not null,
  changed_by uuid references public.profiles(id),
  notes text,
  created_at timestamptz not null default now()
);

-- ============ updated_at + audit triggers ============
create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();
create trigger customers_touch before update on public.customers for each row execute function public.touch_updated_at();
create trigger orders_touch before update on public.orders for each row execute function public.touch_updated_at();
create trigger deliveries_touch before update on public.deliveries for each row execute function public.touch_updated_at();
create trigger settings_touch before update on public.company_settings for each row execute function public.touch_updated_at();

create trigger customers_audit after insert or update or delete on public.customers for each row execute function public.audit_trigger();
create trigger products_audit after insert or update or delete on public.products for each row execute function public.audit_trigger();
create trigger profiles_audit after update on public.profiles for each row execute function public.audit_trigger();
create trigger settings_audit after update on public.company_settings for each row execute function public.audit_trigger();
create trigger payment_terms_audit after insert or update or delete on public.payment_terms for each row execute function public.audit_trigger();
