-- 0003 Transactional business rules. All writes on orders/stock/finance/deliveries go through these functions.

-- ---------- internal stock helper ----------
create or replace function public._stock_move(
  p_product uuid, p_d_physical integer, p_d_reserved integer, p_type text, p_qty integer,
  p_reason text, p_order uuid, p_lot text default null, p_expiry date default null
) returns void language plpgsql security definer set search_path = '' as $$
declare
  v_prod public.products%rowtype;
  v_allow boolean;
begin
  select * into v_prod from public.products where id = p_product for update;
  if not found then raise exception 'Produto não encontrado.'; end if;
  select coalesce(allow_negative_stock, false) into v_allow from public.profiles where id = auth.uid();
  if v_prod.stock_physical + p_d_physical < 0 and not coalesce(v_allow, false) then
    raise exception 'Estoque insuficiente para % (físico atual: %).', v_prod.name, v_prod.stock_physical;
  end if;
  if v_prod.stock_reserved + p_d_reserved < 0 then
    raise exception 'Reserva inconsistente para %.', v_prod.name;
  end if;
  perform set_config('app.stock_rpc', 'on', true);
  update public.products
     set stock_physical = stock_physical + p_d_physical,
         stock_reserved = stock_reserved + p_d_reserved
   where id = p_product;
  perform set_config('app.stock_rpc', 'off', true);
  insert into public.inventory_movements (product_id, type, quantity, physical_after, reserved_after, lot, expiry_date, reason, order_id, created_by)
  values (p_product, p_type, p_qty, v_prod.stock_physical + p_d_physical, v_prod.stock_reserved + p_d_reserved,
          p_lot, p_expiry, p_reason, p_order, auth.uid());
  if v_prod.stock_physical + p_d_physical < 0 then
    perform public.log_audit('estoque_negativo', 'products', p_product::text,
      jsonb_build_object('fisico_apos', v_prod.stock_physical + p_d_physical, 'pedido', p_order));
  end if;
end;
$$;
revoke execute on function public._stock_move(uuid,integer,integer,text,integer,text,uuid,text,date) from public, anon, authenticated;

-- ---------- manual stock movement ----------
create or replace function public.stock_adjust(
  p_product uuid, p_type text, p_qty integer, p_reason text, p_lot text default null, p_expiry date default null
) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.has_role(array['admin','estoque']::public.app_role[]) then
    raise exception 'Sem permissão para movimentar estoque.';
  end if;
  if p_qty is null or p_qty = 0 or abs(p_qty) > 1000000 then raise exception 'Quantidade inválida.'; end if;
  if p_type not in ('entrada','saida','ajuste') then raise exception 'Tipo de movimentação inválido.'; end if;
  if p_type = 'ajuste' and coalesce(trim(p_reason),'') = '' then raise exception 'Ajustes exigem justificativa.'; end if;
  if p_type in ('entrada','saida') and p_qty < 0 then raise exception 'Informe quantidade positiva.'; end if;

  if p_type = 'entrada' then
    perform public._stock_move(p_product, p_qty, 0, 'entrada', p_qty, p_reason, null, nullif(trim(p_lot),''), p_expiry);
    if coalesce(trim(p_lot),'') <> '' then
      insert into public.inventory_lots (product_id, lot, expiry_date, quantity)
      values (p_product, trim(p_lot), p_expiry, p_qty)
      on conflict (product_id, lot) do update set quantity = public.inventory_lots.quantity + excluded.quantity,
        expiry_date = coalesce(excluded.expiry_date, public.inventory_lots.expiry_date);
    end if;
  elsif p_type = 'saida' then
    perform public._stock_move(p_product, -p_qty, 0, 'saida', -p_qty, p_reason, null, nullif(trim(p_lot),''), null);
    if coalesce(trim(p_lot),'') <> '' then
      update public.inventory_lots set quantity = quantity - p_qty where product_id = p_product and lot = trim(p_lot);
    end if;
  else
    perform public._stock_move(p_product, p_qty, 0, 'ajuste', p_qty, p_reason, null, nullif(trim(p_lot),''), null);
  end if;
end;
$$;

-- ---------- customer duplicate check (minimal fields) ----------
create or replace function public.find_customer_duplicates(p_document text, p_name text, p_exclude uuid default null)
returns table (id uuid, code bigint, display_name text, city text, reason text)
language sql stable security definer set search_path = '' as $$
  select c.id, c.code, coalesce(nullif(c.trade_name,''), c.legal_name), c.city,
         case when p_document <> '' and c.document = p_document then 'documento' else 'nome' end
  from public.customers c
  where public.my_role() is not null
    and (p_exclude is null or c.id <> p_exclude)
    and (
      (coalesce(p_document,'') <> '' and c.document = p_document)
      or (char_length(coalesce(p_name,'')) >= 4 and (c.legal_name ilike p_name or c.trade_name ilike p_name))
    )
  limit 5
$$;

-- ---------- order save (create/update draft, optional submit) ----------
create or replace function public.save_order(p jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_role public.app_role := public.my_role();
  v_id uuid := nullif(p ->> 'id','')::uuid;
  v_key uuid := (p ->> 'idempotency_key')::uuid;
  v_existing public.orders%rowtype;
  v_cust public.customers%rowtype;
  v_term public.payment_terms%rowtype;
  v_rep uuid;
  v_max_disc numeric;
  v_item jsonb;
  v_prod public.products%rowtype;
  v_qty integer;
  v_price numeric;
  v_disc numeric;
  v_net numeric;
  v_line numeric;
  v_subtotal numeric := 0;
  v_gross numeric := 0;
  v_freight numeric := coalesce((p ->> 'freight')::numeric, 0);
  v_tax numeric := coalesce((p ->> 'tax_total')::numeric, 0);
  v_reasons text[] := '{}';
  v_pos integer := 0;
  v_submit boolean := coalesce((p ->> 'submit')::boolean, false);
  v_number bigint;
  v_status public.order_status;
begin
  if v_role is null or v_role not in ('admin','gerente','comercial') then
    raise exception 'Sem permissão para registrar pedidos.';
  end if;
  if v_key is null then raise exception 'Chave de idempotência ausente.'; end if;

  -- replay of the same submission returns the original order
  select * into v_existing from public.orders where idempotency_key = v_key;
  if found and (v_id is null or v_existing.id <> v_id) then
    return jsonb_build_object('id', v_existing.id, 'number', v_existing.number, 'replay', true);
  end if;

  if v_id is not null then
    select * into v_existing from public.orders where id = v_id for update;
    if not found then raise exception 'Pedido não encontrado.'; end if;
    if v_existing.status <> 'rascunho' then raise exception 'Somente rascunhos podem ser editados.'; end if;
    if v_role = 'comercial' and v_existing.rep_id <> v_uid then raise exception 'Pedido pertence a outro representante.'; end if;
  end if;

  select * into v_cust from public.customers where id = (p ->> 'customer_id')::uuid;
  if not found then raise exception 'Cliente não encontrado.'; end if;
  if v_role = 'comercial' and v_cust.sales_rep_id is not null and v_cust.sales_rep_id <> v_uid then
    raise exception 'Cliente atendido por outro representante.';
  end if;
  if v_cust.status = 'bloqueado' then raise exception 'Cliente bloqueado. Pedido não permitido.'; end if;

  if nullif(p ->> 'payment_term_id','') is not null then
    select * into v_term from public.payment_terms where id = (p ->> 'payment_term_id')::uuid and active;
    if not found then raise exception 'Condição de pagamento inválida.'; end if;
  elsif v_submit then
    raise exception 'Informe a condição de pagamento.';
  end if;

  if v_freight < 0 or v_tax < 0 then raise exception 'Frete/impostos não podem ser negativos.'; end if;
  if jsonb_typeof(p -> 'items') <> 'array' or jsonb_array_length(p -> 'items') = 0 then
    raise exception 'Adicione ao menos um item.';
  end if;
  if jsonb_array_length(p -> 'items') > 200 then raise exception 'Itens demais no pedido.'; end if;

  v_rep := case when v_role = 'comercial' then v_uid else coalesce(nullif(p ->> 'rep_id','')::uuid, v_existing.rep_id, v_cust.sales_rep_id, v_uid) end;
  select max_discount_pct into v_max_disc from public.profiles where id = v_rep;

  if v_id is null then
    insert into public.orders (idempotency_key, customer_id, customer_snapshot, rep_id, created_by, status)
    values (v_key, v_cust.id, '{}'::jsonb, v_rep, v_uid, 'rascunho')
    returning id, number into v_id, v_number;
  else
    v_number := v_existing.number;
    delete from public.order_items where order_id = v_id;
  end if;

  for v_item in select * from jsonb_array_elements(p -> 'items') loop
    v_qty := (v_item ->> 'quantity')::integer;
    if v_qty is null or v_qty <= 0 or v_qty > 100000 then raise exception 'Quantidade inválida em um dos itens.'; end if;
    if ((v_item ->> 'quantity')::numeric) <> v_qty then raise exception 'Quantidades devem ser inteiras.'; end if;
    select * into v_prod from public.products where id = (v_item ->> 'product_id')::uuid;
    if not found or not v_prod.active then raise exception 'Produto inválido ou inativo.'; end if;
    if exists (select 1 from public.order_items oi where oi.order_id = v_id and oi.product_id = v_prod.id) then
      raise exception 'Produto % repetido no pedido.', v_prod.name;
    end if;
    v_price := coalesce(nullif(v_item ->> 'unit_price','')::numeric, v_prod.price);
    if v_price is null then
      raise exception 'Produto % sem preço cadastrado. Informe o preço ou peça ao administrador.', v_prod.name;
    end if;
    if v_price < 0 then raise exception 'Preço inválido.'; end if;
    v_disc := coalesce(nullif(v_item ->> 'discount_pct','')::numeric, 0);
    if v_disc < 0 or v_disc > 100 then raise exception 'Desconto inválido.'; end if;
    v_net := round(v_price * (1 - v_disc / 100), 2);
    v_line := round(v_net * v_qty, 2);
    v_subtotal := v_subtotal + round(v_price * v_qty, 2);
    v_gross := v_gross + v_line;

    if v_prod.min_price is not null and v_net < v_prod.min_price then
      v_reasons := array_append(v_reasons, format('%s abaixo do preço mínimo', v_prod.sku));
    end if;
    if v_prod.price is not null and v_prod.price > 0
       and (1 - v_net / v_prod.price) * 100 > coalesce(v_max_disc, 0) + 0.001 then
      v_reasons := array_append(v_reasons, format('%s com desconto acima do limite do vendedor', v_prod.sku));
    end if;

    v_pos := v_pos + 1;
    insert into public.order_items (order_id, product_id, sku, product_name, brand_code, unit, quantity, list_price, min_price, unit_price, discount_pct, line_total, position)
    values (v_id, v_prod.id, v_prod.sku, v_prod.name || coalesce(' — ' || v_prod.net_content, ''),
            (select b.code from public.brands b where b.id = v_prod.brand_id), v_prod.unit, v_qty,
            coalesce(v_prod.price, v_price), v_prod.min_price, v_price, v_disc, v_line, v_pos);
  end loop;

  v_status := case when v_submit then 'aguardando_aprovacao'::public.order_status else 'rascunho'::public.order_status end;

  update public.orders set
    customer_id = v_cust.id,
    customer_snapshot = jsonb_build_object(
      'code', v_cust.code, 'person_type', v_cust.person_type, 'legal_name', v_cust.legal_name, 'trade_name', v_cust.trade_name,
      'document', v_cust.document, 'state_registration', v_cust.state_registration, 'buyer_name', v_cust.buyer_name,
      'phone', v_cust.phone, 'whatsapp', v_cust.whatsapp, 'email', v_cust.email, 'cep', v_cust.cep, 'street', v_cust.street,
      'number', v_cust.number, 'complement', v_cust.complement, 'district', v_cust.district, 'city', v_cust.city, 'state', v_cust.state,
      'receiver_name', v_cust.receiver_name, 'receiver_phone', v_cust.receiver_phone),
    delivery_address = nullif(trim(p ->> 'delivery_address'), ''),
    rep_id = v_rep,
    status = v_status,
    subtotal = v_subtotal,
    discount_total = v_subtotal - v_gross,
    freight = v_freight,
    tax_total = v_tax,
    total = v_gross + v_freight + v_tax,
    payment_term_id = v_term.id,
    payment_term_snapshot = case when v_term.id is null then null else jsonb_build_object('name', v_term.name, 'days', v_term.days) end,
    expected_delivery = nullif(p ->> 'expected_delivery','')::date,
    notes = nullif(trim(p ->> 'notes'), ''),
    requires_approval_reason = nullif(array_to_string(v_reasons, '; '), '')
  where id = v_id;

  if v_existing.id is null then
    insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
    values (v_id, null, 'rascunho', v_uid, 'Pedido criado');
  end if;
  if v_submit then
    insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
    values (v_id, 'rascunho', 'aguardando_aprovacao', v_uid, nullif(array_to_string(v_reasons, '; '), ''));
  end if;
  perform public.log_audit(case when v_existing.id is null then 'criar_pedido' else 'editar_pedido' end, 'orders', v_id::text,
    jsonb_build_object('numero', v_number, 'total', v_gross + v_freight + v_tax, 'enviado', v_submit));

  return jsonb_build_object('id', v_id, 'number', v_number, 'replay', false);
end;
$$;

-- ---------- picking quantities ----------
create or replace function public.save_picking(p_order uuid, p_items jsonb)
returns void language plpgsql security definer set search_path = '' as $$
declare
  v_order public.orders%rowtype;
  v_item jsonb;
  v_qty integer;
begin
  if not public.has_role(array['admin','estoque']::public.app_role[]) then raise exception 'Sem permissão.'; end if;
  select * into v_order from public.orders where id = p_order for update;
  if not found then raise exception 'Pedido não encontrado.'; end if;
  if v_order.status <> 'em_separacao' then raise exception 'O pedido precisa estar em separação.'; end if;
  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item ->> 'picked_qty')::integer;
    if v_qty is null or v_qty < 0 then raise exception 'Quantidade separada inválida.'; end if;
    update public.order_items
       set picked_qty = least(v_qty, quantity), lot = nullif(trim(v_item ->> 'lot'), '')
     where id = (v_item ->> 'id')::uuid and order_id = p_order;
  end loop;
end;
$$;

-- ---------- status transitions ----------
create or replace function public.change_order_status(p_order uuid, p_to public.order_status, p_notes text default null)
returns public.order_status language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_role public.app_role := public.my_role();
  v_order public.orders%rowtype;
  v_allowed public.app_role[];
  v_final public.order_status := p_to;
  v_it record;
  v_short boolean := false;
begin
  if v_role is null then raise exception 'Sem permissão.'; end if;
  if p_to in ('faturado','pronto_expedicao','em_rota','entregue','entrega_parcial','entrega_nao_realizada','aguardando_estoque') then
    raise exception 'Este status é definido automaticamente pelo módulo correspondente.';
  end if;
  select * into v_order from public.orders where id = p_order for update;
  if not found then raise exception 'Pedido não encontrado.'; end if;
  if v_order.status = p_to then raise exception 'O pedido já está neste status.'; end if;

  select allowed_roles into v_allowed from public.order_transitions where from_status = v_order.status and to_status = p_to;
  if v_allowed is null then
    raise exception 'Transição de "%" para "%" não permitida.', v_order.status, p_to;
  end if;
  if not (v_role = any(v_allowed)) then raise exception 'Seu perfil não pode executar esta transição.'; end if;
  if v_role = 'comercial' and v_order.rep_id <> v_uid then raise exception 'Pedido pertence a outro representante.'; end if;

  if p_to = 'aprovado' then
    if v_order.created_by = v_uid and v_role not in ('admin') and v_order.requires_approval_reason is not null then
      raise exception 'Descontos fora do limite precisam ser aprovados por outro responsável.';
    end if;
    -- reserve stock; if any item lacks availability, park the order in "aguardando_estoque"
    for v_it in
      select oi.product_id, sum(oi.quantity)::integer as qty, p.stock_physical - p.stock_reserved as available
      from public.order_items oi join public.products p on p.id = oi.product_id
      where oi.order_id = p_order group by oi.product_id, p.stock_physical, p.stock_reserved
    loop
      if v_it.available < v_it.qty then v_short := true; end if;
    end loop;
    if v_short then
      v_final := 'aguardando_estoque';
    else
      for v_it in select product_id, sum(quantity)::integer as qty from public.order_items where order_id = p_order group by product_id loop
        perform public._stock_move(v_it.product_id, 0, v_it.qty, 'reserva', v_it.qty, 'Reserva para pedido', p_order);
      end loop;
      update public.orders set stock_reserved = true where id = p_order;
    end if;
    if v_order.approved_by is null then
      update public.orders set approved_by = v_uid, approved_at = now() where id = p_order;
    end if;
  elsif p_to = 'separado' then
    if not exists (select 1 from public.order_items where order_id = p_order and picked_qty > 0) then
      raise exception 'Registre as quantidades separadas antes de concluir a conferência.';
    end if;
    for v_it in select product_id, quantity, picked_qty, lot from public.order_items where order_id = p_order loop
      perform public._stock_move(v_it.product_id, -v_it.picked_qty, -v_it.quantity, 'saida', -v_it.picked_qty,
        'Saída por separação', p_order, v_it.lot);
      if v_it.lot is not null then
        update public.inventory_lots set quantity = quantity - v_it.picked_qty where product_id = v_it.product_id and lot = v_it.lot;
      end if;
    end loop;
    update public.orders set stock_reserved = false, stock_issued = true where id = p_order;
  elsif p_to = 'cancelado' then
    if coalesce(trim(p_notes),'') = '' then raise exception 'Informe o motivo do cancelamento.'; end if;
    if exists (select 1 from public.invoices where order_id = p_order and status = 'emitida') then
      raise exception 'Cancele o documento fiscal antes de cancelar o pedido.';
    end if;
    if v_order.stock_reserved then
      for v_it in select product_id, sum(quantity)::integer as qty from public.order_items where order_id = p_order group by product_id loop
        perform public._stock_move(v_it.product_id, 0, -v_it.qty, 'liberacao', v_it.qty, 'Cancelamento do pedido', p_order);
      end loop;
    end if;
    if v_order.stock_issued then
      for v_it in select product_id, sum(picked_qty - delivered_qty)::integer as qty from public.order_items where order_id = p_order group by product_id loop
        if v_it.qty > 0 then
          perform public._stock_move(v_it.product_id, v_it.qty, 0, 'estorno', v_it.qty, 'Estorno por cancelamento', p_order);
        end if;
      end loop;
    end if;
    update public.orders set stock_reserved = false, stock_issued = false, cancel_reason = trim(p_notes),
      cancelled_by = v_uid, cancelled_at = now() where id = p_order;
  elsif p_to = 'rascunho' then
    update public.orders set approved_by = null, approved_at = null where id = p_order;
  end if;

  update public.orders set status = v_final where id = p_order;
  insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
  values (p_order, v_order.status, v_final,  v_uid,
          case when v_final <> p_to then coalesce(p_notes || ' — ', '') || 'Estoque insuficiente para reserva' else p_notes end);
  perform public.log_audit('status_pedido', 'orders', p_order::text,
    jsonb_build_object('de', v_order.status, 'para', v_final, 'obs', p_notes));
  return v_final;
end;
$$;

-- ---------- invoicing ----------
create or replace function public.register_invoice(p jsonb)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_order public.orders%rowtype;
  v_key uuid := (p ->> 'idempotency_key')::uuid;
  v_inv uuid;
  v_rec uuid;
  v_amount numeric := (p ->> 'amount')::numeric;
  v_issue date := (p ->> 'issue_date')::date;
  v_days integer[];
  v_n integer;
  v_each numeric;
  i integer;
begin
  if not public.has_role(array['admin','faturamento']::public.app_role[]) then raise exception 'Sem permissão para faturar.'; end if;
  select id into v_inv from public.invoices where idempotency_key = v_key;
  if found then return v_inv; end if;

  select * into v_order from public.orders where id = (p ->> 'order_id')::uuid for update;
  if not found then raise exception 'Pedido não encontrado.'; end if;
  if v_order.status <> 'aguardando_faturamento' then raise exception 'O pedido não está aguardando faturamento.'; end if;
  if coalesce(trim(p ->> 'number'),'') = '' then raise exception 'Informe o número do documento.'; end if;
  if v_amount is null or v_amount <= 0 then raise exception 'Valor faturado inválido.'; end if;
  if v_issue is null then raise exception 'Informe a data de emissão.'; end if;

  insert into public.invoices (order_id, doc_type, number, series, access_key, issue_date, amount, notes, idempotency_key, created_by)
  values (v_order.id, coalesce(nullif(p ->> 'doc_type',''), 'NF-e'), trim(p ->> 'number'), nullif(trim(p ->> 'series'),''),
          nullif(regexp_replace(coalesce(p ->> 'access_key',''), '\D', '', 'g'), ''), v_issue, v_amount,
          nullif(trim(p ->> 'notes'),''), v_key, v_uid)
  returning id into v_inv;

  v_days := coalesce((select array_agg(x::integer) from jsonb_array_elements_text(v_order.payment_term_snapshot -> 'days') x), '{0}');
  v_n := cardinality(v_days);
  v_each := trunc(v_amount / v_n, 2);

  insert into public.receivables (customer_id, order_id, invoice_id, original_amount, issue_date, payment_method)
  values (v_order.customer_id, v_order.id, v_inv, v_amount, v_issue, nullif(p ->> 'payment_method',''))
  returning id into v_rec;

  for i in 1..v_n loop
    insert into public.receivable_installments (receivable_id, number, due_date, amount)
    values (v_rec, i, v_issue + v_days[i], case when i = v_n then v_amount - v_each * (v_n - 1) else v_each end);
  end loop;

  update public.orders set status = 'faturado' where id = v_order.id;
  insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
  values (v_order.id, v_order.status, 'faturado', v_uid, format('Documento %s nº %s', coalesce(nullif(p ->> 'doc_type',''),'NF-e'), trim(p ->> 'number')));
  perform public.log_audit('faturar', 'invoices', v_inv::text, jsonb_build_object('pedido', v_order.number, 'valor', v_amount));
  return v_inv;
end;
$$;

create or replace function public.cancel_invoice(p_invoice uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare
  v_inv public.invoices%rowtype;
begin
  if not public.has_role(array['admin','faturamento']::public.app_role[]) then raise exception 'Sem permissão.'; end if;
  if coalesce(trim(p_reason),'') = '' then raise exception 'Informe o motivo.'; end if;
  select * into v_inv from public.invoices where id = p_invoice for update;
  if not found or v_inv.status <> 'emitida' then raise exception 'Documento não encontrado ou já cancelado.'; end if;
  if exists (select 1 from public.payments pm join public.receivables r on r.id = pm.receivable_id where r.invoice_id = p_invoice) then
    raise exception 'Há pagamentos registrados para este documento. Estorne-os antes de cancelar.';
  end if;
  if exists (select 1 from public.deliveries where order_id = v_inv.order_id and status not in ('aguardando_expedicao','pronta','reagendada')) then
    raise exception 'O pedido já saiu para entrega.';
  end if;
  update public.invoices set status = 'cancelada', cancelled_by = auth.uid(), cancelled_at = now(), cancel_reason = trim(p_reason) where id = p_invoice;
  update public.receivables set status = 'cancelado' where invoice_id = p_invoice;
  update public.receivable_installments set status = 'cancelado'
   where receivable_id in (select id from public.receivables where invoice_id = p_invoice);
  delete from public.deliveries where order_id = v_inv.order_id and status in ('aguardando_expedicao','pronta','reagendada');
  update public.orders set status = 'aguardando_faturamento' where id = v_inv.order_id;
  insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
  values (v_inv.order_id, 'faturado', 'aguardando_faturamento', auth.uid(), 'Documento fiscal cancelado: ' || trim(p_reason));
  perform public.log_audit('cancelar_faturamento', 'invoices', p_invoice::text, jsonb_build_object('motivo', p_reason));
end;
$$;

-- ---------- payments ----------
create or replace function public.register_payment(p jsonb)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_key uuid := (p ->> 'idempotency_key')::uuid;
  v_pay uuid;
  v_inst public.receivable_installments%rowtype;
  v_amount numeric := round((p ->> 'amount')::numeric, 2);
  v_interest numeric := round(coalesce(nullif(p ->> 'interest','')::numeric, 0), 2);
  v_discount numeric := round(coalesce(nullif(p ->> 'discount','')::numeric, 0), 2);
  v_balance numeric;
  v_rec_status text;
begin
  if not public.has_role(array['admin','faturamento']::public.app_role[]) then raise exception 'Sem permissão para registrar pagamentos.'; end if;
  select id into v_pay from public.payments where idempotency_key = v_key;
  if found then return v_pay; end if;

  select * into v_inst from public.receivable_installments where id = (p ->> 'installment_id')::uuid for update;
  if not found then raise exception 'Parcela não encontrada.'; end if;
  if v_inst.status in ('pago','cancelado') then raise exception 'Parcela já quitada ou cancelada.'; end if;
  if v_amount is null or v_amount <= 0 then raise exception 'Valor recebido inválido.'; end if;
  if v_interest < 0 or v_discount < 0 then raise exception 'Juros/desconto inválidos.'; end if;
  if coalesce(p ->> 'method','') = '' then raise exception 'Informe a forma de pagamento.'; end if;

  v_balance := v_inst.amount + v_inst.interest + v_interest - v_inst.discount - v_discount - v_inst.paid_amount - v_amount;
  if v_balance < -0.009 then raise exception 'Valor excede o saldo da parcela.'; end if;

  insert into public.payments (installment_id, receivable_id, amount, interest, discount, paid_at, method, notes, idempotency_key, created_by)
  values (v_inst.id, v_inst.receivable_id, v_amount, v_interest, v_discount, coalesce(nullif(p ->> 'paid_at','')::date, current_date),
          p ->> 'method', nullif(trim(p ->> 'notes'),''), v_key, auth.uid())
  returning id into v_pay;

  update public.receivable_installments set
    interest = interest + v_interest, discount = discount + v_discount, paid_amount = paid_amount + v_amount,
    status = case when v_balance <= 0.009 then 'pago' else 'parcial' end
  where id = v_inst.id;

  select case
    when bool_and(status in ('pago','cancelado')) then 'pago'
    when bool_or(status in ('pago','parcial')) then 'parcial'
    else 'pendente' end
  into v_rec_status from public.receivable_installments where receivable_id = v_inst.receivable_id;
  update public.receivables set status = v_rec_status where id = v_inst.receivable_id;

  perform public.log_audit('pagamento', 'payments', v_pay::text,
    jsonb_build_object('parcela', v_inst.id, 'valor', v_amount, 'juros', v_interest, 'desconto', v_discount));
  return v_pay;
end;
$$;

-- ---------- deliveries ----------
create or replace function public.create_delivery(p_order uuid, p_driver uuid, p_date date, p_notes text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_order public.orders%rowtype;
  v_del uuid;
  v_snap jsonb;
  v_count integer;
begin
  if not public.has_role(array['admin','estoque']::public.app_role[]) then raise exception 'Sem permissão.'; end if;
  select * into v_order from public.orders where id = p_order for update;
  if not found then raise exception 'Pedido não encontrado.'; end if;
  if v_order.status not in ('faturado','entrega_parcial','entrega_nao_realizada') then
    raise exception 'Somente pedidos faturados (ou com entrega pendente) podem ser expedidos.';
  end if;
  if exists (select 1 from public.deliveries where order_id = p_order and status in ('aguardando_expedicao','pronta','em_rota','reagendada')) then
    raise exception 'Já existe uma entrega em aberto para este pedido.';
  end if;
  if p_driver is not null and not exists (select 1 from public.profiles where id = p_driver and role = 'entregador' and active) then
    raise exception 'Entregador inválido.';
  end if;
  v_snap := v_order.customer_snapshot;

  insert into public.deliveries (order_id, customer_name, address, contact, scheduled_date, driver_id, status, notes, created_by)
  values (p_order, coalesce(nullif(v_snap ->> 'trade_name',''), v_snap ->> 'legal_name'),
    coalesce(v_order.delivery_address, concat_ws(', ', v_snap ->> 'street', v_snap ->> 'number', v_snap ->> 'complement',
      v_snap ->> 'district', concat_ws('/', v_snap ->> 'city', v_snap ->> 'state'), v_snap ->> 'cep')),
    concat_ws(' — ', nullif(v_snap ->> 'receiver_name',''), nullif(coalesce(v_snap ->> 'receiver_phone', v_snap ->> 'phone'),'')),
    coalesce(p_date, v_order.expected_delivery), p_driver,
    case when p_driver is null then 'aguardando_expedicao'::public.delivery_status else 'pronta'::public.delivery_status end,
    nullif(trim(p_notes),''), auth.uid())
  returning id into v_del;

  insert into public.delivery_items (delivery_id, order_item_id, sku, product_name, quantity)
  select v_del, oi.id, oi.sku, oi.product_name, oi.picked_qty - oi.delivered_qty
  from public.order_items oi where oi.order_id = p_order and oi.picked_qty - oi.delivered_qty > 0;
  get diagnostics v_count = row_count;
  if v_count = 0 then raise exception 'Não há itens pendentes de entrega.'; end if;

  insert into public.delivery_status_history (delivery_id, from_status, to_status, changed_by, notes)
  values (v_del, null, (select status from public.deliveries where id = v_del), auth.uid(), 'Entrega criada');
  update public.orders set status = 'pronto_expedicao' where id = p_order;
  insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
  values (p_order, v_order.status, 'pronto_expedicao', auth.uid(), 'Entrega criada');
  perform public.log_audit('criar_entrega', 'deliveries', v_del::text, jsonb_build_object('pedido', v_order.number));
  return v_del;
end;
$$;

create or replace function public.assign_delivery(p_delivery uuid, p_driver uuid, p_date date)
returns void language plpgsql security definer set search_path = '' as $$
declare v_d public.deliveries%rowtype;
begin
  if not public.has_role(array['admin','estoque']::public.app_role[]) then raise exception 'Sem permissão.'; end if;
  select * into v_d from public.deliveries where id = p_delivery for update;
  if not found then raise exception 'Entrega não encontrada.'; end if;
  if v_d.status not in ('aguardando_expedicao','pronta','reagendada') then raise exception 'Entrega já em andamento ou finalizada.'; end if;
  if p_driver is not null and not exists (select 1 from public.profiles where id = p_driver and role = 'entregador' and active) then
    raise exception 'Entregador inválido.';
  end if;
  update public.deliveries set driver_id = p_driver, scheduled_date = coalesce(p_date, scheduled_date),
    status = case when p_driver is null then 'aguardando_expedicao'::public.delivery_status else 'pronta'::public.delivery_status end
  where id = p_delivery;
  insert into public.delivery_status_history (delivery_id, from_status, to_status, changed_by, notes)
  values (p_delivery, v_d.status, case when p_driver is null then 'aguardando_expedicao'::public.delivery_status else 'pronta'::public.delivery_status end,
          auth.uid(), 'Responsável/data atualizados');
end;
$$;

create or replace function public.update_delivery(p jsonb)
returns void language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_role public.app_role := public.my_role();
  v_d public.deliveries%rowtype;
  v_to public.delivery_status := (p ->> 'status')::public.delivery_status;
  v_item jsonb;
  v_qty integer;
  v_order_status public.order_status;
  v_prev_order public.order_status;
  v_pending integer;
begin
  select * into v_d from public.deliveries where id = (p ->> 'delivery_id')::uuid for update;
  if not found then raise exception 'Entrega não encontrada.'; end if;
  if not (v_role in ('admin','estoque') or (v_role = 'entregador' and v_d.driver_id = v_uid)) then
    raise exception 'Sem permissão para esta entrega.';
  end if;
  if v_d.status in ('entregue','entrega_parcial','recusada','cliente_ausente','endereco_incorreto') then
    raise exception 'Entrega já finalizada.';
  end if;
  if v_to = 'em_rota' then
    if v_d.status not in ('pronta','reagendada') then raise exception 'A entrega precisa estar pronta para sair.'; end if;
    if v_d.driver_id is null then raise exception 'Defina o entregador.'; end if;
  elsif v_to in ('entregue','entrega_parcial','cliente_ausente','endereco_incorreto','recusada','reagendada') then
    if v_d.status <> 'em_rota' and v_to <> 'reagendada' then raise exception 'A entrega precisa estar em rota.'; end if;
  else
    raise exception 'Status inválido.';
  end if;

  if v_to in ('entregue','entrega_parcial') then
    if coalesce(trim(p ->> 'received_by'),'') = '' then raise exception 'Informe o nome de quem recebeu.'; end if;
    if v_to = 'entregue' then
      update public.delivery_items set delivered_qty = quantity where delivery_id = v_d.id;
    else
      for v_item in select * from jsonb_array_elements(coalesce(p -> 'items','[]'::jsonb)) loop
        v_qty := (v_item ->> 'delivered_qty')::integer;
        if v_qty is null or v_qty < 0 then raise exception 'Quantidade entregue inválida.'; end if;
        update public.delivery_items set delivered_qty = least(v_qty, quantity)
         where id = (v_item ->> 'id')::uuid and delivery_id = v_d.id;
      end loop;
      if not exists (select 1 from public.delivery_items where delivery_id = v_d.id and delivered_qty > 0) then
        raise exception 'Informe ao menos um item entregue.';
      end if;
    end if;
    update public.order_items oi set delivered_qty = oi.delivered_qty + di.delivered_qty
      from public.delivery_items di where di.delivery_id = v_d.id and di.order_item_id = oi.id;
  end if;

  update public.deliveries set
    status = v_to,
    departed_at = case when v_to = 'em_rota' then now() else departed_at end,
    completed_at = case when v_to in ('entregue','entrega_parcial','cliente_ausente','endereco_incorreto','recusada') then now() else completed_at end,
    received_by = coalesce(nullif(trim(p ->> 'received_by'),''), received_by),
    result_notes = coalesce(nullif(trim(p ->> 'notes'),''), result_notes),
    proof_path = coalesce(nullif(p ->> 'proof_path',''), proof_path),
    scheduled_date = case when v_to = 'reagendada' then coalesce(nullif(p ->> 'scheduled_date','')::date, scheduled_date) else scheduled_date end
  where id = v_d.id;

  insert into public.delivery_status_history (delivery_id, from_status, to_status, changed_by, notes)
  values (v_d.id, v_d.status, v_to, v_uid, nullif(trim(p ->> 'notes'),''));

  select status into v_prev_order from public.orders where id = v_d.order_id for update;
  select coalesce(sum(quantity - delivered_qty), 0) into v_pending from public.order_items where order_id = v_d.order_id;
  v_order_status := case
    when v_to = 'em_rota' then 'em_rota'
    when v_to in ('entregue','entrega_parcial') and v_pending = 0 then 'entregue'
    when v_to in ('entregue','entrega_parcial') then 'entrega_parcial'
    when v_to = 'reagendada' then 'pronto_expedicao'
    else 'entrega_nao_realizada' end;
  if v_order_status is distinct from v_prev_order then
    update public.orders set status = v_order_status where id = v_d.order_id;
    insert into public.order_status_history (order_id, from_status, to_status, changed_by, notes)
    values (v_d.order_id, v_prev_order, v_order_status, v_uid, format('Entrega nº %s: %s', v_d.number, v_to));
  end if;
  perform public.log_audit('entrega_status', 'deliveries', v_d.id::text, jsonb_build_object('de', v_d.status, 'para', v_to));
end;
$$;

-- functions callable by logged in users (each validates role internally)
revoke execute on function public.save_order(jsonb) from public, anon;
revoke execute on function public.save_picking(uuid, jsonb) from public, anon;
revoke execute on function public.change_order_status(uuid, public.order_status, text) from public, anon;
revoke execute on function public.register_invoice(jsonb) from public, anon;
revoke execute on function public.cancel_invoice(uuid, text) from public, anon;
revoke execute on function public.register_payment(jsonb) from public, anon;
revoke execute on function public.create_delivery(uuid, uuid, date, text) from public, anon;
revoke execute on function public.assign_delivery(uuid, uuid, date) from public, anon;
revoke execute on function public.update_delivery(jsonb) from public, anon;
revoke execute on function public.stock_adjust(uuid, text, integer, text, text, date) from public, anon;
revoke execute on function public.find_customer_duplicates(text, text, uuid) from public, anon;
grant execute on function public.save_order(jsonb) to authenticated;
grant execute on function public.save_picking(uuid, jsonb) to authenticated;
grant execute on function public.change_order_status(uuid, public.order_status, text) to authenticated;
grant execute on function public.register_invoice(jsonb) to authenticated;
grant execute on function public.cancel_invoice(uuid, text) to authenticated;
grant execute on function public.register_payment(jsonb) to authenticated;
grant execute on function public.create_delivery(uuid, uuid, date, text) to authenticated;
grant execute on function public.assign_delivery(uuid, uuid, date) to authenticated;
grant execute on function public.update_delivery(jsonb) to authenticated;
grant execute on function public.stock_adjust(uuid, text, integer, text, text, date) to authenticated;
grant execute on function public.find_customer_duplicates(text, text, uuid) to authenticated;
