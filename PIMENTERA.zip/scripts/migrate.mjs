// Applies versioned SQL migrations from supabase/migrations in order, once each.
// Usage: POSTGRES_URL_NON_POOLING=... node scripts/migrate.mjs
import { readdir, readFile } from 'node:fs/promises'
import path from 'node:path'
import pg from 'pg'

const url = process.env.POSTGRES_URL_NON_POOLING || process.env.POSTGRES_URL
if (!url) {
  console.error('Defina POSTGRES_URL_NON_POOLING para executar as migrações.')
  process.exit(1)
}

const client = new pg.Client({
  connectionString: url.replace(/[?&]sslmode=[^&]*/g, ''),
  ssl: { rejectUnauthorized: false },
})
await client.connect()
await client.query(`create table if not exists public.schema_migrations (
  version text primary key, applied_at timestamptz not null default now())`)
await client.query('alter table public.schema_migrations enable row level security')

const dir = path.resolve('supabase/migrations')
const files = (await readdir(dir)).filter((f) => f.endsWith('.sql')).sort()
const { rows } = await client.query('select version from public.schema_migrations')
const applied = new Set(rows.map((r) => r.version))

for (const file of files) {
  if (applied.has(file)) continue
  const sql = await readFile(path.join(dir, file), 'utf8')
  process.stdout.write(`Aplicando ${file}... `)
  try {
    await client.query('begin')
    await client.query(sql)
    await client.query('insert into public.schema_migrations (version) values ($1)', [file])
    await client.query('commit')
    console.log('ok')
  } catch (err) {
    await client.query('rollback')
    console.log('falhou')
    console.error(err.message)
    await client.end()
    process.exit(1)
  }
}
await client.end()
console.log('Migrações concluídas.')
