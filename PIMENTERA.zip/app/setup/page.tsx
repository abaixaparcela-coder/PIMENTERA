import { redirect } from 'next/navigation'
import { AuthFrame } from '@/components/crm/auth-frame'
import { AuthForm } from '@/components/crm/auth-form'
import { createFirstAdmin, hasAnyUser } from '@/app/login/actions'

export const metadata = { title: 'Configuração inicial' }

export default async function SetupPage() {
  if (await hasAnyUser()) redirect('/login')
  return (
    <AuthFrame
      title="Administrador inicial"
      subtitle="Esta tela só fica disponível enquanto não houver nenhum usuário cadastrado."
    >
      <AuthForm action={createFirstAdmin} mode="setup" />
    </AuthFrame>
  )
}
