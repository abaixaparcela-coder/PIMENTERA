'use server'

import { redirect } from 'next/navigation'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

export type AuthState = { error?: string } | undefined

const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email('Informe um e-mail válido.'),
  password: z.string().min(1, 'Informe a senha.'),
})

export async function signIn(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const parsed = loginSchema.safeParse({ email: formData.get('email'), password: formData.get('password') })
  if (!parsed.success) return { error: parsed.error.issues[0].message }

  const supabase = await createClient()
  const { data, error } = await supabase.auth.signInWithPassword(parsed.data)
  if (error) {
    if (error.status === 429) return { error: 'Muitas tentativas. Aguarde alguns minutos e tente novamente.' }
    if (error.code === 'email_not_confirmed') return { error: 'E-mail ainda não confirmado.' }
    if (error.status && error.status >= 500) {
      console.error('[auth] unexpected sign-in failure', error.message)
      return { error: 'Falha inesperada no login. Tente novamente.' }
    }
    return { error: 'E-mail ou senha inválidos.' }
  }

  const { data: profile } = await supabase.from('profiles').select('active, role').eq('id', data.user.id).single()
  if (!profile?.active) {
    await supabase.auth.signOut()
    return { error: 'Conta inativa. Procure o administrador do sistema.' }
  }
  redirect(profile.role === 'entregador' ? '/minhas-entregas' : '/')
}

export async function signOut() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  redirect('/login')
}

const setupSchema = z.object({
  full_name: z.string().trim().min(3, 'Informe o nome completo.').max(120),
  email: z.string().trim().toLowerCase().email('Informe um e-mail válido.'),
  password: z.string().min(10, 'A senha deve ter ao menos 10 caracteres.').max(72),
})

export async function hasAnyUser() {
  const admin = createAdminClient()
  const { count } = await admin.from('profiles').select('id', { count: 'exact', head: true })
  return (count ?? 0) > 0
}

/** One-time bootstrap: creates the first administrator. Disabled once any profile exists. */
export async function createFirstAdmin(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const parsed = setupSchema.safeParse({
    full_name: formData.get('full_name'),
    email: formData.get('email'),
    password: formData.get('password'),
  })
  if (!parsed.success) return { error: parsed.error.issues[0].message }
  if (await hasAnyUser()) return { error: 'O administrador inicial já foi criado.' }

  const admin = createAdminClient()
  const { error } = await admin.auth.admin.createUser({
    email: parsed.data.email,
    password: parsed.data.password,
    email_confirm: true,
    user_metadata: { full_name: parsed.data.full_name },
  })
  if (error) {
    console.error('[setup] createUser failed', error.message)
    return { error: error.message.includes('Password') ? 'Senha fraca. Use letras, números e símbolos.' : 'Não foi possível criar o administrador.' }
  }

  const supabase = await createClient()
  await supabase.auth.signInWithPassword({ email: parsed.data.email, password: parsed.data.password })
  redirect('/')
}
