import Link from 'next/link'
import { redirect } from 'next/navigation'
import { AuthFrame } from '@/components/crm/auth-frame'
import { AuthForm } from '@/components/crm/auth-form'
import { getProfile } from '@/lib/auth'
import { hasAnyUser, signIn } from './actions'

export const metadata = { title: 'Entrar' }

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ inativo?: string }> }) {
  const [{ inativo }, profile, anyUser] = await Promise.all([searchParams, getProfile(), hasAnyUser()])
  if (profile?.active) redirect('/')

  return (
    <AuthFrame title="Entrar" subtitle="Acesso restrito a colaboradores autorizados.">
      {inativo ? (
        <p className="rounded-md border border-mustard/60 bg-mustard/20 px-3 py-2 text-sm">
          Sua conta está inativa. Procure o administrador.
        </p>
      ) : null}
      <AuthForm action={signIn} mode="login" />
      {!anyUser ? (
        <p className="text-sm text-muted-foreground">
          Primeiro acesso ao sistema?{' '}
          <Link href="/setup" className="font-medium text-primary underline-offset-4 hover:underline">
            Criar administrador inicial
          </Link>
        </p>
      ) : (
        <p className="text-xs text-muted-foreground">Esqueceu a senha? Solicite a redefinição ao administrador.</p>
      )}
    </AuthFrame>
  )
}
