import Link from 'next/link'
import { MapPin, Phone } from 'lucide-react'
import { EmptyState, PageHeader, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { DELIVERY_STATUS_LABEL, deliveryTone } from '@/lib/constants'
import { date, deliveryNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Minhas entregas' }

export default async function MyDeliveriesPage() {
  const profile = await requireModule('minhas-entregas')
  const supabase = await createClient()
  const { data: rows } = await supabase
    .from('deliveries')
    .select('id, number, status, customer_name, address, contact, scheduled_date')
    .eq('driver_id', profile.id)
    .in('status', ['pronta', 'em_rota', 'reagendada'])
    .order('scheduled_date', { ascending: true, nullsFirst: false })

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-4">
      <PageHeader title="Minhas entregas" description="Somente entregas atribuídas a você." />
      {!rows?.length ? (
        <EmptyState title="Nenhuma entrega pendente" description="Quando a expedição atribuir uma entrega a você, ela aparecerá aqui." />
      ) : (
        <ul className="flex flex-col gap-3">
          {rows.map((d) => (
            <li key={d.id}>
              <Link href={`/entregas/${d.id}`} className="flex flex-col gap-2 rounded-lg border border-border bg-card p-4 transition-colors hover:border-primary">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs font-semibold">{deliveryNumber(d.number)}</span>
                  <StatusBadge tone={deliveryTone(d.status)}>{DELIVERY_STATUS_LABEL[d.status]}</StatusBadge>
                </div>
                <p className="font-heading text-base font-semibold">{d.customer_name}</p>
                <p className="flex items-start gap-1.5 text-sm text-muted-foreground">
                  <MapPin className="mt-0.5 size-4 shrink-0" aria-hidden /> {d.address}
                </p>
                {d.contact ? (
                  <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Phone className="size-4 shrink-0" aria-hidden /> {d.contact}
                  </p>
                ) : null}
                <p className="text-xs">Prevista: {date(d.scheduled_date)}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
