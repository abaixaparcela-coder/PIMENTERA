import { notFound } from 'next/navigation'
import { PickingForm } from '@/components/crm/picking-form'
import { PrintButton } from '@/components/crm/print-button'
import { PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { ORDER_STATUS_LABEL, orderTone } from '@/lib/constants'
import { date, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Lista de separação' }

export default async function PickingPage({ params }: { params: Promise<{ id: string }> }) {
  await requireModule('expedicao')
  const { id } = await params
  const supabase = await createClient()
  const { data: order } = await supabase.from('orders').select('id, number, status, customer_snapshot, delivery_address, expected_delivery').eq('id', id).maybeSingle()
  if (!order) notFound()
  const { data: items } = await supabase
    .from('order_items')
    .select('id, sku, product_name, quantity, picked_qty, lot, product:products(stock_physical)')
    .eq('order_id', id)
    .order('position')
  const c = order.customer_snapshot as { trade_name?: string; legal_name?: string }
  const rows = (items ?? []).map((i) => ({ ...i, physical: (i.product as unknown as { stock_physical: number } | null)?.stock_physical ?? 0 }))

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title={`Separação — ${orderNumber(order.number)}`}
        description={`${c.trade_name || c.legal_name} · entrega prevista ${date(order.expected_delivery)}`}
        actions={
          <>
            <StatusBadge tone={orderTone(order.status)}>{ORDER_STATUS_LABEL[order.status]}</StatusBadge>
            <PrintButton label="Imprimir lista" />
          </>
        }
      />
      <Panel title="Itens a separar">
        {order.status === 'em_separacao' ? (
          <PickingForm orderId={order.id} rows={rows} />
        ) : (
          <p className="text-sm text-muted-foreground">O pedido não está em separação. Inicie a separação pela tela do pedido.</p>
        )}
      </Panel>
      <p className="text-xs text-muted-foreground">Endereço de entrega: {order.delivery_address || '—'}</p>
    </div>
  )
}
