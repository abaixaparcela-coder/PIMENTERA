import Link from 'next/link'
import { CreateDeliveryButton } from '@/components/crm/create-delivery-button'
import { DataTable, EmptyState, PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { ORDER_STATUS_LABEL, orderTone } from '@/lib/constants'
import { date, num, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Separação e expedição' }

export default async function ExpedicaoPage() {
  const profile = await requireModule('expedicao')
  const supabase = await createClient()
  const [{ data: orders }, { data: drivers }] = await Promise.all([
    supabase
      .from('orders')
      .select('id, number, status, expected_delivery, customer_snapshot, items:order_items(quantity, picked_qty, delivered_qty)')
      .in('status', ['aguardando_estoque', 'aprovado', 'em_separacao', 'separado', 'faturado', 'entrega_parcial', 'entrega_nao_realizada'])
      .order('expected_delivery', { ascending: true, nullsFirst: false }),
    supabase.from('profiles').select('id, full_name').eq('role', 'entregador').eq('active', true).order('full_name'),
  ])
  const canAct = ['admin', 'estoque'].includes(profile.role)
  const groups = [
    { title: 'Para separar', statuses: ['aguardando_estoque', 'aprovado', 'em_separacao'] },
    { title: 'Separados (aguardando liberação ao faturamento)', statuses: ['separado'] },
    { title: 'Faturados — criar entrega', statuses: ['faturado', 'entrega_parcial', 'entrega_nao_realizada'] },
  ]
  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Separação e expedição" description="Pedidos aprovados com estoque reservado, conferência e preparação das entregas." />
      {groups.map((g) => {
        const list = (orders ?? []).filter((o) => g.statuses.includes(o.status))
        return (
          <Panel key={g.title} title={`${g.title} (${list.length})`}>
            {!list.length ? (
              <EmptyState title="Nada pendente" />
            ) : (
              <DataTable>
                <thead>
                  <tr>
                    <th>Pedido</th>
                    <th>Cliente</th>
                    <th className="text-right">Unidades</th>
                    <th className="text-right">Pendente entrega</th>
                    <th>Previsão</th>
                    <th>Status</th>
                    <th className="text-right">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((o) => {
                    const c = o.customer_snapshot as { trade_name?: string; legal_name?: string; city?: string }
                    const its = (o.items ?? []) as { quantity: number; picked_qty: number; delivered_qty: number }[]
                    const units = its.reduce((s, i) => s + i.quantity, 0)
                    const pending = its.reduce((s, i) => s + Math.max(0, i.picked_qty - i.delivered_qty), 0)
                    return (
                      <tr key={o.id}>
                        <td>
                          <Link href={`/pedidos/${o.id}`} className="font-mono text-xs font-semibold hover:underline">
                            {orderNumber(o.number)}
                          </Link>
                        </td>
                        <td>
                          {c.trade_name || c.legal_name} <span className="text-xs text-muted-foreground">{c.city}</span>
                        </td>
                        <td className="text-right tabular-nums">{num(units)}</td>
                        <td className="text-right tabular-nums">{num(pending)}</td>
                        <td>{date(o.expected_delivery)}</td>
                        <td>
                          <StatusBadge tone={orderTone(o.status)}>{ORDER_STATUS_LABEL[o.status]}</StatusBadge>
                        </td>
                        <td className="text-right">
                          {!canAct ? null : o.status === 'em_separacao' ? (
                            <Link href={`/expedicao/${o.id}`} className="text-sm font-medium text-primary hover:underline">
                              Separar
                            </Link>
                          ) : ['faturado', 'entrega_parcial', 'entrega_nao_realizada'].includes(o.status) ? (
                            <CreateDeliveryButton orderId={o.id} drivers={drivers ?? []} defaultDate={o.expected_delivery} />
                          ) : (
                            <Link href={`/pedidos/${o.id}`} className="text-sm font-medium text-primary hover:underline">
                              Abrir
                            </Link>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </DataTable>
            )}
          </Panel>
        )
      })}
    </div>
  )
}
