import { AppShell } from '@/components/crm/app-shell'
import { requireProfile } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'
import { todayISO } from '@/lib/format'

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireProfile()
  const supabase = await createClient()
  const today = todayISO()
  const r = profile.role
  const notes: { label: string; href: string; count: number }[] = []

  const tasks: Promise<void>[] = []
  const add = (label: string, href: string, q: PromiseLike<{ count: number | null }>) =>
    tasks.push(
      Promise.resolve(q).then(({ count }) => {
        if (count) notes.push({ label, href, count })
      }),
    )

  if (['admin', 'gerente'].includes(r))
    add('Pedidos aguardando aprovação', '/pedidos?status=aguardando_aprovacao', supabase.from('orders').select('id', { count: 'exact', head: true }).eq('status', 'aguardando_aprovacao'))
  if (['admin', 'estoque'].includes(r)) {
    add('Pedidos para separar', '/expedicao', supabase.from('orders').select('id', { count: 'exact', head: true }).in('status', ['aprovado', 'em_separacao']))
    add('Pedidos aguardando estoque', '/pedidos?status=aguardando_estoque', supabase.from('orders').select('id', { count: 'exact', head: true }).eq('status', 'aguardando_estoque'))
  }
  if (['admin', 'faturamento'].includes(r)) {
    add('Pedidos para faturar', '/faturamento', supabase.from('orders').select('id', { count: 'exact', head: true }).eq('status', 'aguardando_faturamento'))
    add('Parcelas vencidas', '/financeiro?filtro=vencidas', supabase.from('receivable_installments').select('id', { count: 'exact', head: true }).in('status', ['pendente', 'parcial']).lt('due_date', today))
  }
  if (r === 'entregador')
    add('Entregas atribuídas', '/minhas-entregas', supabase.from('deliveries').select('id', { count: 'exact', head: true }).eq('driver_id', profile.id).in('status', ['pronta', 'em_rota', 'reagendada']))

  await Promise.all(tasks)

  return (
    <AppShell user={{ name: profile.full_name, email: profile.email, role: profile.role }} notifications={notes}>
      {children}
    </AppShell>
  )
}
