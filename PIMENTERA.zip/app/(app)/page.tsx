import Link from 'next/link'
import { redirect } from 'next/navigation'
import { FilterBar } from '@/components/crm/filter-bar'
import { BrandTag, DataTable, EmptyState, LinkButton, PageHeader, Panel } from '@/components/crm/ui'
import { canAccess, requireProfile } from '@/lib/auth'
import { ORDER_STATUS_LABEL } from '@/lib/constants'
import { loadDashboard } from '@/lib/dashboard'
import { addDaysISO, money, num, todayISO } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Painel' }

type SP = Promise<{ de?: string; ate?: string; marca?: string; vendedor?: string; status?: string }>

function Metric({ label, value, hint, href, tone }: { label: string; value: string; hint: string; href: string; tone?: 'warn' | 'bad' }) {
  return (
    <Link
      href={href}
      title={hint}
      className="group flex flex-col gap-1 rounded-md border border-border bg-card p-3 transition-colors hover:border-primary/50 hover:bg-accent/40"
    >
      <span className="text-xs text-muted-foreground">{label}</span>
      <span
        className={`font-mono text-lg font-semibold tabular-nums ${tone === 'bad' ? 'text-destructive' : tone === 'warn' ? 'text-foreground' : ''}`}
      >
        {value}
      </span>
      <span className="text-[11px] leading-snug text-muted-foreground">{hint}</span>
    </Link>
  )
}

export default async function DashboardPage({ searchParams }: { searchParams: SP }) {
  const profile = await requireProfile()
  if (profile.role === 'entregador') redirect('/minhas-entregas')
  const sp = await searchParams
  const today = todayISO()
  const f = { from: sp.de || addDaysISO(today, -29), to: sp.ate || today, brand: sp.marca, rep: sp.vendedor, status: sp.status }
  const supabase = await createClient()
  const [d, reps] = await Promise.all([
    loadDashboard(f),
    supabase.from('profiles').select('id, full_name').in('role', ['comercial', 'admin', 'gerente']).eq('active', true).order('full_name'),
  ])
  const period = `de=${f.from}&ate=${f.to}`
  const fin = canAccess(profile.role, 'financeiro')

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title={`Olá, ${profile.full_name.split(' ')[0] || 'bem-vindo'}`}
        description="Indicadores calculados a partir dos registros do banco. Clique em um indicador para ver os registros."
        actions={
          canAccess(profile.role, 'pedidos') && profile.role !== 'estoque' && profile.role !== 'faturamento' ? (
            <LinkButton href="/pedidos/novo">Novo pedido</LinkButton>
          ) : null
        }
      />
      <FilterBar
        filters={[
          { type: 'date', name: 'de', label: 'De', value: f.from },
          { type: 'date', name: 'ate', label: 'Até', value: f.to },
          { type: 'select', name: 'marca', label: 'Marca', value: f.brand, options: [{ value: 'pimentera', label: 'Pimentera' }, { value: 'mixx', label: 'Mixx' }] },
          ...(profile.role === 'comercial'
            ? []
            : [{ type: 'select' as const, name: 'vendedor', label: 'Vendedor', value: f.rep, options: (reps.data ?? []).map((r) => ({ value: r.id, label: r.full_name })) }]),
          { type: 'select', name: 'status', label: 'Status do pedido', value: f.status, options: Object.entries(ORDER_STATUS_LABEL).map(([value, label]) => ({ value, label })) },
        ]}
      />

      <section aria-label="Comercial" className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <Metric label="Vendas realizadas" value={money(d.soldValue)} hint="Total dos pedidos do período, exceto rascunhos e cancelados" href={`/pedidos?${period}`} />
        <Metric label="Pedidos criados" value={num(d.ordersCreated)} hint="Pedidos criados no período, exceto cancelados" href={`/pedidos?${period}`} />
        <Metric label="Ticket médio" value={money(d.avgTicket)} hint="Vendas realizadas ÷ pedidos vendidos" href={`/pedidos?${period}`} />
        <Metric label="Aguardando aprovação" value={num(d.awaitingApproval)} hint="Situação atual, sem filtro de período" href="/pedidos?status=aguardando_aprovacao" tone={d.awaitingApproval ? 'warn' : undefined} />
        <Metric label="Em separação" value={num(d.picking)} hint="Situação atual" href="/pedidos?status=em_separacao" />
        <Metric label="Aguardando faturamento" value={num(d.awaitingInvoice)} hint="Situação atual" href="/pedidos?status=aguardando_faturamento" />
        {fin ? (
          <>
            <Metric label="Valor faturado" value={money(d.invoiced)} hint="Documentos emitidos no período" href={`/faturamento?${period}`} />
            <Metric label="Valor recebido" value={money(d.received)} hint="Pagamentos registrados no período" href={`/financeiro?filtro=recebidos&${period}`} />
            <Metric label="Contas a receber" value={money(d.receivable)} hint="Saldo em aberto de todas as parcelas" href="/financeiro" />
            <Metric label="Contas vencidas" value={money(d.overdue)} hint="Saldo de parcelas com vencimento anterior a hoje" href="/financeiro?filtro=vencidas" tone={d.overdue ? 'bad' : undefined} />
          </>
        ) : null}
        <Metric label="Entregas pendentes" value={num(d.deliveriesPending)} hint="Entregas não concluídas nem recusadas" href="/entregas" />
        <Metric label="Entregas atrasadas" value={num(d.deliveriesLate)} hint="Pendentes com data prevista anterior a hoje" href="/entregas?atrasadas=1" tone={d.deliveriesLate ? 'bad' : undefined} />
        <Metric label="Estoque baixo" value={num(d.lowStock)} hint="Disponível menor ou igual ao estoque mínimo" href="/estoque?baixo=1" tone={d.lowStock ? 'warn' : undefined} />
        <Metric label="Clientes novos" value={num(d.newCustomers)} hint="Cadastrados no período" href={`/clientes?${period}`} />
        <Metric label="Sem compras recentes" value={num(d.inactiveBuyers)} hint="Clientes ativos sem pedido nos últimos 60 dias" href="/clientes?sem_compra=1" />
      </section>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="Produtos mais vendidos" className="lg:col-span-2">
          {d.topProducts.length === 0 ? (
            <EmptyState title="Sem vendas no período" description="Os produtos aparecem aqui quando houver pedidos enviados." />
          ) : (
            <DataTable>
              <thead>
                <tr>
                  <th>Produto</th>
                  <th>Marca</th>
                  <th className="text-right">Qtd.</th>
                  <th className="text-right">Valor</th>
                </tr>
              </thead>
              <tbody>
                {d.topProducts.map((p) => (
                  <tr key={p.sku}>
                    <td>
                      <span className="font-mono text-xs text-muted-foreground">{p.sku}</span> {p.name}
                    </td>
                    <td>
                      <BrandTag code={p.brand} />
                    </td>
                    <td className="text-right font-mono tabular-nums">{num(p.qty)}</td>
                    <td className="text-right font-mono tabular-nums">{money(p.value)}</td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          )}
        </Panel>
        <Panel title="Vendas por marca">
          <div className="flex flex-col gap-4">
            {(['pimentera', 'mixx'] as const).map((b) => {
              const total = d.byBrand.pimentera + d.byBrand.mixx
              const pct = total ? Math.round((d.byBrand[b] / total) * 100) : 0
              return (
                <div key={b} className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <BrandTag code={b} />
                    <span className="font-mono tabular-nums">{money(d.byBrand[b])}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted" role="img" aria-label={`${pct}% das vendas`}>
                    <div className={`h-full ${b === 'pimentera' ? 'bg-primary' : 'bg-foreground'}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              )
            })}
            <p className="text-xs text-muted-foreground">Soma dos itens dos pedidos vendidos no período.</p>
          </div>
        </Panel>
      </div>
    </div>
  )
}
