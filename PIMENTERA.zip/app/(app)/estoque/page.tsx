import Link from 'next/link'
import { StockMoveForm } from '@/components/crm/stock-move-form'
import { BrandTag, DataTable, LinkButton, PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { addDaysISO, date, dateTime, num, orderNumber, todayISO } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Estoque' }

const MOVE_LABEL: Record<string, string> = {
  entrada: 'Entrada',
  saida: 'Saída',
  ajuste: 'Ajuste',
  reserva: 'Reserva',
  liberacao: 'Liberação',
  estorno: 'Estorno',
}

export default async function StockPage({ searchParams }: { searchParams: Promise<{ produto?: string; marca?: string }> }) {
  const profile = await requireModule('estoque')
  const sp = await searchParams
  const supabase = await createClient()
  let pq = supabase.from('products').select('id, sku, name, net_content, stock_physical, stock_reserved, stock_min, active, brand_id, brand:brands(code)').order('brand_id').order('name')
  if (sp.marca) pq = pq.eq('brand_id', sp.marca === 'pimentera' ? 1 : 2)
  const [{ data: products }, { data: moves }, { data: lots }] = await Promise.all([
    pq,
    supabase
      .from('inventory_movements')
      .select('id, type, quantity, physical_after, lot, reason, created_at, product:products(sku, name), order:orders(id, number), user:profiles(full_name)')
      .order('created_at', { ascending: false })
      .limit(40),
    supabase
      .from('inventory_lots')
      .select('id, lot, expiry_date, quantity, product:products(sku, name)')
      .gt('quantity', 0)
      .not('expiry_date', 'is', null)
      .lte('expiry_date', addDaysISO(todayISO(), 90))
      .order('expiry_date'),
  ])
  const canMove = profile.role === 'admin' || profile.role === 'estoque'
  const all = products ?? []
  const totals = all.reduce(
    (a, p) => {
      a.physical += p.stock_physical
      a.reserved += p.stock_reserved
      if (p.stock_physical - p.stock_reserved <= p.stock_min) a.low++
      return a
    },
    { physical: 0, reserved: 0, low: 0 },
  )

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Estoque"
        description="Físico = unidades em depósito. Reservado = comprometido com pedidos aprovados. Disponível = físico − reservado."
        actions={
          <>
            <LinkButton href="/api/export/estoque" variant="outline">
              Exportar estoque
            </LinkButton>
            <LinkButton href="/api/export/movimentacoes" variant="outline">
              Exportar movimentações
            </LinkButton>
          </>
        }
      />
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-md border border-border bg-card p-3">
          <p className="text-xs text-muted-foreground">Unidades físicas</p>
          <p className="text-xl font-semibold tabular-nums">{num(totals.physical)}</p>
        </div>
        <div className="rounded-md border border-border bg-card p-3">
          <p className="text-xs text-muted-foreground">Reservadas</p>
          <p className="text-xl font-semibold tabular-nums">{num(totals.reserved)}</p>
        </div>
        <div className="rounded-md border border-border bg-card p-3">
          <p className="text-xs text-muted-foreground">Itens abaixo do mínimo</p>
          <p className={`text-xl font-semibold tabular-nums ${totals.low ? 'text-destructive' : ''}`}>{num(totals.low)}</p>
        </div>
      </div>

      {canMove ? (
        <Panel title="Registrar movimentação">
          <StockMoveForm
            defaultProduct={sp.produto}
            products={all.filter((p) => p.active).map((p) => ({ id: p.id, label: `${p.sku} — ${p.name} ${p.net_content ?? ''}` }))}
          />
        </Panel>
      ) : null}

      <Panel
        title="Saldos por produto"
        actions={
          <div className="flex gap-2 text-xs">
            <Link href="/estoque" className={!sp.marca ? 'font-semibold underline' : 'hover:underline'}>
              Todos
            </Link>
            <Link href="/estoque?marca=pimentera" className={sp.marca === 'pimentera' ? 'font-semibold underline' : 'hover:underline'}>
              Pimentera
            </Link>
            <Link href="/estoque?marca=mixx" className={sp.marca === 'mixx' ? 'font-semibold underline' : 'hover:underline'}>
              Mixx
            </Link>
          </div>
        }
      >
        <DataTable>
          <thead>
            <tr>
              <th>SKU</th>
              <th>Produto</th>
              <th>Marca</th>
              <th className="text-right">Físico</th>
              <th className="text-right">Reservado</th>
              <th className="text-right">Disponível</th>
              <th className="text-right">Mínimo</th>
              <th>Alerta</th>
            </tr>
          </thead>
          <tbody>
            {all.map((p) => {
              const avail = p.stock_physical - p.stock_reserved
              return (
                <tr key={p.id}>
                  <td className="font-mono text-xs">{p.sku}</td>
                  <td>
                    <Link href={`/produtos/${p.id}`} className="hover:text-primary hover:underline">
                      {p.name} <span className="text-muted-foreground">{p.net_content}</span>
                    </Link>
                  </td>
                  <td>
                    <BrandTag code={(p.brand as unknown as { code: string } | null)?.code ?? ''} />
                  </td>
                  <td className="text-right tabular-nums">{num(p.stock_physical)}</td>
                  <td className="text-right tabular-nums">{num(p.stock_reserved)}</td>
                  <td className="text-right font-medium tabular-nums">{num(avail)}</td>
                  <td className="text-right tabular-nums">{num(p.stock_min)}</td>
                  <td>{avail <= 0 ? <StatusBadge tone="bad">Sem saldo</StatusBadge> : avail <= p.stock_min ? <StatusBadge tone="warn">Baixo</StatusBadge> : null}</td>
                </tr>
              )
            })}
          </tbody>
        </DataTable>
      </Panel>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Panel title="Lotes vencendo em até 90 dias">
          {(lots ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum lote próximo do vencimento.</p>
          ) : (
            <ul className="flex flex-col divide-y divide-border text-sm">
              {lots!.map((l) => {
                const prod = l.product as unknown as { sku: string; name: string } | null
                return (
                  <li key={l.id} className="flex items-center justify-between gap-2 py-2">
                    <span>
                      {prod?.name} <span className="font-mono text-xs text-muted-foreground">{l.lot}</span>
                    </span>
                    <span className={`tabular-nums ${l.expiry_date! < todayISO() ? 'text-destructive' : ''}`}>
                      {date(l.expiry_date)} · {num(l.quantity)}
                    </span>
                  </li>
                )
              })}
            </ul>
          )}
        </Panel>
        <Panel title="Últimas movimentações" className="xl:col-span-2">
          {(moves ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhuma movimentação registrada ainda.</p>
          ) : (
            <DataTable>
              <thead>
                <tr>
                  <th>Data/hora</th>
                  <th>Produto</th>
                  <th>Tipo</th>
                  <th className="text-right">Qtd.</th>
                  <th className="text-right">Físico após</th>
                  <th>Motivo</th>
                  <th>Usuário</th>
                </tr>
              </thead>
              <tbody>
                {moves!.map((m) => {
                  const prod = m.product as unknown as { sku: string; name: string } | null
                  const ord = m.order as unknown as { id: string; number: number } | null
                  return (
                    <tr key={m.id}>
                      <td className="whitespace-nowrap">{dateTime(m.created_at)}</td>
                      <td>
                        <span className="font-mono text-xs">{prod?.sku}</span> {prod?.name}
                      </td>
                      <td>{MOVE_LABEL[m.type]}</td>
                      <td className="text-right tabular-nums">{num(m.quantity)}</td>
                      <td className="text-right tabular-nums">{num(m.physical_after)}</td>
                      <td>
                        {m.reason}
                        {ord ? (
                          <Link href={`/pedidos/${ord.id}`} className="ml-1 font-mono text-xs hover:underline">
                            {orderNumber(ord.number)}
                          </Link>
                        ) : null}
                        {m.lot ? <span className="ml-1 font-mono text-xs text-muted-foreground">lote {m.lot}</span> : null}
                      </td>
                      <td>{(m.user as unknown as { full_name: string } | null)?.full_name ?? '—'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </DataTable>
          )}
        </Panel>
      </div>
    </div>
  )
}
