import Link from 'next/link'
import { DataTable, EmptyState, Field, PageHeader, Panel, Select, TextInput } from '@/components/crm/ui'
import { PrintButton } from '@/components/crm/print-button'
import { requireModule } from '@/lib/auth'
import { money, num } from '@/lib/format'
import { REPORTS, reportRange, runReport, type Cell, type Column } from '@/lib/reports'

export const metadata = { title: 'Relatórios' }

function render(v: Cell, kind?: Column['kind']) {
  if (v === null || v === undefined || v === '') return '—'
  if (kind === 'money') return money(v)
  if (kind === 'int') return num(v)
  return String(v)
}

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ r?: string; de?: string; ate?: string; marca?: string }>
}) {
  await requireModule('relatorios')
  const sp = await searchParams
  const key = sp.r && REPORTS.some((r) => r.key === sp.r) ? sp.r : null
  const def = REPORTS.find((r) => r.key === key)
  const range = reportRange(sp)
  const report = key ? await runReport(key, sp) : null

  const qs = new URLSearchParams({ r: key ?? '', de: range.de, ate: range.ate, ...(sp.marca ? { marca: sp.marca } : {}) })

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Relatórios" description="Todos os relatórios consultam diretamente os registros salvos no banco." />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        <nav aria-label="Relatórios disponíveis" className="print:hidden">
          <Panel title="Escolha o relatório">
            <ul className="flex flex-col gap-1">
              {REPORTS.map((r) => (
                <li key={r.key}>
                  <Link
                    href={`/relatorios?r=${r.key}&de=${range.de}&ate=${range.ate}`}
                    aria-current={r.key === key ? 'page' : undefined}
                    className={`block rounded-md px-2 py-1.5 text-sm ${r.key === key ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}
                  >
                    {r.label}
                  </Link>
                </li>
              ))}
            </ul>
          </Panel>
        </nav>

        <div className="flex flex-col gap-4 lg:col-span-3">
          {!def ? (
            <EmptyState title="Selecione um relatório" description="Escolha um relatório na lista para visualizar, imprimir ou exportar em CSV." />
          ) : (
            <>
              <Panel title={def.label}>
                <p className="mb-3 text-sm text-muted-foreground">{def.description}</p>
                <form className="flex flex-wrap items-end gap-3 print:hidden" method="get">
                  <input type="hidden" name="r" value={def.key} />
                  {def.period && (
                    <>
                      <Field label="De" htmlFor="de">
                        <TextInput id="de" name="de" type="date" defaultValue={range.de} />
                      </Field>
                      <Field label="Até" htmlFor="ate">
                        <TextInput id="ate" name="ate" type="date" defaultValue={range.ate} />
                      </Field>
                    </>
                  )}
                  {['vendas_produto', 'estoque', 'sem_movimento'].includes(def.key) && (
                    <Field label="Marca" htmlFor="marca">
                      <Select id="marca" name="marca" defaultValue={sp.marca ?? ''}>
                        <option value="">Todas</option>
                        <option value="pimentera">Pimentera</option>
                        <option value="mixx">Mixx Condimentos</option>
                      </Select>
                    </Field>
                  )}
                  <button type="submit" className="h-9 rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground">
                    Aplicar
                  </button>
                  <a
                    href={`/relatorios/export?${qs.toString()}`}
                    className="inline-flex h-9 items-center rounded-md border border-border px-4 text-sm font-medium hover:bg-muted"
                  >
                    Exportar CSV
                  </a>
                  <PrintButton />
                </form>
                {def.period && (
                  <p className="mt-2 hidden text-sm print:block">
                    Período: {range.de.split('-').reverse().join('/')} a {range.ate.split('-').reverse().join('/')}
                  </p>
                )}
              </Panel>

              {report?.note && <p className="text-sm text-muted-foreground">{report.note}</p>}

              {report && report.rows.length ? (
                <DataTable>
                  <thead>
                    <tr>
                      {report.columns.map((c) => (
                        <th key={c.key} className={c.kind ? 'text-right' : undefined}>
                          {c.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {report.rows.map((row, i) => (
                      <tr key={i}>
                        {report.columns.map((c) => (
                          <td key={c.key} className={c.kind ? 'text-right tabular-nums' : undefined}>
                            {render(row[c.key], c.kind)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </DataTable>
              ) : (
                <EmptyState title="Nenhum registro encontrado" description="Não há dados salvos para os filtros selecionados." />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
