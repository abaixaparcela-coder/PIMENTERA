import { NextResponse, type NextRequest } from 'next/server'
import { canAccess, getProfile } from '@/lib/auth'
import { audit } from '@/lib/audit'
import { REPORTS, runReport, toCSV } from '@/lib/reports'

export async function GET(req: NextRequest) {
  const profile = await getProfile()
  if (!profile || !profile.active) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })
  if (!canAccess(profile.role, 'relatorios')) return NextResponse.json({ error: 'Sem permissão' }, { status: 403 })

  const sp = req.nextUrl.searchParams
  const key = sp.get('r') ?? ''
  if (!REPORTS.some((r) => r.key === key)) return NextResponse.json({ error: 'Relatório inválido' }, { status: 400 })

  const report = await runReport(key, {
    de: sp.get('de') ?? undefined,
    ate: sp.get('ate') ?? undefined,
    marca: sp.get('marca') ?? undefined,
  })
  if (!report) return NextResponse.json({ error: 'Relatório inválido' }, { status: 400 })

  await audit(profile.id, 'report.export', 'report', null, { report: key, rows: report.rows.length })

  return new NextResponse(toCSV(report), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="relatorio-${key}-${new Date().toISOString().slice(0, 10)}.csv"`,
      'Cache-Control': 'no-store',
    },
  })
}
