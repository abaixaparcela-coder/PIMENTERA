import Link from 'next/link'
import { DataTable, EmptyState, PageHeader, Panel } from '@/components/crm/ui'
import { VisitForm } from '@/components/crm/visit-form'
import { requireModule } from '@/lib/auth'
import { VISIT_RESULT_LABEL } from '@/lib/constants'
import { date, dateTime } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Visitas' }

export default async function VisitsPage() {
  await requireModule('visitas')
  const supabase = await createClient()
  const [visits, customers] = await Promise.all([
    supabase
      .from('visits')
      .select('id, visited_at, result, notes, next_action, next_action_date, rep:profiles(full_name), customer:customers(id, trade_name, legal_name, city)')
      .order('visited_at', { ascending: false })
      .limit(200),
    supabase.from('customers').select('id, trade_name, legal_name, city').neq('status', 'bloqueado').order('trade_name').limit(1000),
  ])

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Visitas comerciais" description="Registre o resultado de cada visita e a próxima ação combinada." />
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Panel title="Registrar visita">
          <VisitForm
            customers={(customers.data ?? []).map((c) => ({ id: c.id, name: `${c.trade_name || c.legal_name}${c.city ? ` — ${c.city}` : ''}` }))}
          />
        </Panel>
        <div className="xl:col-span-2">
          {visits.data?.length ? (
            <DataTable>
              <thead>
                <tr>
                  <th>Data</th>
                  <th>Cliente</th>
                  <th>Representante</th>
                  <th>Resultado</th>
                  <th>Próxima ação</th>
                </tr>
              </thead>
              <tbody>
                {visits.data.map((v) => {
                  const cu = v.customer as unknown as { id: string; trade_name: string | null; legal_name: string }
                  return (
                    <tr key={v.id}>
                      <td className="whitespace-nowrap">{dateTime(v.visited_at)}</td>
                      <td>
                        <Link href={`/clientes/${cu.id}`} className="hover:underline">
                          {cu.trade_name || cu.legal_name}
                        </Link>
                        {v.notes ? <div className="max-w-xs truncate text-xs text-muted-foreground">{v.notes}</div> : null}
                      </td>
                      <td>{(v.rep as unknown as { full_name: string } | null)?.full_name}</td>
                      <td>{VISIT_RESULT_LABEL[v.result]}</td>
                      <td>
                        {v.next_action ?? '—'}
                        {v.next_action_date ? <div className="text-xs text-muted-foreground">{date(v.next_action_date)}</div> : null}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </DataTable>
          ) : (
            <EmptyState title="Nenhuma visita registrada" description="Use o formulário para registrar a primeira visita." />
          )}
        </div>
      </div>
    </div>
  )
}
