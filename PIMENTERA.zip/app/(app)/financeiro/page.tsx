import Link from 'next/link'
import { PaymentForm } from '@/components/crm/payment-form'
import { DataTable, EmptyState, PageHeader, Panel, Select, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { RECEIVABLE_STATUS_LABEL, receivableTone } from '@/lib/constants'
import { date, money, orderNumber, todayISO } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Contas a receber' }

type Row = {
  id: string
  number: number
  due_date: string
  amount: number
  interest: number
  discount: number
  paid_amount: number
  status: string
  receivable: {
    id: string
    payment_method: string | null
    customer: { id: string; trade_name: string | null; legal_name: string } | null
    order: { id: string; number: number } | null
    invoice: { doc_type: string; number: string } | null
  } | null
}

const balanceOf = (r: Row) => Math.max(0, Number(r.amount) + Number(r.interest) - Number(r.discount) - Number(r.paid_amount))

export default async function FinanceiroPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const profile = await requireModule('financeiro')
  const canWrite = ['admin', 'faturamento'].includes(profile.role)
  const sp = await searchParams
  const filter = sp.status ?? 'abertas'
  const today = todayISO()
  const supabase = await createClient()

  let q = supabase
    .from('receivable_installments')
    .select(
      'id, number, due_date, amount, interest, discount, paid_amount, status, receivable:receivables(id, payment_method, customer:customers(id, trade_name, legal_name), order:orders(id, number), invoice:invoices(doc_type, number))',
    )
    .order('due_date')
    .limit(500)
  if (filter === 'abertas') q = q.in('status', ['pendente', 'parcial'])
  else if (filter === 'vencidas') q = q.in('status', ['pendente', 'parcial']).lt('due_date', today)
  else if (filter === 'a_vencer') q = q.in('status', ['pendente', 'parcial']).gte('due_date', today)
  else if (filter in RECEIVABLE_STATUS_LABEL) q = q.eq('status', filter)

  const [{ data }, { data: methods }, { data: todayPays }, { data: openAll }] = await Promise.all([
    q,
    supabase.from('payment_methods').select('name').eq('active', true).order('name'),
    supabase.from('payments').select('amount').eq('paid_at', today),
    supabase.from('receivable_installments').select('amount, interest, discount, paid_amount, due_date').in('status', ['pendente', 'parcial']),
  ])
  const rows = (data ?? []) as unknown as Row[]
  const methodNames = (methods ?? []).map((m) => m.name)
  const openRows = (openAll ?? []) as unknown as Row[]
  const totalOpen = openRows.reduce((s, r) => s + balanceOf(r), 0)
  const totalOverdue = openRows.filter((r) => r.due_date < today).reduce((s, r) => s + balanceOf(r), 0)
  const receivedToday = (todayPays ?? []).reduce((s, p) => s + Number(p.amount), 0)

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Contas a receber"
        description="Parcelas geradas no faturamento. Recebimentos só são registrados por baixa manual."
        actions={
          <form className="flex gap-2">
            <Select name="status" defaultValue={filter} aria-label="Filtro" className="w-44">
              <option value="abertas">Em aberto</option>
              <option value="vencidas">Vencidas</option>
              <option value="a_vencer">A vencer</option>
              <option value="pago">Pagas</option>
              <option value="cancelado">Canceladas</option>
              <option value="todas">Todas</option>
            </Select>
            <button className="h-9 rounded-md bg-foreground px-3 text-sm font-medium text-background">Filtrar</button>
          </form>
        }
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Saldo em aberto" value={money(totalOpen)} />
        <Stat label="Vencido" value={money(totalOverdue)} danger={totalOverdue > 0} />
        <Stat label="Recebido hoje" value={money(receivedToday)} />
      </div>
      {!rows.length ? (
        <EmptyState title="Nenhuma parcela" description="Parcelas são criadas automaticamente ao registrar o faturamento de um pedido." />
      ) : (
        <Panel>
          <DataTable>
            <thead>
              <tr>
                <th>Vencimento</th>
                <th>Cliente</th>
                <th>Pedido / Doc.</th>
                <th>Parc.</th>
                <th className="text-right">Valor</th>
                <th className="text-right">Recebido</th>
                <th className="text-right">Saldo</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const bal = balanceOf(r)
                const overdue = ['pendente', 'parcial'].includes(r.status) && r.due_date < today
                const rc = r.receivable
                return (
                  <tr key={r.id} className="align-top">
                    <td className={overdue ? 'font-medium text-destructive' : ''}>{date(r.due_date)}</td>
                    <td>
                      {rc?.customer ? (
                        <Link className="underline underline-offset-2" href={`/clientes/${rc.customer.id}`}>
                          {rc.customer.trade_name || rc.customer.legal_name}
                        </Link>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td>
                      {rc?.order ? (
                        <Link className="underline underline-offset-2" href={`/pedidos/${rc.order.id}`}>
                          {orderNumber(rc.order.number)}
                        </Link>
                      ) : null}
                      {rc?.invoice ? <span className="block text-xs text-muted-foreground">{rc.invoice.doc_type} {rc.invoice.number}</span> : null}
                    </td>
                    <td>{r.number}</td>
                    <td className="text-right tabular-nums">{money(r.amount)}</td>
                    <td className="text-right tabular-nums">{money(r.paid_amount)}</td>
                    <td className="text-right font-medium tabular-nums">{money(bal)}</td>
                    <td>
                      <StatusBadge tone={overdue ? 'bad' : receivableTone(r.status)}>
                        {overdue ? 'Vencido' : (RECEIVABLE_STATUS_LABEL[r.status] ?? r.status)}
                      </StatusBadge>
                    </td>
                    <td>{canWrite && ['pendente', 'parcial'].includes(r.status) ? <PaymentForm installmentId={r.id} balance={bal} methods={methodNames} /> : null}</td>
                  </tr>
                )
              })}
            </tbody>
          </DataTable>
        </Panel>
      )}
    </div>
  )
}

function Stat({ label, value, danger }: { label: string; value: string; danger?: boolean }) {
  return (
    <div className="flex flex-col gap-1 rounded-lg border border-border bg-card p-4">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <span className={`text-xl font-semibold tabular-nums ${danger ? 'text-destructive' : ''}`}>{value}</span>
    </div>
  )
}
