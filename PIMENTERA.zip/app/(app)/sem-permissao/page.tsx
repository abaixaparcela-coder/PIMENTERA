import { EmptyState, LinkButton } from '@/components/crm/ui'

export const metadata = { title: 'Sem permissão' }

export default function NoPermissionPage() {
  return (
    <EmptyState
      title="Acesso não autorizado"
      description="Seu perfil não tem permissão para acessar este módulo. Se precisar de acesso, fale com o administrador."
      action={<LinkButton href="/">Voltar ao início</LinkButton>}
    />
  )
}
