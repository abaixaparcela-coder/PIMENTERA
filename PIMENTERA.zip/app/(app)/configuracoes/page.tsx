import { LogoUploadForm, PaymentMethodsEditor, PaymentTermsEditor, SettingsForm } from '@/components/crm/admin-forms'
import { LinkButton, PageHeader, Panel } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { getCompany } from '@/lib/company'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Configurações' }

export default async function ConfiguracoesPage() {
  await requireModule('configuracoes')
  const supabase = await createClient()
  const [{ company, logos }, { data: terms }, { data: methods }] = await Promise.all([
    getCompany(),
    supabase.from('payment_terms').select('id, name, days, active').order('name'),
    supabase.from('payment_methods').select('id, name, active').order('name'),
  ])
  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Configurações"
        description="Dados da empresa, logos oficiais e cadastros auxiliares. Confirme os dados comerciais antes de imprimir pedidos."
        actions={<LinkButton href="/configuracoes/usuarios">Usuários e permissões</LinkButton>}
      />
      <Panel title="Dados da empresa">
        <SettingsForm s={(company ?? {}) as Record<string, string | number | null>} />
      </Panel>
      <Panel title="Logos oficiais" description="Usadas no cabeçalho dos pedidos impressos. Armazenadas em bucket privado.">
        <div className="grid gap-3 sm:grid-cols-2">
          <LogoUploadForm brand="pimentera" label="Pimentera Foods" current={logos.pimentera} />
          <LogoUploadForm brand="mixx" label="Mixx Condimentos" current={logos.mixx} />
        </div>
      </Panel>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Condições de pagamento" description="Os prazos geram as parcelas de contas a receber no faturamento.">
          <PaymentTermsEditor terms={terms ?? []} />
        </Panel>
        <Panel title="Formas de pagamento">
          <PaymentMethodsEditor methods={methods ?? []} />
        </Panel>
      </div>
    </div>
  )
}
