import { NewUserForm, UserRowForm } from '@/components/crm/admin-forms'
import { PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { MODULE_ROLES, ROLE_LABEL, type Role } from '@/lib/constants'
import { dateTime } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Usuários' }

const MODULE_LABEL: Record<string, string> = {
  dashboard: 'Painel',
  clientes: 'Clientes',
  visitas: 'Visitas / pedidos',
  produtos: 'Produtos',
  pedidos: 'Pedidos',
  estoque: 'Estoque',
  expedicao: 'Separação',
  faturamento: 'Faturamento',
  financeiro: 'Financeiro',
  entregas: 'Entregas',
  'minhas-entregas': 'Minhas entregas',
  relatorios: 'Relatórios',
  configuracoes: 'Configurações',
  auditoria: 'Auditoria',
}

export default async function UsuariosPage() {
  await requireModule('configuracoes')
  const supabase = await createClient()
  const { data: users } = await supabase
    .from('profiles')
    .select('id, full_name, email, phone, role, active, max_discount_pct, allow_negative_stock, created_at')
    .order('active', { ascending: false })
    .order('full_name')

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Usuários e permissões" description="Representantes, estoque, faturamento, entregadores e gerentes. Contas inativas perdem acesso imediatamente." />
      <Panel title="Novo usuário">
        <NewUserForm />
      </Panel>
      <Panel title={`Usuários (${users?.length ?? 0})`}>
        <ul className="flex flex-col divide-y divide-border">
          {(users ?? []).map((u) => (
            <li key={u.id} className="flex flex-col gap-2 py-4 first:pt-0">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <span className="font-medium">{u.email}</span>
                <StatusBadge tone={u.active ? 'ok' : 'neutral'}>{u.active ? 'Ativo' : 'Inativo'}</StatusBadge>
                <StatusBadge tone="info">{ROLE_LABEL[u.role as Role]}</StatusBadge>
                <span className="text-xs text-muted-foreground">desde {dateTime(u.created_at)}</span>
              </div>
              <UserRowForm user={u} />
            </li>
          ))}
        </ul>
      </Panel>
      <Panel title="Matriz de acesso por perfil" description="Aplicada no servidor (páginas e ações) e reforçada no banco por RLS e funções.">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground">
                <th className="py-2 pr-3 font-medium">Módulo</th>
                {Object.values(ROLE_LABEL).map((r) => (
                  <th key={r} className="px-2 py-2 text-center font-medium">
                    {r}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Object.entries(MODULE_ROLES).map(([mod, roles]) => (
                <tr key={mod} className="border-b border-border last:border-0">
                  <td className="py-1.5 pr-3">{MODULE_LABEL[mod] ?? mod}</td>
                  {(Object.keys(ROLE_LABEL) as Role[]).map((r) => (
                    <td key={r} className="px-2 py-1.5 text-center">
                      {roles.includes(r) ? <span aria-label="Permitido" className="font-semibold text-primary">●</span> : <span aria-label="Sem acesso" className="text-muted-foreground">–</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  )
}
