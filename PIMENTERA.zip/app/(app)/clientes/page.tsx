import Link from 'next/link'
import { FilterBar } from '@/components/crm/filter-bar'
import { DataTable, EmptyState, LinkButton, PageHeader, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { CHANNEL_LABEL, CUSTOMER_STATUS_LABEL } from '@/lib/constants'
import { addDaysISO, customerCode, date, doc, onlyDigits, phone, todayISO } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Clientes' }

type SP = Promise<{ q?: string; status?: string; canal?: string; de?: string; ate?: string; sem_compra?: string }>

export default async function CustomersPage({ searchParams }: { searchParams: SP }) {
  const profile = await requireModule('clientes')
  const sp = await searchParams
  const supabase = await createClient()
  let q = supabase
    .from('customers')
    .select('id, code, legal_name, trade_name, document, city, state, phone, whatsapp, channel, status, created_at, sales_rep:profiles!customers_sales_rep_id_fkey(full_name)')
    .order('trade_name', { ascending: true, nullsFirst: false })
    .limit(300)
  if (sp.status) q = q.eq('status', sp.status)
  if (sp.canal) q = q.eq('channel', sp.canal)
  if (sp.de) q = q.gte('created_at', `${sp.de}T00:00:00-03:00`)
  if (sp.ate) q = q.lte('created_at', `${sp.ate}T23:59:59-03:00`)
  const term = sp.q?.trim().replace(/[%,()]/g, ' ')
  if (term) {
    const digits = onlyDigits(term)
    const ors = [`legal_name.ilike.%${term}%`, `trade_name.ilike.%${term}%`, `city.ilike.%${term}%`]
    if (digits.length >= 3) ors.push(`document.ilike.%${digits}%`, `phone.ilike.%${digits}%`, `whatsapp.ilike.%${digits}%`)
    const codeMatch = term.match(/^(?:cli-?)?(\d{1,7})$/i)
    if (codeMatch) ors.push(`code.eq.${Number(codeMatch[1])}`)
    q = q.or(ors.join(','))
  }
  const { data, error } = await q
  let rows = data ?? []
  if (sp.sem_compra) {
    const { data: recent } = await supabase
      .from('orders')
      .select('customer_id')
      .gte('created_at', `${addDaysISO(todayISO(), -60)}T00:00:00-03:00`)
      .not('status', 'in', '(rascunho,cancelado)')
    const buyers = new Set((recent ?? []).map((r) => r.customer_id))
    rows = rows.filter((r) => r.status === 'ativo' && !buyers.has(r.id))
  }

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Clientes"
        description={profile.role === 'comercial' ? 'Sua carteira de clientes e prospects.' : 'Cadastro de clientes e prospects.'}
        actions={
          <>
            <LinkButton href={`/api/export/clientes`} variant="outline">
              Exportar CSV
            </LinkButton>
            {profile.role !== 'estoque' ? <LinkButton href="/clientes/novo">Novo cliente</LinkButton> : null}
          </>
        }
      />
      <FilterBar
        filters={[
          { type: 'text', name: 'q', label: 'Pesquisar', value: sp.q, placeholder: 'Nome, razão social, CNPJ/CPF, cidade, telefone ou código' },
          { type: 'select', name: 'status', label: 'Situação', value: sp.status, options: Object.entries(CUSTOMER_STATUS_LABEL).map(([value, label]) => ({ value, label })) },
          { type: 'select', name: 'canal', label: 'Canal', value: sp.canal, options: Object.entries(CHANNEL_LABEL).map(([value, label]) => ({ value, label })) },
        ]}
      />
      {sp.sem_compra ? <p className="text-sm text-muted-foreground">Mostrando clientes ativos sem pedidos nos últimos 60 dias.</p> : null}
      {error ? <p className="text-sm text-destructive">Erro ao carregar clientes: {error.message}</p> : null}
      {rows.length === 0 ? (
        <EmptyState
          title="Nenhum cliente encontrado"
          description="Ajuste os filtros ou cadastre um novo cliente."
          action={<LinkButton href="/clientes/novo">Cadastrar cliente</LinkButton>}
        />
      ) : (
        <DataTable>
          <thead>
            <tr>
              <th>Código</th>
              <th>Cliente</th>
              <th>Documento</th>
              <th>Cidade/UF</th>
              <th>Telefone</th>
              <th>Canal</th>
              <th>Vendedor</th>
              <th>Situação</th>
              <th>Cadastro</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id}>
                <td className="font-mono text-xs">{customerCode(c.code)}</td>
                <td>
                  <Link href={`/clientes/${c.id}`} className="font-medium hover:text-primary hover:underline">
                    {c.trade_name || c.legal_name}
                  </Link>
                  {c.trade_name ? <div className="text-xs text-muted-foreground">{c.legal_name}</div> : null}
                </td>
                <td className="font-mono text-xs">{doc(c.document) || '—'}</td>
                <td>{c.city ? `${c.city}/${c.state ?? ''}` : '—'}</td>
                <td className="whitespace-nowrap">{phone(c.whatsapp || c.phone) || '—'}</td>
                <td>{CHANNEL_LABEL[c.channel]}</td>
                <td>{(c.sales_rep as unknown as { full_name: string } | null)?.full_name ?? '—'}</td>
                <td>
                  <StatusBadge tone={c.status === 'ativo' ? 'ok' : c.status === 'bloqueado' ? 'bad' : c.status === 'prospect' ? 'info' : 'neutral'}>
                    {CUSTOMER_STATUS_LABEL[c.status]}
                  </StatusBadge>
                </td>
                <td>{date(c.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </DataTable>
      )}
    </div>
  )
}
