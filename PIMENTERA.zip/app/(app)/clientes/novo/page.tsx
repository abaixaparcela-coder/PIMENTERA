import { redirect } from 'next/navigation'
import { CustomerForm } from '@/components/crm/customer-form'
import { PageHeader } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Novo cliente' }

export default async function NewCustomerPage() {
  const profile = await requireModule('clientes')
  if (profile.role === 'estoque') redirect('/sem-permissao')
  const supabase = await createClient()
  const [reps, terms] = await Promise.all([
    supabase.from('profiles').select('id, full_name').in('role', ['comercial', 'admin', 'gerente']).eq('active', true).order('full_name'),
    supabase.from('payment_terms').select('id, name').eq('active', true).order('days'),
  ])
  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Novo cliente" description="Campos com * são obrigatórios. Prospects podem ser cadastrados sem documento." />
      <CustomerForm
        id={null}
        initial={{ status: 'prospect', channel: 'supermercado', sales_rep_id: profile.role === 'comercial' ? profile.id : null, brands: [] }}
        reps={reps.data ?? []}
        terms={terms.data ?? []}
        isComercial={profile.role === 'comercial'}
      />
    </div>
  )
}
