import { notFound, redirect } from 'next/navigation'
import { CustomerForm } from '@/components/crm/customer-form'
import { PageHeader } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { customerCode } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Editar cliente' }

export default async function EditCustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const profile = await requireModule('clientes')
  if (profile.role === 'estoque') redirect('/sem-permissao')
  const { id } = await params
  const supabase = await createClient()
  const [{ data: c }, reps, terms] = await Promise.all([
    supabase.from('customers').select('*').eq('id', id).maybeSingle(),
    supabase.from('profiles').select('id, full_name').in('role', ['comercial', 'admin', 'gerente']).eq('active', true).order('full_name'),
    supabase.from('payment_terms').select('id, name').eq('active', true).order('days'),
  ])
  if (!c) notFound()
  if (profile.role === 'comercial' && c.sales_rep_id !== profile.id) redirect('/sem-permissao')
  return (
    <div className="flex flex-col gap-4">
      <PageHeader title={`Editar ${c.trade_name || c.legal_name}`} description={customerCode(c.code)} />
      <CustomerForm id={id} initial={c} reps={reps.data ?? []} terms={terms.data ?? []} isComercial={profile.role === 'comercial'} />
    </div>
  )
}
