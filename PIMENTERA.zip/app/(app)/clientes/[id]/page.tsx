import Link from 'next/link'
import { notFound } from 'next/navigation'
import { PrintButton } from '@/components/crm/print-button'
import { DataTable, DefList, LinkButton, PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { VisitForm } from '@/components/crm/visit-form'
import { canAccess, requireModule } from '@/lib/auth'
import {
  BRAND_LABEL,
  CHANNEL_LABEL,
  CUSTOMER_STATUS_LABEL,
  DELIVERY_STATUS_LABEL,
  ORDER_STATUS_LABEL,
  RECEIVABLE_STATUS_LABEL,
  VISIT_RESULT_LABEL,
  deliveryTone,
  orderTone,
  receivableTone,
} from '@/lib/constants'
import { cep, customerCode, date, dateTime, deliveryNumber, doc, formatAddress, money, orderNumber, phone } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Ficha do cliente' }

export default async function CustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const profile = await requireModule('clientes')
  const { id } = await params
  const supabase = await createClient()
  const { data: c } = await supabase
    .from('customers')
    .select('*, sales_rep:profiles!customers_sales_rep_id_fkey(full_name), term:payment_terms(name)')
    .eq('id', id)
    .maybeSingle()
  if (!c) notFound()

  const fin = canAccess(profile.role, 'financeiro')
  const [visits, orders, deliveries, receivables] = await Promise.all([
    supabase.from('visits').select('id, visited_at, result, notes, next_action, next_action_date, rep:profiles(full_name)').eq('customer_id', id).order('visited_at', { ascending: false }).limit(50),
    supabase.from('orders').select('id, number, status, total, created_at').eq('customer_id', id).order('created_at', { ascending: false }).limit(50),
    supabase.from('deliveries').select('id, number, status, scheduled_date, completed_at, orders!inner(customer_id)').eq('orders.customer_id', id).order('created_at', { ascending: false }).limit(50),
    fin
      ? supabase.from('receivables').select('id, original_amount, status, issue_date, order:orders(number), receivable_installments(amount, interest, discount, paid_amount)').eq('customer_id', id).order('issue_date', { ascending: false }).limit(50)
      : Promise.resolve({ data: [] as never[] }),
  ])
  const rep = c.sales_rep as { full_name: string } | null
  const term = c.term as { name: string } | null
  const canEdit = profile.role !== 'estoque' && (profile.role !== 'comercial' || c.sales_rep_id === profile.id)
  const canVisit = ['admin', 'gerente', 'comercial'].includes(profile.role)

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title={c.trade_name || c.legal_name}
        description={`${customerCode(c.code)} · ${CHANNEL_LABEL[c.channel]} · cadastrado em ${date(c.created_at)}`}
        actions={
          <>
            <PrintButton label="Imprimir ficha" />
            {canEdit ? (
              <LinkButton href={`/clientes/${id}/editar`} variant="outline">
                Editar
              </LinkButton>
            ) : null}
            {canVisit && c.status !== 'bloqueado' ? <LinkButton href={`/pedidos/novo?cliente=${id}`}>Novo pedido</LinkButton> : null}
          </>
        }
      />

      <div className="print-only hidden border-b border-foreground pb-2 text-sm font-semibold">Ficha cadastral — CRM Pimentera + Mixx Condimentos</div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="Dados cadastrais" className="lg:col-span-2">
          <DefList
            items={[
              ['Situação', <StatusBadge key="s" tone={c.status === 'ativo' ? 'ok' : c.status === 'bloqueado' ? 'bad' : 'info'}>{CUSTOMER_STATUS_LABEL[c.status]}</StatusBadge>],
              ['Tipo', c.person_type === 'PJ' ? 'Pessoa jurídica' : 'Pessoa física'],
              ['Razão social / nome', c.legal_name],
              ['Nome fantasia', c.trade_name],
              [c.person_type === 'PJ' ? 'CNPJ' : 'CPF', doc(c.document)],
              ['Inscrição estadual', c.state_registration ? `${c.state_registration}${c.ie_indicator ? ` (${c.ie_indicator.replace('_', ' ')})` : ''}` : null],
              ['Comprador / responsável', c.buyer_name],
              ['Telefone', phone(c.phone)],
              ['WhatsApp', c.whatsapp ? <a key="w" className="underline underline-offset-2" href={`https://wa.me/55${c.whatsapp}`} target="_blank" rel="noreferrer">{phone(c.whatsapp)}</a> : null],
              ['E-mail', c.email],
              ['CEP', cep(c.cep)],
              ['Endereço', formatAddress(c)],
              ['Endereço de cobrança', c.billing_address || 'Mesmo do cadastro'],
              ['Endereço de entrega', c.delivery_address || 'Mesmo do cadastro'],
              ['Recebimento', [c.receiver_name, phone(c.receiver_phone)].filter(Boolean).join(' · ')],
            ]}
          />
        </Panel>
        <Panel title="Comercial">
          <DefList
            items={[
              ['Vendedor', rep?.full_name],
              ['Condição de pagamento', term?.name],
              ['Limite de crédito', c.credit_limit !== null ? money(c.credit_limit) : null],
              ['Marcas', (c.brands as string[]).map((b) => BRAND_LABEL[b]).join(', ')],
              ['Observações', c.commercial_notes],
            ]}
          />
        </Panel>
      </div>

      <Panel title={`Pedidos (${orders.data?.length ?? 0})`}>
        {orders.data?.length ? (
          <DataTable>
            <thead>
              <tr>
                <th>Pedido</th>
                <th>Data</th>
                <th>Status</th>
                <th className="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.data.map((o) => (
                <tr key={o.id}>
                  <td>
                    <Link className="font-mono hover:underline" href={`/pedidos/${o.id}`}>
                      {orderNumber(o.number)}
                    </Link>
                  </td>
                  <td>{date(o.created_at)}</td>
                  <td>
                    <StatusBadge tone={orderTone(o.status)}>{ORDER_STATUS_LABEL[o.status]}</StatusBadge>
                  </td>
                  <td className="text-right font-mono tabular-nums">{money(o.total)}</td>
                </tr>
              ))}
            </tbody>
          </DataTable>
        ) : (
          <p className="text-sm text-muted-foreground">Nenhum pedido registrado.</p>
        )}
      </Panel>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Visitas comerciais">
          <div className="flex flex-col gap-4">
            {canVisit ? (
              <div className="no-print rounded-md border border-border bg-muted/40 p-3">
                <VisitForm fixedCustomerId={id} />
              </div>
            ) : null}
            {visits.data?.length ? (
              <ol className="flex flex-col gap-3">
                {visits.data.map((v) => (
                  <li key={v.id} className="flex flex-col gap-0.5 border-l-2 border-primary/40 pl-3 text-sm">
                    <span className="text-xs text-muted-foreground">
                      {dateTime(v.visited_at)} · {(v.rep as unknown as { full_name: string } | null)?.full_name}
                    </span>
                    <span className="font-medium">{VISIT_RESULT_LABEL[v.result]}</span>
                    {v.notes ? <span className="text-pretty">{v.notes}</span> : null}
                    {v.next_action ? (
                      <span className="text-xs">
                        Próxima ação: {v.next_action}
                        {v.next_action_date ? ` em ${date(v.next_action_date)}` : ''}
                      </span>
                    ) : null}
                  </li>
                ))}
              </ol>
            ) : (
              <p className="text-sm text-muted-foreground">Nenhuma visita registrada.</p>
            )}
          </div>
        </Panel>
        <div className="flex flex-col gap-4">
          <Panel title="Entregas">
            {deliveries.data?.length ? (
              <ul className="flex flex-col gap-2 text-sm">
                {deliveries.data.map((d) => (
                  <li key={d.id} className="flex items-center justify-between gap-2">
                    <span className="font-mono">{deliveryNumber(d.number)}</span>
                    <span className="text-muted-foreground">{date(d.completed_at ?? d.scheduled_date)}</span>
                    <StatusBadge tone={deliveryTone(d.status)}>{DELIVERY_STATUS_LABEL[d.status]}</StatusBadge>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">Nenhuma entrega.</p>
            )}
          </Panel>
          {fin ? (
            <Panel title="Contas a receber">
              {receivables.data?.length ? (
                <ul className="flex flex-col gap-2 text-sm">
                  {receivables.data.map((r) => {
                    const inst = (r.receivable_installments ?? []) as { amount: number; interest: number; discount: number; paid_amount: number }[]
                    const open = inst.reduce((s, i) => s + Math.max(0, Number(i.amount) + Number(i.interest) - Number(i.discount) - Number(i.paid_amount)), 0)
                    return (
                      <li key={r.id} className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-mono">{orderNumber((r.order as unknown as { number: number }).number)}</span>
                        <span className="font-mono tabular-nums">
                          {money(r.original_amount)} · aberto {money(open)}
                        </span>
                        <StatusBadge tone={receivableTone(r.status)}>{RECEIVABLE_STATUS_LABEL[r.status]}</StatusBadge>
                      </li>
                    )
                  })}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">Nenhum título.</p>
              )}
            </Panel>
          ) : null}
        </div>
      </div>
    </div>
  )
}
