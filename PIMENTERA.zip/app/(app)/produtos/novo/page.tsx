import { redirect } from 'next/navigation'
import { ProductForm } from '@/components/crm/product-form'
import { PageHeader } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Novo produto' }

export default async function NewProductPage() {
  const profile = await requireModule('produtos')
  if (profile.role !== 'admin') redirect('/sem-permissao')
  const supabase = await createClient()
  const [{ data: brands }, { data: categories }, { data: units }] = await Promise.all([
    supabase.from('brands').select('id, name').order('id'),
    supabase.from('product_categories').select('id, name').order('name'),
    supabase.from('units').select('code, description').order('code'),
  ])
  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Novo produto" />
      <ProductForm initial={{ active: true, unit: 'UN', stock_min: 0 }} brands={brands ?? []} categories={categories ?? []} units={units ?? []} />
    </div>
  )
}
