import Link from 'next/link'
import { FilterBar } from '@/components/crm/filter-bar'
import { CsvImportForm } from '@/components/crm/csv-import-form'
import { BrandTag, DataTable, EmptyState, LinkButton, PageHeader, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { money, num } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Produtos' }

type SP = Promise<{ q?: string; marca?: string; situacao?: string; baixo?: string }>

export default async function ProductsPage({ searchParams }: { searchParams: SP }) {
  const profile = await requireModule('produtos')
  const sp = await searchParams
  const supabase = await createClient()
  let q = supabase
    .from('products')
    .select('id, sku, name, net_content, unit, price, min_price, cost, stock_physical, stock_reserved, stock_min, active, brand:brands(code), category:product_categories(name)')
    .order('brand_id')
    .order('name')
  if (sp.marca) q = q.eq('brand_id', sp.marca === 'pimentera' ? 1 : 2)
  if (sp.situacao) q = q.eq('active', sp.situacao === 'ativo')
  const term = sp.q?.trim().replace(/[%,()]/g, ' ')
  if (term) q = q.or(`name.ilike.%${term}%,sku.ilike.%${term}%,barcode.ilike.%${term}%`)
  const { data, error } = await q
  let rows = data ?? []
  if (sp.baixo) rows = rows.filter((p) => p.stock_physical - p.stock_reserved <= p.stock_min)
  const isAdmin = profile.role === 'admin'
  const showCost = isAdmin || profile.role === 'gerente'

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Produtos"
        description="Catálogo Pimentera e Mixx Condimentos. Preços e custos são definidos pelo administrador."
        actions={
          <>
            <LinkButton href="/api/export/produtos" variant="outline">
              Exportar CSV
            </LinkButton>
            {isAdmin ? <LinkButton href="/produtos/novo">Novo produto</LinkButton> : null}
          </>
        }
      />
      <FilterBar
        filters={[
          { type: 'text', name: 'q', label: 'Pesquisar', value: sp.q, placeholder: 'Nome, SKU ou código de barras' },
          { type: 'select', name: 'marca', label: 'Marca', value: sp.marca, options: [{ value: 'pimentera', label: 'Pimentera' }, { value: 'mixx', label: 'Mixx Condimentos' }] },
          { type: 'select', name: 'situacao', label: 'Situação', value: sp.situacao, options: [{ value: 'ativo', label: 'Ativo' }, { value: 'inativo', label: 'Inativo' }] },
          { type: 'select', name: 'baixo', label: 'Estoque', value: sp.baixo, options: [{ value: '1', label: 'Abaixo do mínimo' }] },
        ]}
      />
      {isAdmin ? <CsvImportForm /> : null}
      {error ? <p className="text-sm text-destructive">Erro ao carregar produtos: {error.message}</p> : null}
      {rows.length === 0 ? (
        <EmptyState title="Nenhum produto encontrado" description="Ajuste os filtros ou cadastre um produto." />
      ) : (
        <DataTable>
          <thead>
            <tr>
              <th>SKU</th>
              <th>Produto</th>
              <th>Marca</th>
              <th>Un.</th>
              {showCost ? <th className="text-right">Custo</th> : null}
              <th className="text-right">Preço</th>
              <th className="text-right">Mínimo</th>
              <th className="text-right">Físico</th>
              <th className="text-right">Reservado</th>
              <th className="text-right">Disponível</th>
              <th>Situação</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => {
              const avail = p.stock_physical - p.stock_reserved
              const low = avail <= p.stock_min
              const brand = (p.brand as unknown as { code: string } | null)?.code ?? ''
              return (
                <tr key={p.id}>
                  <td className="font-mono text-xs">{p.sku}</td>
                  <td>
                    <Link href={`/produtos/${p.id}`} className="font-medium hover:text-primary hover:underline">
                      {p.name}
                    </Link>
                    <div className="text-xs text-muted-foreground">{p.net_content}</div>
                  </td>
                  <td>
                    <BrandTag code={brand} />
                  </td>
                  <td>{p.unit}</td>
                  {showCost ? <td className="text-right tabular-nums">{p.cost === null ? '—' : money(p.cost)}</td> : null}
                  <td className="text-right tabular-nums">{p.price === null ? <span className="text-muted-foreground">sem preço</span> : money(p.price)}</td>
                  <td className="text-right tabular-nums">{p.min_price === null ? '—' : money(p.min_price)}</td>
                  <td className="text-right tabular-nums">{num(p.stock_physical)}</td>
                  <td className="text-right tabular-nums">{num(p.stock_reserved)}</td>
                  <td className={`text-right font-medium tabular-nums ${low ? 'text-destructive' : ''}`}>{num(avail)}</td>
                  <td>
                    <StatusBadge tone={p.active ? 'ok' : 'neutral'}>{p.active ? 'Ativo' : 'Inativo'}</StatusBadge>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </DataTable>
      )}
    </div>
  )
}
