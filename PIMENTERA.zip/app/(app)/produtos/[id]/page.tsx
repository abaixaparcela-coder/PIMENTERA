import { notFound } from 'next/navigation'
import { ProductForm } from '@/components/crm/product-form'
import { ProductImageUpload } from '@/components/crm/product-image-upload'
import { BrandTag, DataTable, DefList, LinkButton, PageHeader, Panel } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { date, dateTime, money, num } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Produto' }

const MOVE_LABEL: Record<string, string> = {
  entrada: 'Entrada',
  saida: 'Saída',
  ajuste: 'Ajuste',
  reserva: 'Reserva',
  liberacao: 'Liberação',
  estorno: 'Estorno',
}

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const profile = await requireModule('produtos')
  const { id } = await params
  const supabase = await createClient()
  const { data: p } = await supabase.from('products').select('*, brand:brands(code, name), category:product_categories(name)').eq('id', id).maybeSingle()
  if (!p) notFound()
  const isAdmin = profile.role === 'admin'
  const canStock = ['admin', 'gerente', 'estoque'].includes(profile.role)

  const [{ data: moves }, { data: lots }, catalog, imageUrl] = await Promise.all([
    canStock
      ? supabase.from('inventory_movements').select('id, type, quantity, physical_after, reserved_after, lot, reason, created_at, order:orders(number), user:profiles(full_name)').eq('product_id', id).order('created_at', { ascending: false }).limit(50)
      : Promise.resolve({ data: [] as never[] }),
    canStock ? supabase.from('inventory_lots').select('id, lot, expiry_date, quantity').eq('product_id', id).order('expiry_date') : Promise.resolve({ data: [] as never[] }),
    isAdmin
      ? Promise.all([
          supabase.from('brands').select('id, name').order('id'),
          supabase.from('product_categories').select('id, name').order('name'),
          supabase.from('units').select('code, description').order('code'),
        ])
      : null,
    p.image_path ? supabase.storage.from('arquivos').createSignedUrl(p.image_path, 3600).then((r) => r.data?.signedUrl ?? null) : Promise.resolve(null),
  ])
  const brand = p.brand as { code: string; name: string } | null

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title={p.name}
        description={`${p.sku} · ${p.net_content ?? ''}`}
        actions={canStock ? <LinkButton href={`/estoque?produto=${p.id}`} variant="outline">Movimentar estoque</LinkButton> : null}
      />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="Resumo" className="lg:col-span-2">
          <DefList
            items={[
              ['Marca', brand ? <BrandTag code={brand.code} /> : '—'],
              ['Categoria', (p.category as { name: string } | null)?.name ?? '—'],
              ['Preço de venda', p.price === null ? 'Não informado' : money(p.price)],
              ['Preço mínimo', p.min_price === null ? 'Não informado' : money(p.min_price)],
              ['Estoque físico', num(p.stock_physical)],
              ['Reservado', num(p.stock_reserved)],
              ['Disponível', num(p.stock_physical - p.stock_reserved)],
              ['Estoque mínimo', num(p.stock_min)],
            ]}
          />
        </Panel>
        <Panel title="Imagem">
          <div className="flex flex-col gap-3">
            {imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={imageUrl} alt={p.name} className="aspect-square w-full rounded-md border border-border object-contain" />
            ) : (
              <p className="flex aspect-square items-center justify-center rounded-md border border-dashed border-border text-sm text-muted-foreground">Sem imagem</p>
            )}
            {isAdmin ? <ProductImageUpload productId={p.id} /> : null}
          </div>
        </Panel>
      </div>

      {isAdmin && catalog ? (
        <ProductForm
          initial={p}
          brands={catalog[0].data ?? []}
          categories={catalog[1].data ?? []}
          units={catalog[2].data ?? []}
        />
      ) : null}

      {canStock ? (
        <>
          <Panel title="Lotes e validade">
            {(lots ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum lote registrado.</p>
            ) : (
              <DataTable>
                <thead>
                  <tr>
                    <th>Lote</th>
                    <th>Validade</th>
                    <th className="text-right">Quantidade</th>
                  </tr>
                </thead>
                <tbody>
                  {lots!.map((l) => (
                    <tr key={l.id}>
                      <td className="font-mono text-xs">{l.lot}</td>
                      <td>{date(l.expiry_date)}</td>
                      <td className="text-right tabular-nums">{num(l.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
              </DataTable>
            )}
          </Panel>
          <Panel title="Últimas movimentações">
            {(moves ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhuma movimentação registrada.</p>
            ) : (
              <DataTable>
                <thead>
                  <tr>
                    <th>Data/hora</th>
                    <th>Tipo</th>
                    <th className="text-right">Qtd.</th>
                    <th className="text-right">Físico após</th>
                    <th className="text-right">Reservado após</th>
                    <th>Lote</th>
                    <th>Motivo</th>
                    <th>Usuário</th>
                  </tr>
                </thead>
                <tbody>
                  {moves!.map((m) => (
                    <tr key={m.id}>
                      <td className="whitespace-nowrap">{dateTime(m.created_at)}</td>
                      <td>{MOVE_LABEL[m.type]}</td>
                      <td className="text-right tabular-nums">{num(m.quantity)}</td>
                      <td className="text-right tabular-nums">{num(m.physical_after)}</td>
                      <td className="text-right tabular-nums">{num(m.reserved_after)}</td>
                      <td className="font-mono text-xs">{m.lot ?? '—'}</td>
                      <td>
                        {m.reason}
                        {(m.order as unknown as { number: number } | null)?.number ? ` · PED-${String((m.order as unknown as { number: number }).number).padStart(6, '0')}` : ''}
                      </td>
                      <td>{(m.user as unknown as { full_name: string } | null)?.full_name ?? '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </DataTable>
            )}
          </Panel>
        </>
      ) : null}
    </div>
  )
}
