import Link from 'next/link'
import { CancelInvoiceButton, InvoiceForm } from '@/components/crm/invoice-form'
import { DataTable, EmptyState, PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { date, dateTime, money, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Faturamento' }

type Snapshot = { trade_name?: string; legal_name?: string; document?: string; state_registration?: string }

export default async function FaturamentoPage() {
  const profile = await requireModule('faturamento')
  const canWrite = ['admin', 'faturamento'].includes(profile.role)
  const supabase = await createClient()
  const [{ data: queue }, { data: invoices }, { data: methods }, { data: approvedSum }] = await Promise.all([
    supabase
      .from('orders')
      .select('id, number, total, customer_snapshot, payment_term_snapshot, created_at')
      .eq('status', 'aguardando_faturamento')
      .order('number'),
    supabase
      .from('invoices')
      .select('id, doc_type, number, series, access_key, issue_date, amount, status, cancel_reason, created_at, order:orders(id, number, customer_snapshot)')
      .order('created_at', { ascending: false })
      .limit(100),
    supabase.from('payment_methods').select('name').eq('active', true).order('name'),
    supabase
      .from('orders')
      .select('total')
      .in('status', ['aprovado', 'aguardando_estoque', 'em_separacao', 'separado', 'aguardando_faturamento']),
  ])
  const methodNames = (methods ?? []).map((m) => m.name)
  const pendingValue = (queue ?? []).reduce((s, o) => s + Number(o.total), 0)
  const approvedValue = (approvedSum ?? []).reduce((s, o) => s + Number(o.total), 0)
  const invoicedValue = (invoices ?? []).filter((i) => i.status === 'emitida').reduce((s, i) => s + Number(i.amount), 0)

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Faturamento"
        description="Registro de documentos fiscais emitidos no seu emissor. O CRM não emite NF-e — integração com provedor fiscal depende de credenciais externas."
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Aprovado, ainda não faturado" value={money(approvedValue)} hint="Pedidos aprovados até aguardando faturamento" />
        <Stat label="Na fila de faturamento" value={money(pendingValue)} hint={`${queue?.length ?? 0} pedido(s)`} />
        <Stat label="Faturado (últimos 100 docs.)" value={money(invoicedValue)} hint="Somente documentos emitidos" />
      </div>

      <Panel title="Fila: aguardando faturamento">
        {!queue?.length ? (
          <EmptyState title="Fila vazia" description="Pedidos entram aqui depois de separados e conferidos." />
        ) : (
          <div className="flex flex-col gap-4">
            {queue.map((o) => {
              const c = (o.customer_snapshot ?? {}) as Snapshot
              const term = (o.payment_term_snapshot ?? {}) as { name?: string }
              return (
                <details key={o.id} className="rounded-md border border-border">
                  <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-2 p-3 text-sm">
                    <span className="flex flex-col">
                      <span className="font-medium">
                        {orderNumber(o.number)} · {c.trade_name || c.legal_name}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {c.legal_name} · {c.document || 'sem documento'} · IE {c.state_registration || '—'} · {term.name ?? 'sem condição'}
                      </span>
                    </span>
                    <span className="font-semibold tabular-nums">{money(o.total)}</span>
                  </summary>
                  <div className="flex flex-col gap-3 border-t border-border p-3">
                    <Link href={`/pedidos/${o.id}`} className="text-sm underline underline-offset-2">
                      Conferir itens e valores do pedido
                    </Link>
                    {canWrite ? (
                      <InvoiceForm orderId={o.id} total={Number(o.total)} methods={methodNames} />
                    ) : (
                      <p className="text-sm text-muted-foreground">Somente faturamento/administrador registra documentos.</p>
                    )}
                  </div>
                </details>
              )
            })}
          </div>
        )}
      </Panel>

      <Panel title="Documentos registrados">
        {!invoices?.length ? (
          <EmptyState title="Nenhum documento registrado" />
        ) : (
          <DataTable>
            <thead>
              <tr>
                <th>Documento</th>
                <th>Pedido</th>
                <th>Cliente</th>
                <th>Emissão</th>
                <th className="text-right">Valor</th>
                <th>Status</th>
                <th>Registrado</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {invoices.map((i) => {
                const o = i.order as unknown as { id: string; number: number; customer_snapshot: Snapshot } | null
                return (
                  <tr key={i.id}>
                    <td>
                      <span className="font-medium">
                        {i.doc_type} {i.number}
                        {i.series ? `/${i.series}` : ''}
                      </span>
                      {i.access_key ? <span className="block font-mono text-[10px] text-muted-foreground">{i.access_key}</span> : null}
                    </td>
                    <td>{o ? <Link className="underline underline-offset-2" href={`/pedidos/${o.id}`}>{orderNumber(o.number)}</Link> : '—'}</td>
                    <td>{o?.customer_snapshot?.trade_name || o?.customer_snapshot?.legal_name}</td>
                    <td>{date(i.issue_date)}</td>
                    <td className="text-right tabular-nums">{money(i.amount)}</td>
                    <td>
                      <StatusBadge tone={i.status === 'emitida' ? 'ok' : 'bad'}>{i.status === 'emitida' ? 'Emitido' : 'Cancelado'}</StatusBadge>
                      {i.cancel_reason ? <span className="block text-xs text-muted-foreground">{i.cancel_reason}</span> : null}
                    </td>
                    <td className="text-xs text-muted-foreground">{dateTime(i.created_at)}</td>
                    <td>{canWrite && i.status === 'emitida' ? <CancelInvoiceButton invoiceId={i.id} /> : null}</td>
                  </tr>
                )
              })}
            </tbody>
          </DataTable>
        )}
      </Panel>
    </div>
  )
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-lg border border-border bg-card p-4">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <span className="text-xl font-semibold tabular-nums">{value}</span>
      <span className="text-xs text-muted-foreground">{hint}</span>
    </div>
  )
}
