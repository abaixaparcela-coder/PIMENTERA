import { DataTable, EmptyState, PageHeader, Panel, TextInput } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { dateTime } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Auditoria' }

export default async function AuditoriaPage({ searchParams }: { searchParams: Promise<{ entidade?: string; de?: string; ate?: string }> }) {
  await requireModule('auditoria')
  const sp = await searchParams
  const supabase = await createClient()
  let q = supabase
    .from('audit_logs')
    .select('id, action, entity, entity_id, details, created_at, user:profiles(full_name, email)')
    .order('created_at', { ascending: false })
    .limit(300)
  if (sp.entidade) q = q.ilike('entity', `%${sp.entidade.replace(/[%_]/g, '')}%`)
  if (sp.de) q = q.gte('created_at', `${sp.de}T00:00:00-03:00`)
  if (sp.ate) q = q.lte('created_at', `${sp.ate}T23:59:59-03:00`)
  const { data: rows } = await q

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Auditoria"
        description="Registro imutável das operações relevantes (últimos 300 eventos do filtro)."
        actions={
          <form className="flex flex-wrap gap-2">
            <TextInput name="entidade" placeholder="Entidade (ex.: orders)" defaultValue={sp.entidade ?? ''} aria-label="Entidade" className="w-44" />
            <TextInput name="de" type="date" defaultValue={sp.de ?? ''} aria-label="De" className="w-36" />
            <TextInput name="ate" type="date" defaultValue={sp.ate ?? ''} aria-label="Até" className="w-36" />
            <button className="h-9 rounded-md bg-foreground px-3 text-sm font-medium text-background">Filtrar</button>
          </form>
        }
      />
      {!rows?.length ? (
        <EmptyState title="Sem eventos" />
      ) : (
        <Panel>
          <DataTable>
            <thead>
              <tr>
                <th>Data/hora</th>
                <th>Usuário</th>
                <th>Operação</th>
                <th>Entidade</th>
                <th>Registro</th>
                <th>Detalhes</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const u = r.user as unknown as { full_name: string; email: string } | null
                return (
                  <tr key={r.id} className="align-top">
                    <td className="whitespace-nowrap text-xs">{dateTime(r.created_at)}</td>
                    <td>{u?.full_name || u?.email || 'Sistema'}</td>
                    <td className="font-medium">{r.action}</td>
                    <td className="font-mono text-xs">{r.entity}</td>
                    <td className="max-w-28 truncate font-mono text-xs" title={r.entity_id ?? ''}>
                      {r.entity_id}
                    </td>
                    <td>
                      {r.details ? (
                        <pre className="max-h-32 max-w-md overflow-auto whitespace-pre-wrap break-all rounded bg-muted p-2 text-[11px]">
                          {JSON.stringify(r.details, null, 1)}
                        </pre>
                      ) : null}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </DataTable>
        </Panel>
      )}
    </div>
  )
}
