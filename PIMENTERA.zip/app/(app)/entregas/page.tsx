import Link from 'next/link'
import { DataTable, EmptyState, PageHeader, Panel, Select, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { DELIVERY_STATUS_LABEL, deliveryTone } from '@/lib/constants'
import { date, dateTime, deliveryNumber, orderNumber, todayISO } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Entregas' }

const OPEN = ['aguardando_expedicao', 'pronta', 'em_rota', 'reagendada']

export default async function EntregasPage({ searchParams }: { searchParams: Promise<{ status?: string; atrasadas?: string }> }) {
  await requireModule('entregas')
  const sp = await searchParams
  const supabase = await createClient()
  let q = supabase
    .from('deliveries')
    .select('id, number, status, customer_name, address, scheduled_date, departed_at, completed_at, driver:profiles!deliveries_driver_id_fkey(full_name), order:orders(id, number)')
    .order('number', { ascending: false })
    .limit(300)
  if (sp.status === 'abertas' || sp.atrasadas) q = q.in('status', OPEN)
  else if (sp.status && sp.status in DELIVERY_STATUS_LABEL) q = q.eq('status', sp.status)
  if (sp.atrasadas) q = q.lt('scheduled_date', todayISO())
  const { data: rows } = await q
  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Entregas"
        description="Painel operacional. Uma entrega só é concluída com a confirmação do entregador."
        actions={
          <form className="flex gap-2">
            <Select name="status" defaultValue={sp.atrasadas ? 'abertas' : (sp.status ?? '')} aria-label="Status" className="w-48">
              <option value="">Todas</option>
              <option value="abertas">Em aberto</option>
              {Object.entries(DELIVERY_STATUS_LABEL).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
            <button className="h-9 rounded-md bg-foreground px-3 text-sm font-medium text-background">Filtrar</button>
          </form>
        }
      />
      {sp.atrasadas ? <p className="text-sm text-destructive">Exibindo entregas em aberto com data prevista anterior a hoje.</p> : null}
      {!rows?.length ? (
        <EmptyState title="Nenhuma entrega" description="Entregas são criadas na tela de Separação após o faturamento." />
      ) : (
        <Panel>
          <DataTable>
            <thead>
              <tr>
                <th>Entrega</th>
                <th>Pedido</th>
                <th>Cliente</th>
                <th>Entregador</th>
                <th>Prevista</th>
                <th>Saída</th>
                <th>Conclusão</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((d) => {
                const o = d.order as unknown as { id: string; number: number } | null
                return (
                  <tr key={d.id}>
                    <td>
                      <Link href={`/entregas/${d.id}`} className="font-mono text-xs font-semibold hover:underline">
                        {deliveryNumber(d.number)}
                      </Link>
                    </td>
                    <td className="font-mono text-xs">{o ? orderNumber(o.number) : ''}</td>
                    <td>
                      <span className="block max-w-56 truncate">{d.customer_name}</span>
                    </td>
                    <td>{(d.driver as unknown as { full_name: string } | null)?.full_name ?? <span className="text-muted-foreground">—</span>}</td>
                    <td>{date(d.scheduled_date)}</td>
                    <td className="whitespace-nowrap">{dateTime(d.departed_at)}</td>
                    <td className="whitespace-nowrap">{dateTime(d.completed_at)}</td>
                    <td>
                      <StatusBadge tone={deliveryTone(d.status)}>{DELIVERY_STATUS_LABEL[d.status]}</StatusBadge>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </DataTable>
        </Panel>
      )}
    </div>
  )
}
