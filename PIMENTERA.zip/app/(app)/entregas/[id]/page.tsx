import Link from 'next/link'
import { notFound } from 'next/navigation'
import { AssignDeliveryForm, ProofLink } from '@/components/crm/assign-delivery-form'
import { DeliveryResultForm } from '@/components/crm/delivery-result-form'
import { DataTable, DefList, PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { DELIVERY_STATUS_LABEL, deliveryTone } from '@/lib/constants'
import { date, dateTime, deliveryNumber, num, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Entrega' }

export default async function DeliveryDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const profile = await requireModule('entregas')
  const { id } = await params
  const supabase = await createClient()
  const [{ data: d }, { data: items }, { data: history }, { data: drivers }] = await Promise.all([
    supabase
      .from('deliveries')
      .select(
        'id, number, status, customer_name, address, contact, scheduled_date, driver_id, notes, departed_at, completed_at, received_by, proof_path, result_notes, created_at, driver:profiles!deliveries_driver_id_fkey(full_name), order:orders(id, number)',
      )
      .eq('id', id)
      .maybeSingle(),
    supabase.from('delivery_items').select('id, sku, product_name, quantity, delivered_qty').eq('delivery_id', id).order('product_name'),
    supabase
      .from('delivery_status_history')
      .select('id, from_status, to_status, notes, created_at, user:profiles!delivery_status_history_changed_by_fkey(full_name)')
      .eq('delivery_id', id)
      .order('created_at', { ascending: false }),
    supabase.from('profiles').select('id, full_name').eq('role', 'entregador').eq('active', true).order('full_name'),
  ])
  if (!d) notFound()

  const driver = d.driver as unknown as { full_name: string } | null
  const order = d.order as unknown as { id: string; number: number } | null
  const canManage = ['admin', 'estoque', 'gerente'].includes(profile.role)
  const isOwnDriver = d.driver_id === profile.id
  const pending = (items ?? []).reduce((s, i) => s + Math.max(0, i.quantity - i.delivered_qty), 0)

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title={deliveryNumber(d.number)}
        description={d.customer_name}
        actions={<StatusBadge tone={deliveryTone(d.status)}>{DELIVERY_STATUS_LABEL[d.status] ?? d.status}</StatusBadge>}
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="flex flex-col gap-4 lg:col-span-2">
          <Panel title="Dados da entrega">
            <DefList
              items={[
                ['Pedido', order ? <Link className="underline underline-offset-2" href={`/pedidos/${order.id}`}>{orderNumber(order.number)}</Link> : '—'],
                ['Endereço', d.address],
                ['Contato de recebimento', d.contact || '—'],
                ['Data prevista', date(d.scheduled_date)],
                ['Entregador', driver?.full_name ?? 'Não atribuído'],
                ['Saída', dateTime(d.departed_at)],
                ['Conclusão', dateTime(d.completed_at)],
                ['Recebido por', d.received_by || '—'],
                ['Observações', d.notes || '—'],
                ['Resultado', d.result_notes || '—'],
                ['Comprovante', d.proof_path ? <ProofLink deliveryId={d.id} /> : 'Sem comprovante'],
              ]}
            />
          </Panel>
          <Panel title="Itens" description={pending > 0 ? `${num(pending)} unidade(s) pendente(s) de entrega` : undefined}>
            <DataTable>
              <thead>
                <tr>
                  <th>SKU</th>
                  <th>Produto</th>
                  <th className="text-right">Qtd.</th>
                  <th className="text-right">Entregue</th>
                  <th className="text-right">Pendente</th>
                </tr>
              </thead>
              <tbody>
                {(items ?? []).map((i) => (
                  <tr key={i.id}>
                    <td className="font-mono text-xs">{i.sku}</td>
                    <td>{i.product_name}</td>
                    <td className="text-right tabular-nums">{num(i.quantity)}</td>
                    <td className="text-right tabular-nums">{num(i.delivered_qty)}</td>
                    <td className="text-right tabular-nums">{num(Math.max(0, i.quantity - i.delivered_qty))}</td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </Panel>
          <Panel title="Histórico de status">
            {!history?.length ? (
              <p className="text-sm text-muted-foreground">Sem registros.</p>
            ) : (
              <ol className="flex flex-col gap-2">
                {history.map((h) => {
                  const u = h.user as unknown as { full_name: string } | null
                  return (
                    <li key={h.id} className="flex flex-col gap-0.5 border-b border-border pb-2 text-sm last:border-0">
                      <span className="font-medium">
                        {h.from_status ? `${DELIVERY_STATUS_LABEL[h.from_status] ?? h.from_status} → ` : ''}
                        {DELIVERY_STATUS_LABEL[h.to_status] ?? h.to_status}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {dateTime(h.created_at)} · {u?.full_name ?? 'Sistema'}
                        {h.notes ? ` · ${h.notes}` : ''}
                      </span>
                    </li>
                  )
                })}
              </ol>
            )}
          </Panel>
        </div>
        <div className="flex flex-col gap-4">
          {canManage && !['entregue', 'recusada'].includes(d.status) ? (
            <Panel title="Atribuição">
              <AssignDeliveryForm deliveryId={d.id} drivers={drivers ?? []} driverId={d.driver_id} scheduled={d.scheduled_date} />
            </Panel>
          ) : null}
          {canManage || isOwnDriver ? (
            <Panel title="Registrar resultado">
              <DeliveryResultForm
                deliveryId={d.id}
                status={d.status}
                items={(items ?? []).map((i) => ({ id: i.id, product_name: i.product_name, quantity: i.quantity }))}
              />
              {!['pronta', 'reagendada', 'em_rota'].includes(d.status) ? (
                <p className="text-sm text-muted-foreground">Nenhuma ação disponível para o status atual.</p>
              ) : null}
            </Panel>
          ) : null}
        </div>
      </div>
    </div>
  )
}
