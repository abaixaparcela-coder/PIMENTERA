import Link from 'next/link'
import { Plus } from 'lucide-react'
import { DataTable, EmptyState, LinkButton, PageHeader, Panel, Select, StatusBadge, TextInput } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { ORDER_STATUS_LABEL, orderTone } from '@/lib/constants'
import { date, money, num, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Pedidos' }

type SP = Promise<{ status?: string; q?: string; de?: string; ate?: string; rep?: string }>

export default async function OrdersPage({ searchParams }: { searchParams: SP }) {
  const profile = await requireModule('pedidos')
  const sp = await searchParams
  const supabase = await createClient()
  let q = supabase
    .from('orders')
    .select('id, number, status, total, created_at, expected_delivery, customer_snapshot, requires_approval_reason, rep:profiles!orders_rep_id_fkey(full_name), items:order_items(quantity)')
    .order('number', { ascending: false })
    .limit(200)
  if (sp.status) {
    const list = sp.status.split(',').filter((s) => s in ORDER_STATUS_LABEL)
    if (list.length) q = q.in('status', list)
  }
  if (sp.de) q = q.gte('created_at', `${sp.de}T00:00:00-03:00`)
  if (sp.ate) q = q.lte('created_at', `${sp.ate}T23:59:59-03:00`)
  if (sp.rep) q = q.eq('rep_id', sp.rep)
  const term = sp.q?.trim()
  if (term) {
    const n = Number(term.replace(/\D/g, ''))
    const safe = term.replace(/[%,()]/g, ' ')
    q = n && /^(ped-?)?\d+$/i.test(term)
      ? q.eq('number', n)
      : q.or(`customer_snapshot->>trade_name.ilike.%${safe}%,customer_snapshot->>legal_name.ilike.%${safe}%`)
  }
  const { data: orders, error } = await q
  const canCreate = ['admin', 'gerente', 'comercial'].includes(profile.role)

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Pedidos"
        description={profile.role === 'comercial' ? 'Seus pedidos e os de seus clientes.' : 'Todos os pedidos registrados.'}
        actions={
          <>
            <LinkButton href={`/api/export/pedidos?${new URLSearchParams(sp as Record<string, string>).toString()}`} variant="outline">
              Exportar CSV
            </LinkButton>
            {canCreate ? (
              <LinkButton href="/pedidos/novo">
                <Plus aria-hidden /> Tirar pedido
              </LinkButton>
            ) : null}
          </>
        }
      />
      <Panel>
        <form className="grid grid-cols-2 gap-2 md:grid-cols-5" role="search">
          <TextInput name="q" defaultValue={sp.q} placeholder="Nº do pedido ou cliente" aria-label="Buscar" className="col-span-2" />
          <Select name="status" defaultValue={sp.status ?? ''} aria-label="Status">
            <option value="">Todos os status</option>
            {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </Select>
          <TextInput type="date" name="de" defaultValue={sp.de} aria-label="De" />
          <div className="flex gap-2">
            <TextInput type="date" name="ate" defaultValue={sp.ate} aria-label="Até" />
            <button type="submit" className="h-9 rounded-md bg-foreground px-3 text-sm font-medium text-background">
              Filtrar
            </button>
          </div>
        </form>
      </Panel>
      {error ? <p className="text-sm text-destructive">Erro ao carregar pedidos: {error.message}</p> : null}
      {!orders?.length ? (
        <EmptyState title="Nenhum pedido encontrado" description="Ajuste os filtros ou registre um novo pedido." action={canCreate ? <LinkButton href="/pedidos/novo">Tirar pedido</LinkButton> : undefined} />
      ) : (
        <Panel>
          <DataTable>
            <thead>
              <tr>
                <th>Pedido</th>
                <th>Data</th>
                <th>Cliente</th>
                <th>Representante</th>
                <th className="text-right">Unid.</th>
                <th className="text-right">Total</th>
                <th>Previsão</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => {
                const c = o.customer_snapshot as { trade_name?: string; legal_name?: string; city?: string }
                const units = (o.items ?? []).reduce((s: number, i: { quantity: number }) => s + i.quantity, 0)
                return (
                  <tr key={o.id}>
                    <td>
                      <Link href={`/pedidos/${o.id}`} className="font-mono text-xs font-semibold hover:text-primary hover:underline">
                        {orderNumber(o.number)}
                      </Link>
                    </td>
                    <td className="whitespace-nowrap">{date(o.created_at)}</td>
                    <td>
                      <span className="block max-w-56 truncate">{c.trade_name || c.legal_name}</span>
                      <span className="text-xs text-muted-foreground">{c.city}</span>
                    </td>
                    <td>{(o.rep as unknown as { full_name: string } | null)?.full_name}</td>
                    <td className="text-right tabular-nums">{num(units)}</td>
                    <td className="text-right font-medium tabular-nums">{money(o.total)}</td>
                    <td className="whitespace-nowrap">{date(o.expected_delivery)}</td>
                    <td>
                      <StatusBadge tone={orderTone(o.status)}>{ORDER_STATUS_LABEL[o.status]}</StatusBadge>
                      {o.requires_approval_reason && o.status === 'aguardando_aprovacao' ? <span className="ml-1 text-xs text-destructive">exceção</span> : null}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </DataTable>
        </Panel>
      )}
    </div>
  )
}
