import { redirect } from 'next/navigation'
import { OrderBuilder, type BuilderInitial } from '@/components/crm/order-builder'
import { PageHeader } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { customerCode, doc, formatAddress, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Tirar pedido' }

type SP = Promise<{ cliente?: string; duplicar?: string; editar?: string }>

export default async function NewOrderPage({ searchParams }: { searchParams: SP }) {
  const profile = await requireModule('visitas')
  const sp = await searchParams
  const supabase = await createClient()

  const [{ data: customers }, { data: products }, { data: terms }, { data: templates }] = await Promise.all([
    supabase
      .from('customers')
      .select('id, code, legal_name, trade_name, document, city, state, street, number, complement, district, cep, delivery_address, payment_term_id, status')
      .neq('status', 'inativo')
      .order('trade_name', { nullsFirst: false }),
    supabase
      .from('products')
      .select('id, sku, name, net_content, unit, price, min_price, stock_physical, stock_reserved, brand:brands(code), category:product_categories(name)')
      .eq('active', true)
      .order('brand_id')
      .order('name'),
    supabase.from('payment_terms').select('id, name, days').eq('active', true).order('name'),
    supabase.from('order_templates').select('id, name, items:order_template_items(product_id, quantity)').eq('active', true).order('name'),
  ])

  let initial: BuilderInitial = { customer_id: sp.cliente }
  let title = 'Tirar pedido'
  const sourceId = sp.editar || sp.duplicar
  if (sourceId) {
    const { data: src } = await supabase
      .from('orders')
      .select('id, number, status, customer_id, delivery_address, payment_term_id, freight, tax_total, expected_delivery, notes, items:order_items(product_id, quantity, unit_price, discount_pct, list_price, position)')
      .eq('id', sourceId)
      .maybeSingle()
    if (src) {
      const editing = !!sp.editar
      if (editing && src.status !== 'rascunho') redirect(`/pedidos/${src.id}`)
      const items = [...(src.items ?? [])].sort((a, b) => a.position - b.position)
      initial = {
        id: editing ? src.id : null,
        customer_id: editing || !sp.cliente ? src.customer_id : sp.cliente,
        delivery_address: src.delivery_address ?? undefined,
        payment_term_id: src.payment_term_id,
        freight: Number(src.freight),
        tax_total: Number(src.tax_total),
        expected_delivery: editing ? src.expected_delivery : null,
        notes: editing ? src.notes : null,
        // Duplicates use current catalog prices; only a manually overridden price is carried over.
        items: items.map((i) => ({
          product_id: i.product_id,
          quantity: i.quantity,
          unit_price: editing || Number(i.unit_price) !== Number(i.list_price) ? Number(i.unit_price) : null,
          discount_pct: Number(i.discount_pct),
        })),
      }
      title = editing ? `Editar rascunho ${orderNumber(src.number)}` : `Novo pedido a partir de ${orderNumber(src.number)}`
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title={title} description="Selecione o cliente, adicione os produtos e envie para aprovação." />
      <OrderBuilder
        initial={initial}
        maxDiscount={Number(profile.max_discount_pct ?? 0)}
        canEditPrice={['admin', 'gerente'].includes(profile.role)}
        canSaveTemplate={['admin', 'gerente'].includes(profile.role)}
        terms={terms ?? []}
        templates={(templates ?? []).map((t) => ({ id: t.id, name: t.name, items: t.items ?? [] }))}
        customers={(customers ?? []).map((c) => ({
          id: c.id,
          label: c.trade_name || c.legal_name,
          sub: [customerCode(c.code), c.trade_name ? c.legal_name : null, doc(c.document), c.city ? `${c.city}/${c.state ?? ''}` : null].filter(Boolean).join(' · '),
          address: c.delivery_address || formatAddress(c),
          payment_term_id: c.payment_term_id,
          status: c.status,
        }))}
        products={(products ?? []).map((p) => ({
          id: p.id,
          sku: p.sku,
          name: p.name,
          net_content: p.net_content,
          unit: p.unit,
          price: p.price === null ? null : Number(p.price),
          min_price: p.min_price === null ? null : Number(p.min_price),
          available: p.stock_physical - p.stock_reserved,
          brand: (p.brand as unknown as { code: string } | null)?.code ?? '',
          category: (p.category as unknown as { name: string } | null)?.name ?? null,
        }))}
      />
    </div>
  )
}
