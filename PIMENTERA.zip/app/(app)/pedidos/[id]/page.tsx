import Link from 'next/link'
import { notFound } from 'next/navigation'
import { MessageCircle } from 'lucide-react'
import { OrderDocument } from '@/components/crm/order-document'
import { OrderStatusActions, type TransitionOption } from '@/components/crm/order-status-actions'
import { PrintButton } from '@/components/crm/print-button'
import { LinkButton, PageHeader, Panel, StatusBadge } from '@/components/crm/ui'
import { requireModule } from '@/lib/auth'
import { getCompany } from '@/lib/company'
import { DELIVERY_STATUS_LABEL, ORDER_STATUS_LABEL, deliveryTone, orderTone } from '@/lib/constants'
import { dateTime, deliveryNumber, money, onlyDigits, orderNumber } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

export const metadata = { title: 'Pedido' }

const ACTION_LABEL: Record<string, string> = {
  aguardando_aprovacao: 'Enviar para aprovação',
  aprovado: 'Aprovar e reservar estoque',
  rascunho: 'Devolver para rascunho',
  em_separacao: 'Iniciar separação',
  separado: 'Concluir conferência',
  aguardando_faturamento: 'Liberar para faturamento',
  cancelado: 'Cancelar pedido',
}

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const profile = await requireModule('pedidos')
  const { id } = await params
  const supabase = await createClient()
  const { data: order } = await supabase
    .from('orders')
    .select(
      'id, number, status, created_at, customer_id, customer_snapshot, delivery_address, subtotal, discount_total, freight, tax_total, total, payment_term_snapshot, expected_delivery, notes, requires_approval_reason, cancel_reason, created_by, rep:profiles!orders_rep_id_fkey(full_name), creator:profiles!orders_created_by_fkey(full_name), approver:profiles!orders_approved_by_fkey(full_name), approved_at',
    )
    .eq('id', id)
    .maybeSingle()
  if (!order) notFound()

  const [{ data: items }, { data: history }, { data: transitions }, { data: invoices }, { data: deliveries }, { company, logos }] = await Promise.all([
    supabase.from('order_items').select('id, sku, product_name, brand_code, unit, quantity, unit_price, discount_pct, line_total, picked_qty, delivered_qty').eq('order_id', id).order('position'),
    supabase.from('order_status_history').select('id, from_status, to_status, notes, created_at, user:profiles(full_name)').eq('order_id', id).order('created_at'),
    supabase.from('order_transitions').select('to_status, allowed_roles').eq('from_status', order.status),
    supabase.from('invoices').select('id, doc_type, number, series, issue_date, amount, status').eq('order_id', id).order('created_at'),
    supabase.from('deliveries').select('id, number, status, scheduled_date').eq('order_id', id).order('created_at'),
    getCompany(),
  ])

  const options: TransitionOption[] = (transitions ?? [])
    .filter((t) => (t.allowed_roles as string[]).includes(profile.role))
    // picking conclusion requires quantities; it is done from the Separação screen
    .filter((t) => t.to_status !== 'separado')
    .map((t) => ({ to: t.to_status, label: ACTION_LABEL[t.to_status] ?? ORDER_STATUS_LABEL[t.to_status], destructive: t.to_status === 'cancelado' }))
    .sort((a, b) => Number(!!a.destructive) - Number(!!b.destructive))

  const snap = order.customer_snapshot as Record<string, string>
  const repName = (order.rep as unknown as { full_name: string } | null)?.full_name ?? ''
  const wa = onlyDigits(snap.whatsapp || snap.phone)
  const waText = encodeURIComponent(`Olá! Segue o pedido ${orderNumber(order.number)} — total ${money(order.total)}. O PDF será enviado em anexo.`)
  const canEdit = order.status === 'rascunho' && (profile.role !== 'comercial' || order.created_by === profile.id)
  const canCreate = ['admin', 'gerente', 'comercial'].includes(profile.role)

  return (
    <div className="flex flex-col gap-4">
      <div className="no-print">
        <PageHeader
          title={`Pedido ${orderNumber(order.number)}`}
          description={`${snap.trade_name || snap.legal_name} · criado por ${(order.creator as unknown as { full_name: string } | null)?.full_name ?? '—'} em ${dateTime(order.created_at)}`}
          actions={
            <>
              <StatusBadge tone={orderTone(order.status)}>{ORDER_STATUS_LABEL[order.status]}</StatusBadge>
              <PrintButton />
              {wa ? (
                <a
                  href={`https://wa.me/${wa.length <= 11 ? `55${wa}` : wa}?text=${waText}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-9 items-center gap-1.5 rounded-md border border-input bg-card px-3 text-sm font-medium hover:bg-accent"
                >
                  <MessageCircle className="size-4" aria-hidden /> WhatsApp
                </a>
              ) : null}
              {canEdit ? (
                <LinkButton href={`/pedidos/novo?editar=${order.id}`} variant="outline">
                  Editar rascunho
                </LinkButton>
              ) : null}
              {canCreate ? (
                <LinkButton href={`/pedidos/novo?duplicar=${order.id}`} variant="outline">
                  Duplicar
                </LinkButton>
              ) : null}
            </>
          }
        />
      </div>

      <div className="no-print grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="Ações" className="lg:col-span-2">
          <div className="flex flex-col gap-3">
            {order.requires_approval_reason ? (
              <p className="rounded-md border border-destructive/30 bg-destructive/10 p-2.5 text-sm text-destructive">
                Requer autorização: {order.requires_approval_reason}
              </p>
            ) : null}
            {order.cancel_reason ? <p className="text-sm text-destructive">Motivo do cancelamento: {order.cancel_reason}</p> : null}
            {order.approved_at ? (
              <p className="text-sm text-muted-foreground">
                Aprovado por {(order.approver as unknown as { full_name: string } | null)?.full_name} em {dateTime(order.approved_at)}
              </p>
            ) : null}
            {options.length ? <OrderStatusActions orderId={order.id} options={options} /> : <p className="text-sm text-muted-foreground">Nenhuma ação disponível para o seu perfil neste status.</p>}
            {order.status === 'em_separacao' && ['admin', 'estoque'].includes(profile.role) ? (
              <LinkButton href={`/expedicao/${order.id}`} className="self-start">
                Abrir lista de separação
              </LinkButton>
            ) : null}
            {order.status === 'aguardando_faturamento' && ['admin', 'faturamento'].includes(profile.role) ? (
              <LinkButton href={`/faturamento/${order.id}`} className="self-start">
                Registrar faturamento
              </LinkButton>
            ) : null}
            {(invoices ?? []).length || (deliveries ?? []).length ? (
              <div className="flex flex-col gap-1 border-t border-border pt-3 text-sm">
                {(invoices ?? []).map((i) => (
                  <p key={i.id}>
                    {i.doc_type} nº {i.number}
                    {i.series ? `/${i.series}` : ''} · {money(i.amount)} · {i.status === 'emitida' ? 'emitido' : 'cancelado'}
                  </p>
                ))}
                {(deliveries ?? []).map((d) => (
                  <p key={d.id} className="flex items-center gap-2">
                    <Link href={`/entregas/${d.id}`} className="font-mono text-xs hover:underline">
                      {deliveryNumber(d.number)}
                    </Link>
                    <StatusBadge tone={deliveryTone(d.status)}>{DELIVERY_STATUS_LABEL[d.status]}</StatusBadge>
                  </p>
                ))}
              </div>
            ) : null}
          </div>
        </Panel>
        <Panel title="Histórico de status">
          <ol className="flex flex-col gap-2.5 text-sm">
            {(history ?? []).map((h) => (
              <li key={h.id} className="border-l-2 border-border pl-3">
                <p className="font-medium">{ORDER_STATUS_LABEL[h.to_status]}</p>
                <p className="text-xs text-muted-foreground">
                  {dateTime(h.created_at)} · {(h.user as unknown as { full_name: string } | null)?.full_name ?? 'Sistema'}
                </p>
                {h.notes ? <p className="text-xs">{h.notes}</p> : null}
              </li>
            ))}
          </ol>
        </Panel>
      </div>

      <OrderDocument
        order={{ ...order, payment_term_snapshot: order.payment_term_snapshot as { name: string } | null, customer_snapshot: snap }}
        items={(items ?? []) as never}
        company={company}
        logos={logos}
        repName={repName}
      />
    </div>
  )
}
