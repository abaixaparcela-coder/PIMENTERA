export function AuthFrame({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <main className="flex min-h-dvh flex-col md:flex-row">
      <section className="flex flex-col justify-between gap-8 bg-sidebar p-6 text-sidebar-foreground md:w-[44%] md:p-10">
        <div className="flex items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-md bg-primary font-mono text-sm font-semibold text-primary-foreground">
            P+M
          </span>
          <span className="text-sm font-medium text-sidebar-accent-foreground">Uso interno</span>
        </div>
        <div className="flex flex-col gap-3">
          <h1 className="text-3xl font-semibold leading-tight text-sidebar-accent-foreground text-balance md:text-4xl">
            CRM Pimentera <span className="text-sidebar-primary">+ Mixx Condimentos</span>
          </h1>
          <p className="max-w-sm text-sm leading-relaxed text-sidebar-foreground/75 text-pretty">
            Clientes, visitas, pedidos, estoque, faturamento, contas a receber e entregas em um só lugar.
          </p>
        </div>
        <div className="flex gap-1.5" aria-hidden="true">
          <span className="h-1.5 w-10 rounded-full bg-primary" />
          <span className="h-1.5 w-10 rounded-full bg-sidebar-primary" />
          <span className="h-1.5 w-10 rounded-full bg-sidebar-foreground/30" />
        </div>
      </section>
      <section className="flex flex-1 items-center justify-center p-6">
        <div className="flex w-full max-w-sm flex-col gap-6">
          <div className="flex flex-col gap-1">
            <h2 className="text-xl font-semibold">{title}</h2>
            <p className="text-sm text-muted-foreground">{subtitle}</p>
          </div>
          {children}
        </div>
      </section>
    </main>
  )
}
