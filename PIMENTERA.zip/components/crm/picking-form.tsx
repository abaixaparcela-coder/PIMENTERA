'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { DataTable, TextInput } from '@/components/crm/ui'
import { savePicking } from '@/lib/actions/orders'
import { num } from '@/lib/format'

type Row = { id: string; sku: string; product_name: string; quantity: number; picked_qty: number; lot: string | null; physical: number }

export function PickingForm({ orderId, rows }: { orderId: string; rows: Row[] }) {
  const router = useRouter()
  const [pending, start] = useTransition()
  const [state, setState] = useState(() => Object.fromEntries(rows.map((r) => [r.id, { picked: r.picked_qty, lot: r.lot ?? '', checked: false }])))

  const allChecked = rows.every((r) => state[r.id].checked)
  const short = rows.filter((r) => state[r.id].picked < r.quantity)

  function submit(conclude: boolean) {
    if (conclude && !allChecked) return toast.error('Marque a conferência de todos os itens.')
    start(async () => {
      const r = await savePicking(
        orderId,
        rows.map((x) => ({ id: x.id, picked_qty: state[x.id].picked, lot: state[x.id].lot || undefined })),
        conclude,
      )
      if (r.ok) {
        toast.success(r.message)
        router.refresh()
        if (conclude) router.push('/expedicao')
      } else toast.error(r.error)
    })
  }

  return (
    <div className="flex flex-col gap-3">
      <DataTable>
        <thead>
          <tr>
            <th>SKU</th>
            <th>Produto</th>
            <th className="text-right">Solicitado</th>
            <th className="text-right">Físico</th>
            <th className="text-right">Separado</th>
            <th>Lote</th>
            <th className="text-center">Conferido</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const s = state[r.id]
            const set = (patch: Partial<typeof s>) => setState((p) => ({ ...p, [r.id]: { ...p[r.id], ...patch } }))
            return (
              <tr key={r.id} className={s.picked < r.quantity ? 'bg-mustard/15' : undefined}>
                <td className="font-mono text-xs">{r.sku}</td>
                <td>{r.product_name}</td>
                <td className="text-right tabular-nums">{num(r.quantity)}</td>
                <td className={`text-right tabular-nums ${r.physical < r.quantity ? 'text-destructive' : ''}`}>{num(r.physical)}</td>
                <td className="text-right">
                  <TextInput
                    type="number"
                    inputMode="numeric"
                    min={0}
                    max={r.quantity}
                    value={s.picked}
                    onChange={(e) => set({ picked: Math.max(0, Math.min(r.quantity, Math.trunc(Number(e.target.value) || 0))) })}
                    className="h-8 w-20 text-right"
                    aria-label={`Separado ${r.product_name}`}
                  />
                </td>
                <td>
                  <TextInput value={s.lot} onChange={(e) => set({ lot: e.target.value })} className="h-8 w-28" aria-label={`Lote ${r.product_name}`} />
                </td>
                <td className="text-center">
                  <input type="checkbox" checked={s.checked} onChange={(e) => set({ checked: e.target.checked })} className="size-4 accent-primary" aria-label={`Conferido ${r.product_name}`} />
                </td>
              </tr>
            )
          })}
        </tbody>
      </DataTable>
      <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
        <p className="text-muted-foreground">
          {short.length ? `${short.length} item(ns) com quantidade abaixo do solicitado — ficarão pendentes de entrega.` : 'Todas as quantidades atendidas.'}
        </p>
        <div className="flex gap-2">
          <Button type="button" variant="outline" disabled={pending} onClick={() => submit(false)}>
            Salvar parcial
          </Button>
          <Button type="button" disabled={pending || !allChecked} onClick={() => submit(true)}>
            {pending ? 'Processando…' : 'Concluir conferência'}
          </Button>
        </div>
      </div>
    </div>
  )
}
