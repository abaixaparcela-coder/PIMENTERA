'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Select, TextArea, TextInput } from '@/components/crm/ui'
import { cancelInvoice, registerInvoice } from '@/lib/actions/operations'
import { todayISO } from '@/lib/format'

export function InvoiceForm({ orderId, total, methods }: { orderId: string; total: number; methods: string[] }) {
  const router = useRouter()
  const [key, setKey] = useState(() => crypto.randomUUID())
  const [pending, start] = useTransition()
  const id = (n: string) => `${n}_${orderId.slice(0, 8)}`

  function submit(fd: FormData) {
    start(async () => {
      const r = await registerInvoice({
        order_id: orderId,
        idempotency_key: key,
        doc_type: String(fd.get('doc_type')) as 'NF-e',
        number: String(fd.get('number') ?? ''),
        series: String(fd.get('series') ?? ''),
        access_key: String(fd.get('access_key') ?? ''),
        issue_date: String(fd.get('issue_date') ?? ''),
        amount: Number(String(fd.get('amount') ?? '').replace(',', '.')),
        payment_method: String(fd.get('payment_method') ?? ''),
        notes: String(fd.get('notes') ?? ''),
      })
      if (r.ok) {
        toast.success(r.message)
        setKey(crypto.randomUUID())
        router.refresh()
      } else toast.error(r.error)
    })
  }

  return (
    <form action={submit} className="grid gap-3 sm:grid-cols-2">
      <Field label="Tipo de documento" htmlFor={id('type')}>
        <Select id={id('type')} name="doc_type" defaultValue="NF-e">
          <option>NF-e</option>
          <option>NFC-e</option>
          <option>Recibo</option>
          <option>Outro</option>
        </Select>
      </Field>
      <div className="grid grid-cols-3 gap-2">
        <Field label="Número" htmlFor={id('num')} className="col-span-2">
          <TextInput id={id('num')} name="number" required maxLength={30} />
        </Field>
        <Field label="Série" htmlFor={id('ser')}>
          <TextInput id={id('ser')} name="series" maxLength={10} />
        </Field>
      </div>
      <Field label="Chave de acesso (44 dígitos)" htmlFor={id('key')} className="sm:col-span-2">
        <TextInput id={id('key')} name="access_key" inputMode="numeric" maxLength={54} placeholder="Opcional" />
      </Field>
      <Field label="Data de emissão" htmlFor={id('date')}>
        <TextInput id={id('date')} name="issue_date" type="date" defaultValue={todayISO()} required />
      </Field>
      <Field label="Valor faturado (R$)" htmlFor={id('amt')}>
        <TextInput id={id('amt')} name="amount" inputMode="decimal" defaultValue={total.toFixed(2)} required />
      </Field>
      <Field label="Forma de pagamento" htmlFor={id('pm')} className="sm:col-span-2">
        <Select id={id('pm')} name="payment_method" defaultValue="">
          <option value="">Não informado</option>
          {methods.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </Select>
      </Field>
      <Field label="Observações" htmlFor={id('obs')} className="sm:col-span-2">
        <TextArea id={id('obs')} name="notes" rows={2} maxLength={1000} />
      </Field>
      <div className="sm:col-span-2">
        <Button type="submit" disabled={pending}>
          {pending ? 'Registrando…' : 'Registrar faturamento'}
        </Button>
      </div>
    </form>
  )
}

export function CancelInvoiceButton({ invoiceId }: { invoiceId: string }) {
  const router = useRouter()
  const [pending, start] = useTransition()
  return (
    <Button
      variant="outline"
      size="sm"
      disabled={pending}
      onClick={() => {
        const reason = window.prompt('Motivo do cancelamento do documento:')
        if (!reason?.trim()) return
        start(async () => {
          const r = await cancelInvoice(invoiceId, reason)
          if (r.ok) {
            toast.success(r.message)
            router.refresh()
          } else toast.error(r.error)
        })
      }}
    >
      {pending ? 'Cancelando…' : 'Cancelar'}
    </Button>
  )
}
