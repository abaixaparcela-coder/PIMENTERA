'use client'

import { useActionState, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Select, TextInput } from '@/components/crm/ui'
import { moveStock } from '@/lib/actions/products'
import type { ActionResult } from '@/lib/auth'

export function StockMoveForm({ products, defaultProduct }: { products: { id: string; label: string }[]; defaultProduct?: string }) {
  const [state, action, pending] = useActionState<ActionResult | undefined, FormData>(moveStock, undefined)
  const [type, setType] = useState('entrada')
  const ref = useRef<HTMLFormElement>(null)
  const router = useRouter()
  useEffect(() => {
    if (!state) return
    if (state.ok) {
      toast.success(state.message ?? 'Registrado.')
      ref.current?.reset()
      setType('entrada')
      router.refresh()
    } else toast.error(state.error)
  }, [state, router])

  return (
    <form ref={ref} action={action} className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
      <Field label="Produto *" htmlFor="mv_product" className="sm:col-span-2">
        <Select id="mv_product" name="product_id" defaultValue={defaultProduct ?? ''} required>
          <option value="" disabled>
            Selecione…
          </option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.label}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Tipo *" htmlFor="mv_type">
        <Select id="mv_type" name="type" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="entrada">Entrada</option>
          <option value="saida">Saída</option>
          <option value="ajuste">Ajuste (+/−)</option>
        </Select>
      </Field>
      <Field label="Quantidade *" htmlFor="mv_qty" hint={type === 'ajuste' ? 'Use negativo para reduzir.' : undefined}>
        <TextInput id="mv_qty" name="quantity" type="number" step={1} min={type === 'ajuste' ? undefined : 1} required />
      </Field>
      <Field label="Lote" htmlFor="mv_lot">
        <TextInput id="mv_lot" name="lot" />
      </Field>
      <Field label="Validade" htmlFor="mv_exp">
        <TextInput id="mv_exp" name="expiry_date" type="date" disabled={type !== 'entrada'} />
      </Field>
      <Field label={type === 'ajuste' ? 'Justificativa *' : 'Motivo / documento'} htmlFor="mv_reason" className="sm:col-span-2 lg:col-span-5">
        <TextInput id="mv_reason" name="reason" required={type === 'ajuste'} placeholder={type === 'entrada' ? 'Ex.: Produção lote 05/2026, NF fornecedor…' : ''} />
      </Field>
      <div className="flex items-end">
        <Button type="submit" className="w-full" disabled={pending}>
          {pending ? 'Registrando…' : 'Registrar'}
        </Button>
      </div>
    </form>
  )
}
