'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Select, TextInput } from '@/components/crm/ui'
import { createDelivery } from '@/lib/actions/operations'

export function CreateDeliveryButton({ orderId, drivers, defaultDate }: { orderId: string; drivers: { id: string; full_name: string }[]; defaultDate: string | null }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [driver, setDriver] = useState('')
  const [day, setDay] = useState(defaultDate ?? '')
  const [pending, start] = useTransition()

  if (!open)
    return (
      <Button size="sm" onClick={() => setOpen(true)}>
        Criar entrega
      </Button>
    )
  return (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      <Select value={driver} onChange={(e) => setDriver(e.target.value)} className="h-8 w-40" aria-label="Entregador">
        <option value="">Sem entregador</option>
        {drivers.map((d) => (
          <option key={d.id} value={d.id}>
            {d.full_name}
          </option>
        ))}
      </Select>
      <TextInput type="date" value={day} onChange={(e) => setDay(e.target.value)} className="h-8 w-36" aria-label="Data prevista" />
      <Button
        size="sm"
        disabled={pending}
        onClick={() =>
          start(async () => {
            const r = await createDelivery(orderId, driver || null, day || null, '')
            if (r.ok) {
              toast.success(r.message)
              router.push(`/entregas/${r.data!.id}`)
            } else toast.error(r.error)
          })
        }
      >
        {pending ? 'Criando…' : 'Confirmar'}
      </Button>
      <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>
        Cancelar
      </Button>
    </div>
  )
}
