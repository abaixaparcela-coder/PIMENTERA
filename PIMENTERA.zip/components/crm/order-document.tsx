import { BRAND_LABEL, ORDER_STATUS_LABEL } from '@/lib/constants'
import { cep, date, dateTime, doc, money, num, orderNumber, phone } from '@/lib/format'

type Snapshot = Record<string, string | number | null | undefined>
export type DocItem = {
  id: string
  sku: string
  product_name: string
  brand_code: string
  unit: string
  quantity: number
  unit_price: number
  discount_pct: number
  line_total: number
}
export type DocCompany = {
  company_name: string
  legal_name: string | null
  cnpj: string | null
  address: string | null
  city: string | null
  state: string | null
  phone: string | null
  email: string | null
  website_pimentera: string | null
  website_mixx: string | null
  instagram_pimentera: string | null
  instagram_mixx: string | null
  order_footer_notes: string | null
}

export function OrderDocument({
  order,
  items,
  company,
  logos,
  repName,
}: {
  order: {
    number: number
    status: string
    created_at: string
    customer_snapshot: Snapshot
    delivery_address: string | null
    subtotal: number
    discount_total: number
    freight: number
    tax_total: number
    total: number
    payment_term_snapshot: { name: string } | null
    expected_delivery: string | null
    notes: string | null
  }
  items: DocItem[]
  company: DocCompany | null
  logos: { pimentera: string | null; mixx: string | null }
  repName: string
}) {
  const c = order.customer_snapshot
  const units = items.reduce((s, i) => s + i.quantity, 0)
  const byBrand = items.reduce<Record<string, { units: number; total: number }>>((acc, i) => {
    acc[i.brand_code] ??= { units: 0, total: 0 }
    acc[i.brand_code].units += i.quantity
    acc[i.brand_code].total += Number(i.line_total)
    return acc
  }, {})
  const addr = [c.street, c.number, c.complement, c.district].filter(Boolean).join(', ')
  return (
    <article className="order-doc mx-auto w-full max-w-[210mm] bg-card p-6 text-[12px] leading-snug text-foreground shadow-sm ring-1 ring-border print:max-w-none print:p-0 print:shadow-none print:ring-0">
      <header className="flex items-start justify-between gap-4 border-b-2 border-foreground pb-3">
        <div className="flex items-center gap-3">
          {logos.pimentera ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logos.pimentera} alt="Pimentera Foods" className="h-12 w-auto object-contain" />
          ) : (
            <span className="font-heading text-lg font-bold text-primary">Pimentera</span>
          )}
          <span className="text-muted-foreground">+</span>
          {logos.mixx ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logos.mixx} alt="Mixx Condimentos" className="h-12 w-auto object-contain" />
          ) : (
            <span className="font-heading text-lg font-bold">Mixx Condimentos</span>
          )}
        </div>
        <div className="text-right">
          <p className="font-heading text-base font-bold uppercase tracking-wide">Pedido de venda</p>
          <p className="font-mono text-lg font-bold">{orderNumber(order.number)}</p>
          <p>Emitido em {dateTime(order.created_at)}</p>
          <p>Status: {ORDER_STATUS_LABEL[order.status]}</p>
        </div>
      </header>

      <section className="grid grid-cols-2 gap-4 border-b border-border py-3">
        <div>
          <h3 className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Fornecedor</h3>
          <p className="font-semibold">{company?.legal_name || company?.company_name}</p>
          {company?.cnpj ? <p>CNPJ {doc(company.cnpj)}</p> : null}
          {company?.address ? <p>{[company.address, company.city && `${company.city}/${company.state ?? ''}`].filter(Boolean).join(' — ')}</p> : null}
          <p>{[phone(company?.phone), company?.email].filter(Boolean).join(' · ')}</p>
          <p>{[company?.website_pimentera, company?.website_mixx].filter(Boolean).join(' · ')}</p>
          <p>Representante: {repName}</p>
        </div>
        <div>
          <h3 className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Cliente</h3>
          <p className="font-semibold">{c.legal_name}</p>
          {c.trade_name ? <p>Fantasia: {c.trade_name}</p> : null}
          <p>
            {c.person_type === 'PF' ? 'CPF' : 'CNPJ'}: {doc(String(c.document ?? '')) || '—'}
            {c.state_registration ? ` · IE ${c.state_registration}` : ''}
          </p>
          <p>
            {addr}
            {c.city ? ` — ${c.city}/${c.state ?? ''}` : ''}
            {c.cep ? ` — CEP ${cep(String(c.cep))}` : ''}
          </p>
          <p>
            Comprador: {c.buyer_name || '—'} · {phone(String(c.whatsapp || c.phone || '')) || '—'}
          </p>
          {c.email ? <p>{c.email}</p> : null}
        </div>
      </section>

      <section className="grid grid-cols-3 gap-4 border-b border-border py-3">
        <div className="col-span-2">
          <h3 className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Entrega</h3>
          <p>{order.delivery_address || '—'}</p>
          <p>Recebimento: {[c.receiver_name, phone(String(c.receiver_phone ?? ''))].filter(Boolean).join(' — ') || '—'}</p>
        </div>
        <div>
          <h3 className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Condições</h3>
          <p>Pagamento: {order.payment_term_snapshot?.name ?? '—'}</p>
          <p>Previsão de entrega: {date(order.expected_delivery)}</p>
        </div>
      </section>

      <table className="mt-3 w-full border-collapse">
        <thead>
          <tr className="border-b border-foreground text-left text-[10px] uppercase tracking-wider">
            <th className="py-1.5 pr-2">SKU</th>
            <th className="py-1.5 pr-2">Produto</th>
            <th className="py-1.5 pr-2">Marca</th>
            <th className="py-1.5 pr-2 text-right">Qtd.</th>
            <th className="py-1.5 pr-2">Un.</th>
            <th className="py-1.5 pr-2 text-right">Preço un.</th>
            <th className="py-1.5 pr-2 text-right">Desc.</th>
            <th className="py-1.5 text-right">Total</th>
          </tr>
        </thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.id} className="border-b border-border">
              <td className="py-1 pr-2 font-mono">{i.sku}</td>
              <td className="py-1 pr-2">{i.product_name}</td>
              <td className="py-1 pr-2">{BRAND_LABEL[i.brand_code] ?? i.brand_code}</td>
              <td className="py-1 pr-2 text-right tabular-nums">{num(i.quantity)}</td>
              <td className="py-1 pr-2">{i.unit}</td>
              <td className="py-1 pr-2 text-right tabular-nums">{money(i.unit_price)}</td>
              <td className="py-1 pr-2 text-right tabular-nums">{Number(i.discount_pct) ? `${num(i.discount_pct)}%` : '—'}</td>
              <td className="py-1 text-right font-medium tabular-nums">{money(i.line_total)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <section className="flex flex-wrap justify-between gap-4 pt-3">
        <div className="flex flex-col gap-0.5">
          <p>
            <strong>{num(units)}</strong> unidades em {items.length} itens
          </p>
          {Object.entries(byBrand).map(([b, v]) => (
            <p key={b}>
              {BRAND_LABEL[b] ?? b}: {num(v.units)} un. · {money(v.total)}
            </p>
          ))}
        </div>
        <dl className="grid min-w-56 grid-cols-2 gap-x-4 gap-y-0.5">
          <dt>Subtotal</dt>
          <dd className="text-right tabular-nums">{money(order.subtotal)}</dd>
          <dt>Descontos</dt>
          <dd className="text-right tabular-nums">− {money(order.discount_total)}</dd>
          <dt>Frete</dt>
          <dd className="text-right tabular-nums">{money(order.freight)}</dd>
          {Number(order.tax_total) ? (
            <>
              <dt>Impostos</dt>
              <dd className="text-right tabular-nums">{money(order.tax_total)}</dd>
            </>
          ) : null}
          <dt className="border-t border-foreground pt-1 text-sm font-bold">Total</dt>
          <dd className="border-t border-foreground pt-1 text-right text-sm font-bold tabular-nums">{money(order.total)}</dd>
        </dl>
      </section>

      {order.notes || company?.order_footer_notes ? (
        <section className="mt-3 border-t border-border pt-2">
          {order.notes ? (
            <p>
              <strong>Observações:</strong> {order.notes}
            </p>
          ) : null}
          {company?.order_footer_notes ? <p className="text-muted-foreground">{company.order_footer_notes}</p> : null}
        </section>
      ) : null}

      <footer className="mt-12 grid grid-cols-2 gap-10">
        <div className="border-t border-foreground pt-1 text-center">
          <p>{repName}</p>
          <p className="text-muted-foreground">Representante</p>
        </div>
        <div className="border-t border-foreground pt-1 text-center">
          <p>{c.buyer_name || 'Comprador'}</p>
          <p className="text-muted-foreground">Cliente — assinatura e carimbo</p>
        </div>
      </footer>
      <p className="mt-6 text-center text-[10px] text-muted-foreground">
        Documento sem valor fiscal. {[company?.instagram_pimentera, company?.instagram_mixx].filter(Boolean).join(' · ')}
      </p>
    </article>
  )
}
