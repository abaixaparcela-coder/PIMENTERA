'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Select, TextInput } from '@/components/crm/ui'
import { assignDelivery, proofUrl } from '@/lib/actions/operations'

export function AssignDeliveryForm({
  deliveryId,
  drivers,
  driverId,
  scheduled,
}: {
  deliveryId: string
  drivers: { id: string; full_name: string }[]
  driverId: string | null
  scheduled: string | null
}) {
  const router = useRouter()
  const [driver, setDriver] = useState(driverId ?? '')
  const [day, setDay] = useState(scheduled ?? '')
  const [pending, start] = useTransition()
  return (
    <div className="flex flex-col gap-3">
      <Field label="Entregador" htmlFor="as_driver">
        <Select id="as_driver" value={driver} onChange={(e) => setDriver(e.target.value)}>
          <option value="">Sem entregador</option>
          {drivers.map((d) => (
            <option key={d.id} value={d.id}>
              {d.full_name}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Data prevista" htmlFor="as_date">
        <TextInput id="as_date" type="date" value={day} onChange={(e) => setDay(e.target.value)} />
      </Field>
      <Button
        disabled={pending}
        onClick={() =>
          start(async () => {
            const r = await assignDelivery(deliveryId, driver || null, day || null)
            if (r.ok) {
              toast.success(r.message)
              router.refresh()
            } else toast.error(r.error)
          })
        }
      >
        {pending ? 'Salvando…' : 'Salvar atribuição'}
      </Button>
    </div>
  )
}

export function ProofLink({ deliveryId }: { deliveryId: string }) {
  const [pending, start] = useTransition()
  return (
    <Button
      variant="outline"
      size="sm"
      disabled={pending}
      onClick={() =>
        start(async () => {
          const r = await proofUrl(deliveryId)
          if (r.ok) window.open(r.data!.url, '_blank', 'noopener')
          else toast.error(r.error)
        })
      }
    >
      Ver comprovante
    </Button>
  )
}
