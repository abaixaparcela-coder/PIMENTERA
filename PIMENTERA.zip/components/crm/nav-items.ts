import type { ModuleKey } from '@/lib/constants'

export type NavItem = { href: string; label: string; module: ModuleKey; icon: string }

export const NAV_GROUPS: { label: string; items: NavItem[] }[] = [
  {
    label: 'Comercial',
    items: [
      { href: '/', label: 'Painel', module: 'dashboard', icon: 'gauge' },
      { href: '/pedidos/novo', label: 'Tirar pedido', module: 'visitas', icon: 'plus' },
      { href: '/pedidos', label: 'Pedidos', module: 'pedidos', icon: 'clipboard' },
      { href: '/clientes', label: 'Clientes', module: 'clientes', icon: 'store' },
      { href: '/visitas', label: 'Visitas', module: 'visitas', icon: 'map' },
      { href: '/produtos', label: 'Produtos', module: 'produtos', icon: 'package' },
    ],
  },
  {
    label: 'Operação',
    items: [
      { href: '/estoque', label: 'Estoque', module: 'estoque', icon: 'boxes' },
      { href: '/expedicao', label: 'Separação', module: 'expedicao', icon: 'check' },
      { href: '/entregas', label: 'Entregas', module: 'entregas', icon: 'truck' },
      { href: '/minhas-entregas', label: 'Minhas entregas', module: 'minhas-entregas', icon: 'route' },
    ],
  },
  {
    label: 'Financeiro',
    items: [
      { href: '/faturamento', label: 'Faturamento', module: 'faturamento', icon: 'receipt' },
      { href: '/financeiro', label: 'Contas a receber', module: 'financeiro', icon: 'wallet' },
      { href: '/relatorios', label: 'Relatórios', module: 'relatorios', icon: 'chart' },
    ],
  },
  {
    label: 'Administração',
    items: [
      { href: '/configuracoes', label: 'Configurações', module: 'configuracoes', icon: 'settings' },
      { href: '/configuracoes/usuarios', label: 'Usuários', module: 'configuracoes', icon: 'users' },
      { href: '/auditoria', label: 'Auditoria', module: 'auditoria', icon: 'shield' },
    ],
  },
]
