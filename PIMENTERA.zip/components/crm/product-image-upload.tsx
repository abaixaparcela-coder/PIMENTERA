'use client'

import { useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { uploadProductImage } from '@/lib/actions/products'

export function ProductImageUpload({ productId }: { productId: string }) {
  const [pending, start] = useTransition()
  const router = useRouter()
  return (
    <form
      action={(fd) =>
        start(async () => {
          const r = await uploadProductImage(productId, fd)
          if (r.ok) {
            toast.success(r.message ?? 'Enviado.')
            router.refresh()
          } else toast.error(r.error)
        })
      }
      className="flex flex-col gap-2"
    >
      <input type="file" name="file" accept="image/png,image/jpeg,image/webp" required className="text-xs" aria-label="Imagem do produto" />
      <Button type="submit" size="sm" variant="outline" disabled={pending}>
        {pending ? 'Enviando…' : 'Enviar imagem'}
      </Button>
    </form>
  )
}
