'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Select, TextArea, TextInput } from '@/components/crm/ui'
import { updateDelivery } from '@/lib/actions/operations'
import { num } from '@/lib/format'

type Item = { id: string; product_name: string; quantity: number }

const OUTCOMES = [
  { v: 'entregue', l: 'Entregue (tudo)' },
  { v: 'entrega_parcial', l: 'Entrega parcial' },
  { v: 'cliente_ausente', l: 'Cliente ausente' },
  { v: 'endereco_incorreto', l: 'Endereço incorreto' },
  { v: 'recusada', l: 'Recusada' },
  { v: 'reagendada', l: 'Reagendar' },
]

export function DeliveryResultForm({ deliveryId, status, items }: { deliveryId: string; status: string; items: Item[] }) {
  const router = useRouter()
  const [pending, start] = useTransition()
  const [outcome, setOutcome] = useState('entregue')
  const [qty, setQty] = useState<Record<string, number>>(() => Object.fromEntries(items.map((i) => [i.id, i.quantity])))

  function send(fd: FormData) {
    start(async () => {
      const r = await updateDelivery(fd)
      if (r.ok) {
        toast.success(r.message)
        router.refresh()
      } else toast.error(r.error)
    })
  }

  if (status === 'pronta' || status === 'reagendada') {
    return (
      <form action={send}>
        <input type="hidden" name="delivery_id" value={deliveryId} />
        <input type="hidden" name="status" value="em_rota" />
        <Button type="submit" size="lg" className="w-full" disabled={pending}>
          {pending ? 'Registrando…' : 'Registrar saída para entrega'}
        </Button>
      </form>
    )
  }
  if (status !== 'em_rota') return null

  const needsReceiver = outcome === 'entregue' || outcome === 'entrega_parcial'
  return (
    <form action={send} className="flex flex-col gap-3">
      <input type="hidden" name="delivery_id" value={deliveryId} />
      <input type="hidden" name="items" value={JSON.stringify(items.map((i) => ({ id: i.id, delivered_qty: qty[i.id] })))} />
      <Field label="Resultado" htmlFor="d_status">
        <Select id="d_status" name="status" value={outcome} onChange={(e) => setOutcome(e.target.value)}>
          {OUTCOMES.map((o) => (
            <option key={o.v} value={o.v}>
              {o.l}
            </option>
          ))}
        </Select>
      </Field>
      {outcome === 'entrega_parcial' ? (
        <fieldset className="flex flex-col gap-1.5 rounded-md border border-border p-2.5">
          <legend className="px-1 text-sm font-medium">Quantidades entregues</legend>
          {items.map((i) => (
            <label key={i.id} className="flex items-center justify-between gap-2 text-sm">
              <span className="truncate">
                {i.product_name} <span className="text-muted-foreground">(de {num(i.quantity)})</span>
              </span>
              <TextInput
                type="number"
                inputMode="numeric"
                min={0}
                max={i.quantity}
                value={qty[i.id]}
                onChange={(e) => setQty((p) => ({ ...p, [i.id]: Math.max(0, Math.min(i.quantity, Math.trunc(Number(e.target.value) || 0))) }))}
                className="h-8 w-20 text-right"
              />
            </label>
          ))}
        </fieldset>
      ) : null}
      {needsReceiver ? (
        <Field label="Nome de quem recebeu" htmlFor="d_recv" required>
          <TextInput id="d_recv" name="received_by" required autoComplete="off" />
        </Field>
      ) : null}
      {outcome === 'reagendada' ? (
        <Field label="Nova data" htmlFor="d_date">
          <TextInput id="d_date" type="date" name="scheduled_date" />
        </Field>
      ) : null}
      <Field label="Observações" htmlFor="d_notes">
        <TextArea id="d_notes" name="notes" rows={2} />
      </Field>
      {needsReceiver ? (
        <Field label="Foto do comprovante (opcional)" htmlFor="d_proof" hint="Canhoto assinado ou foto da mercadoria entregue.">
          <input id="d_proof" type="file" name="proof" accept="image/*" capture="environment" className="text-sm" />
        </Field>
      ) : null}
      <Button type="submit" size="lg" disabled={pending}>
        {pending ? 'Enviando…' : 'Confirmar resultado'}
      </Button>
    </form>
  )
}
