'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import {
  BarChart3,
  Boxes,
  ClipboardCheck,
  ClipboardList,
  Gauge,
  LogOut,
  Map,
  Menu,
  Package,
  PanelLeftClose,
  PanelLeftOpen,
  Plus,
  Receipt,
  Route,
  Settings,
  ShieldCheck,
  Store,
  Truck,
  Users,
  Wallet,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { MODULE_ROLES, ROLE_LABEL, type Role } from '@/lib/constants'
import { NAV_GROUPS } from './nav-items'
import { signOut } from '@/app/login/actions'

const ICONS = {
  gauge: Gauge,
  plus: Plus,
  clipboard: ClipboardList,
  store: Store,
  map: Map,
  package: Package,
  boxes: Boxes,
  check: ClipboardCheck,
  truck: Truck,
  route: Route,
  receipt: Receipt,
  wallet: Wallet,
  chart: BarChart3,
  settings: Settings,
  users: Users,
  shield: ShieldCheck,
} as const

type ShellProps = {
  user: { name: string; email: string; role: Role }
  notifications: { label: string; href: string; count: number }[]
  children: React.ReactNode
}

export function AppShell({ user, notifications, children }: ShellProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const pathname = usePathname()
  const totalAlerts = notifications.reduce((a, n) => a + n.count, 0)

  const groups = NAV_GROUPS.map((g) => ({
    ...g,
    items: g.items.filter((i) => MODULE_ROLES[i.module].includes(user.role)),
  })).filter((g) => g.items.length)

  const allHrefs = groups.flatMap((g) => g.items.map((i) => i.href))
  const activeHref = allHrefs
    .filter((h) => (h === '/' ? pathname === '/' : pathname === h || pathname.startsWith(`${h}/`)))
    .sort((a, b) => b.length - a.length)[0]
  const isActive = (href: string) => href === activeHref

  const nav = (
    <nav aria-label="Menu principal" className="flex flex-1 flex-col gap-4 overflow-y-auto px-2 py-3">
      {groups.map((g) => (
        <div key={g.label} className="flex flex-col gap-0.5">
          {!collapsed ? (
            <p className="px-2 pb-1 text-[11px] font-medium uppercase tracking-wider text-sidebar-foreground/50">{g.label}</p>
          ) : null}
          {g.items.map((item) => {
            const Icon = ICONS[item.icon as keyof typeof ICONS]
            const active = isActive(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                title={collapsed ? item.label : undefined}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'flex h-9 items-center gap-2.5 rounded-md px-2 text-sm transition-colors',
                  active
                    ? 'bg-sidebar-primary font-medium text-sidebar-primary-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                  collapsed && 'justify-center',
                )}
              >
                <Icon className="size-4 shrink-0" aria-hidden="true" />
                {!collapsed ? <span className="truncate">{item.label}</span> : <span className="sr-only">{item.label}</span>}
              </Link>
            )
          })}
        </div>
      ))}
    </nav>
  )

  const brand = (
    <div className={cn('flex h-14 items-center gap-2 border-b border-sidebar-border px-3', collapsed && 'justify-center px-0')}>
      <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-primary font-mono text-sm font-semibold text-primary-foreground">
        P+M
      </span>
      {!collapsed ? (
        <div className="flex min-w-0 flex-col leading-tight">
          <span className="truncate text-sm font-semibold text-sidebar-accent-foreground">CRM Pimentera</span>
          <span className="truncate text-xs text-sidebar-primary">+ Mixx Condimentos</span>
        </div>
      ) : null}
    </div>
  )

  return (
    <div className="flex min-h-dvh">
      <aside
        className={cn(
          'no-print sticky top-0 hidden h-dvh shrink-0 flex-col bg-sidebar text-sidebar-foreground transition-[width] md:flex',
          collapsed ? 'w-16' : 'w-60',
        )}
      >
        {brand}
        {nav}
        <div className="border-t border-sidebar-border p-2">
          <button
            type="button"
            onClick={() => setCollapsed((c) => !c)}
            className={cn(
              'flex h-9 w-full items-center gap-2 rounded-md px-2 text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent',
              collapsed && 'justify-center',
            )}
          >
            {collapsed ? <PanelLeftOpen className="size-4" aria-hidden="true" /> : <PanelLeftClose className="size-4" aria-hidden="true" />}
            {collapsed ? <span className="sr-only">Expandir menu</span> : <span>Recolher menu</span>}
          </button>
        </div>
      </aside>

      {mobileOpen ? (
        <div className="no-print fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <button type="button" className="absolute inset-0 bg-foreground/50" onClick={() => setMobileOpen(false)}>
            <span className="sr-only">Fechar menu</span>
          </button>
          <aside className="relative flex h-full w-72 flex-col bg-sidebar text-sidebar-foreground">
            <div className="flex items-center justify-between pr-2">
              {brand}
              <button type="button" onClick={() => setMobileOpen(false)} className="rounded-md p-2 hover:bg-sidebar-accent">
                <X className="size-5" aria-hidden="true" />
                <span className="sr-only">Fechar menu</span>
              </button>
            </div>
            {nav}
          </aside>
        </div>
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="no-print sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-border bg-card/95 px-3 backdrop-blur md:px-6">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="rounded-md p-2 hover:bg-accent md:hidden"
          >
            <Menu className="size-5" aria-hidden="true" />
            <span className="sr-only">Abrir menu</span>
          </button>
          <p className="hidden truncate text-sm text-muted-foreground sm:block">Pimentera Foods + Mixx Condimentos</p>
          <div className="ml-auto flex items-center gap-2">
            <details className="relative">
              <summary className="flex h-9 cursor-pointer list-none items-center gap-1.5 rounded-md border border-border px-2.5 text-sm hover:bg-accent">
                <span>Alertas</span>
                <span
                  className={cn(
                    'inline-flex min-w-5 items-center justify-center rounded-sm px-1 font-mono text-xs',
                    totalAlerts ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground',
                  )}
                >
                  {totalAlerts}
                </span>
              </summary>
              <div className="absolute right-0 mt-1 w-72 rounded-md border border-border bg-popover p-1 shadow-lg">
                {notifications.length === 0 ? (
                  <p className="px-3 py-2 text-sm text-muted-foreground">Nenhum alerta no momento.</p>
                ) : (
                  notifications.map((n) => (
                    <Link
                      key={n.label}
                      href={n.href}
                      className="flex items-center justify-between rounded-sm px-3 py-2 text-sm hover:bg-accent"
                    >
                      <span>{n.label}</span>
                      <span className="font-mono text-xs">{n.count}</span>
                    </Link>
                  ))
                )}
              </div>
            </details>
            <div className="hidden flex-col items-end leading-tight sm:flex">
              <span className="text-sm font-medium">{user.name || user.email}</span>
              <span className="text-xs text-muted-foreground">{ROLE_LABEL[user.role]}</span>
            </div>
            <form action={signOut}>
              <button type="submit" className="flex h-9 items-center gap-1.5 rounded-md px-2 text-sm hover:bg-accent">
                <LogOut className="size-4" aria-hidden="true" />
                <span className="sr-only sm:not-sr-only">Sair</span>
              </button>
            </form>
          </div>
        </header>
        <main className="flex flex-1 flex-col gap-5 p-3 md:p-6">{children}</main>
      </div>
    </div>
  )
}
