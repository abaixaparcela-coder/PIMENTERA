'use client'

import { useRef, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Select, TextArea, TextInput } from '@/components/crm/ui'
import {
  addPaymentMethod,
  addPaymentTerm,
  createUser,
  resetUserPassword,
  togglePaymentMethod,
  togglePaymentTerm,
  updateSettings,
  updateUser,
  uploadLogo,
} from '@/lib/actions/admin'
import type { ActionResult } from '@/lib/auth'
import { ROLE_LABEL } from '@/lib/constants'

function useAction(reset = false) {
  const router = useRouter()
  const formRef = useRef<HTMLFormElement>(null)
  const [pending, start] = useTransition()
  const run = (fn: () => Promise<ActionResult>) =>
    start(async () => {
      const r = await fn()
      if (r.ok) {
        if (r.message) toast.success(r.message)
        if (reset) formRef.current?.reset()
        router.refresh()
      } else toast.error(r.error)
    })
  return { pending, run, formRef }
}

const ROLE_OPTIONS = Object.entries(ROLE_LABEL)

export function NewUserForm() {
  const { pending, run, formRef } = useAction(true)
  return (
    <form ref={formRef} action={(fd) => run(() => createUser(fd))} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      <Field label="Nome completo" htmlFor="nu_name">
        <TextInput id="nu_name" name="full_name" required maxLength={120} />
      </Field>
      <Field label="E-mail (login)" htmlFor="nu_email">
        <TextInput id="nu_email" name="email" type="email" required autoComplete="off" />
      </Field>
      <Field label="Telefone" htmlFor="nu_phone">
        <TextInput id="nu_phone" name="phone" inputMode="tel" maxLength={20} />
      </Field>
      <Field label="Senha inicial" htmlFor="nu_pass" hint="Mínimo de 8 caracteres">
        <TextInput id="nu_pass" name="password" type="password" required minLength={8} autoComplete="new-password" />
      </Field>
      <Field label="Perfil" htmlFor="nu_role">
        <Select id="nu_role" name="role" defaultValue="comercial">
          {ROLE_OPTIONS.map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Desconto máximo sem aprovação (%)" htmlFor="nu_disc">
        <TextInput id="nu_disc" name="max_discount_pct" type="number" min={0} max={100} step="0.5" defaultValue={5} />
      </Field>
      <div className="sm:col-span-2 lg:col-span-3">
        <Button type="submit" disabled={pending}>
          {pending ? 'Criando…' : 'Criar usuário'}
        </Button>
      </div>
    </form>
  )
}

type UserRow = {
  id: string
  full_name: string
  phone: string | null
  role: string
  active: boolean
  max_discount_pct: number
  allow_negative_stock: boolean
}

export function UserRowForm({ user }: { user: UserRow }) {
  const { pending, run } = useAction()
  const p = user.id.slice(0, 8)
  return (
    <form action={(fd) => run(() => updateUser(fd))} className="grid gap-2 sm:grid-cols-2 lg:grid-cols-6 lg:items-end">
      <input type="hidden" name="id" value={user.id} />
      <Field label="Nome" htmlFor={`u_n_${p}`} className="lg:col-span-2">
        <TextInput id={`u_n_${p}`} name="full_name" defaultValue={user.full_name} required />
      </Field>
      <Field label="Telefone" htmlFor={`u_t_${p}`}>
        <TextInput id={`u_t_${p}`} name="phone" defaultValue={user.phone ?? ''} />
      </Field>
      <Field label="Perfil" htmlFor={`u_r_${p}`}>
        <Select id={`u_r_${p}`} name="role" defaultValue={user.role}>
          {ROLE_OPTIONS.map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Situação" htmlFor={`u_a_${p}`}>
        <Select id={`u_a_${p}`} name="active" defaultValue={String(user.active)}>
          <option value="true">Ativo</option>
          <option value="false">Inativo</option>
        </Select>
      </Field>
      <Field label="Desc. máx. (%)" htmlFor={`u_d_${p}`}>
        <TextInput id={`u_d_${p}`} name="max_discount_pct" type="number" min={0} max={100} step="0.5" defaultValue={user.max_discount_pct} />
      </Field>
      <Field label="Estoque negativo" htmlFor={`u_s_${p}`} className="lg:col-span-2">
        <Select id={`u_s_${p}`} name="allow_negative_stock" defaultValue={String(user.allow_negative_stock)}>
          <option value="false">Não permitido</option>
          <option value="true">Permitido (auditado)</option>
        </Select>
      </Field>
      <div className="flex gap-2 lg:col-span-4">
        <Button type="submit" size="sm" disabled={pending}>
          {pending ? 'Salvando…' : 'Salvar'}
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          disabled={pending}
          onClick={() => {
            const pw = window.prompt('Nova senha (mínimo 8 caracteres):')
            if (pw) run(() => resetUserPassword(user.id, pw))
          }}
        >
          Redefinir senha
        </Button>
      </div>
    </form>
  )
}

type Settings = Record<string, string | number | null>

export function SettingsForm({ s }: { s: Settings }) {
  const { pending, run } = useAction()
  const v = (k: string) => (s[k] ?? '') as string
  const fields: [string, string, string?][] = [
    ['company_name', 'Nome do sistema / empresa'],
    ['legal_name', 'Razão social'],
    ['cnpj', 'CNPJ'],
    ['state_registration', 'Inscrição estadual'],
    ['address', 'Endereço'],
    ['city', 'Cidade'],
    ['state', 'UF'],
    ['phone', 'Telefone comercial'],
    ['email', 'E-mail comercial', 'email'],
    ['website_pimentera', 'Site Pimentera'],
    ['website_mixx', 'Site Mixx'],
    ['instagram_pimentera', 'Instagram Pimentera'],
    ['instagram_mixx', 'Instagram Mixx'],
  ]
  return (
    <form action={(fd) => run(() => updateSettings(fd))} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {fields.map(([k, label, type]) => (
        <Field key={k} label={label} htmlFor={`cfg_${k}`}>
          <TextInput id={`cfg_${k}`} name={k} type={type ?? 'text'} defaultValue={v(k)} required={k === 'company_name'} maxLength={k === 'state' ? 2 : 200} />
        </Field>
      ))}
      <Field label="Frete padrão (R$)" htmlFor="cfg_freight">
        <TextInput id="cfg_freight" name="default_freight" inputMode="decimal" defaultValue={String(s.default_freight ?? 0)} />
      </Field>
      <Field label="Observações no rodapé do pedido" htmlFor="cfg_footer" className="sm:col-span-2 lg:col-span-3">
        <TextArea id="cfg_footer" name="order_footer_notes" rows={3} defaultValue={v('order_footer_notes')} maxLength={1000} />
      </Field>
      <div className="sm:col-span-2 lg:col-span-3">
        <Button type="submit" disabled={pending}>
          {pending ? 'Salvando…' : 'Salvar dados da empresa'}
        </Button>
      </div>
    </form>
  )
}

export function LogoUploadForm({ brand, label, current }: { brand: 'pimentera' | 'mixx'; label: string; current: string | null }) {
  const { pending, run, formRef } = useAction(true)
  return (
    <form ref={formRef} action={(fd) => run(() => uploadLogo(fd))} className="flex flex-col gap-3 rounded-md border border-border p-3">
      <input type="hidden" name="brand" value={brand} />
      <span className="text-sm font-medium">{label}</span>
      <div className="flex h-20 items-center justify-center rounded bg-muted">
        {current ? (
          // eslint-disable-next-line @next/next/no-img-element -- signed private URL, not optimizable
          <img src={current} alt={`Logo ${label}`} className="max-h-16 max-w-full object-contain" />
        ) : (
          <span className="text-xs text-muted-foreground">Nenhuma logo enviada</span>
        )}
      </div>
      <input
        name="file"
        type="file"
        accept="image/png,image/jpeg,image/webp,image/svg+xml"
        required
        aria-label={`Arquivo da logo ${label}`}
        className="text-xs file:mr-2 file:rounded file:border-0 file:bg-secondary file:px-2 file:py-1 file:text-xs"
      />
      <Button type="submit" size="sm" variant="outline" disabled={pending}>
        {pending ? 'Enviando…' : 'Enviar logo oficial'}
      </Button>
    </form>
  )
}

export function PaymentTermsEditor({ terms }: { terms: { id: string; name: string; days: number[]; active: boolean }[] }) {
  const { pending, run, formRef } = useAction(true)
  return (
    <div className="flex flex-col gap-3">
      <ul className="flex flex-col divide-y divide-border text-sm">
        {terms.map((t) => (
          <li key={t.id} className="flex items-center justify-between gap-2 py-2">
            <span className={t.active ? '' : 'text-muted-foreground line-through'}>
              {t.name} <span className="text-xs text-muted-foreground">({t.days.join('/')} dias)</span>
            </span>
            <Button size="sm" variant="ghost" disabled={pending} onClick={() => run(() => togglePaymentTerm(t.id, !t.active))}>
              {t.active ? 'Desativar' : 'Ativar'}
            </Button>
          </li>
        ))}
      </ul>
      <form ref={formRef} action={(fd) => run(() => addPaymentTerm(fd))} className="flex flex-wrap items-end gap-2">
        <Field label="Nova condição" htmlFor="pt_name">
          <TextInput id="pt_name" name="name" placeholder="Ex.: 28/56 dias" required />
        </Field>
        <Field label="Prazos (dias)" htmlFor="pt_days">
          <TextInput id="pt_days" name="days" placeholder="28,56" required className="w-28" />
        </Field>
        <Button type="submit" size="sm" disabled={pending}>
          Adicionar
        </Button>
      </form>
    </div>
  )
}

export function PaymentMethodsEditor({ methods }: { methods: { id: string; name: string; active: boolean }[] }) {
  const { pending, run, formRef } = useAction(true)
  return (
    <div className="flex flex-col gap-3">
      <ul className="flex flex-col divide-y divide-border text-sm">
        {methods.map((m) => (
          <li key={m.id} className="flex items-center justify-between gap-2 py-2">
            <span className={m.active ? '' : 'text-muted-foreground line-through'}>{m.name}</span>
            <Button size="sm" variant="ghost" disabled={pending} onClick={() => run(() => togglePaymentMethod(m.id, !m.active))}>
              {m.active ? 'Desativar' : 'Ativar'}
            </Button>
          </li>
        ))}
      </ul>
      <form ref={formRef} action={(fd) => run(() => addPaymentMethod(fd))} className="flex items-end gap-2">
        <Field label="Nova forma" htmlFor="pm_name">
          <TextInput id="pm_name" name="name" required />
        </Field>
        <Button type="submit" size="sm" disabled={pending}>
          Adicionar
        </Button>
      </form>
    </div>
  )
}
