'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Select, TextInput } from '@/components/crm/ui'
import { registerPayment } from '@/lib/actions/operations'
import { todayISO } from '@/lib/format'

const toNum = (v: FormDataEntryValue | null) => Number(String(v ?? '0').replace(',', '.') || 0)

export function PaymentForm({ installmentId, balance, methods }: { installmentId: string; balance: number; methods: string[] }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [key, setKey] = useState(() => crypto.randomUUID())
  const [pending, start] = useTransition()
  const p = installmentId.slice(0, 8)

  if (!open)
    return (
      <Button size="sm" variant="outline" onClick={() => setOpen(true)}>
        Baixar
      </Button>
    )

  function submit(fd: FormData) {
    start(async () => {
      const r = await registerPayment({
        installment_id: installmentId,
        idempotency_key: key,
        amount: toNum(fd.get('amount')),
        interest: toNum(fd.get('interest')),
        discount: toNum(fd.get('discount')),
        paid_at: String(fd.get('paid_at') ?? ''),
        method: String(fd.get('method') ?? ''),
        notes: String(fd.get('notes') ?? ''),
      })
      if (r.ok) {
        toast.success(r.message)
        setKey(crypto.randomUUID())
        setOpen(false)
        router.refresh()
      } else toast.error(r.error)
    })
  }

  return (
    <form action={submit} className="grid min-w-72 grid-cols-2 gap-2 rounded-md border border-border bg-muted/40 p-3 text-left">
      <Field label="Valor recebido" htmlFor={`pa_${p}`}>
        <TextInput id={`pa_${p}`} name="amount" inputMode="decimal" defaultValue={balance.toFixed(2)} required />
      </Field>
      <Field label="Data" htmlFor={`pd_${p}`}>
        <TextInput id={`pd_${p}`} name="paid_at" type="date" defaultValue={todayISO()} required />
      </Field>
      <Field label="Juros (R$)" htmlFor={`pi_${p}`}>
        <TextInput id={`pi_${p}`} name="interest" inputMode="decimal" defaultValue="0" />
      </Field>
      <Field label="Desconto (R$)" htmlFor={`pc_${p}`}>
        <TextInput id={`pc_${p}`} name="discount" inputMode="decimal" defaultValue="0" />
      </Field>
      <Field label="Forma" htmlFor={`pm_${p}`} className="col-span-2">
        <Select id={`pm_${p}`} name="method" required defaultValue={methods[0] ?? ''}>
          {methods.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </Select>
      </Field>
      <Field label="Observação" htmlFor={`pn_${p}`} className="col-span-2">
        <TextInput id={`pn_${p}`} name="notes" maxLength={500} />
      </Field>
      <div className="col-span-2 flex gap-2">
        <Button type="submit" size="sm" disabled={pending}>
          {pending ? 'Salvando…' : 'Confirmar'}
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={() => setOpen(false)}>
          Cancelar
        </Button>
      </div>
    </form>
  )
}
