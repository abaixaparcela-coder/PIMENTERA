'use client'

import { useActionState } from 'react'
import { Button } from '@/components/ui/button'
import { Field, TextInput } from '@/components/crm/ui'
import type { AuthState } from '@/app/login/actions'

export function AuthForm({
  action,
  mode,
}: {
  action: (prev: AuthState, fd: FormData) => Promise<AuthState>
  mode: 'login' | 'setup'
}) {
  const [state, formAction, pending] = useActionState(action, undefined)
  return (
    <form action={formAction} className="flex flex-col gap-4">
      {mode === 'setup' ? (
        <Field label="Nome completo" htmlFor="full_name">
          <TextInput id="full_name" name="full_name" required autoComplete="name" />
        </Field>
      ) : null}
      <Field label="E-mail" htmlFor="email">
        <TextInput id="email" name="email" type="email" required autoComplete="email" inputMode="email" />
      </Field>
      <Field label="Senha" htmlFor="password" hint={mode === 'setup' ? 'Mínimo de 10 caracteres.' : undefined}>
        <TextInput
          id="password"
          name="password"
          type="password"
          required
          autoComplete={mode === 'setup' ? 'new-password' : 'current-password'}
        />
      </Field>
      {state?.error ? (
        <p role="alert" className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {state.error}
        </p>
      ) : null}
      <Button type="submit" size="lg" disabled={pending} className="h-10">
        {pending ? 'Aguarde…' : mode === 'setup' ? 'Criar administrador' : 'Entrar'}
      </Button>
    </form>
  )
}
