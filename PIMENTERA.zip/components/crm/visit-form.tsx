'use client'

import { useActionState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Notice } from '@/components/crm/customer-form'
import { Field, Select, TextArea, TextInput } from '@/components/crm/ui'
import { saveVisit } from '@/lib/actions/customers'
import type { ActionResult } from '@/lib/auth'
import { VISIT_RESULT_LABEL } from '@/lib/constants'

function nowLocal() {
  const d = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }))
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
}

export function VisitForm({ customers, fixedCustomerId }: { customers?: { id: string; name: string }[]; fixedCustomerId?: string }) {
  const [state, action, pending] = useActionState<ActionResult | undefined, FormData>(saveVisit, undefined)
  const ref = useRef<HTMLFormElement>(null)
  useEffect(() => {
    if (state?.ok) ref.current?.reset()
  }, [state])

  return (
    <form ref={ref} action={action} className="flex flex-col gap-3">
      {state ? <Notice kind={state.ok ? 'ok' : 'error'}>{state.ok ? state.message : state.error}</Notice> : null}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {fixedCustomerId ? (
          <input type="hidden" name="customer_id" value={fixedCustomerId} />
        ) : (
          <Field label="Cliente *" htmlFor="v-customer" className="sm:col-span-2">
            <Select id="v-customer" name="customer_id" required defaultValue="">
              <option value="" disabled>
                Selecione…
              </option>
              {(customers ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
        )}
        <Field label="Data e hora *" htmlFor="v-at">
          <TextInput id="v-at" name="visited_at" type="datetime-local" required defaultValue={nowLocal()} />
        </Field>
        <Field label="Resultado *" htmlFor="v-result">
          <Select id="v-result" name="result" required defaultValue="prospeccao">
            {Object.entries(VISIT_RESULT_LABEL).map(([k, l]) => (
              <option key={k} value={k}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Observações" htmlFor="v-notes" className="sm:col-span-2">
          <TextArea id="v-notes" name="notes" rows={3} />
        </Field>
        <Field label="Próxima ação" htmlFor="v-next">
          <TextInput id="v-next" name="next_action" placeholder="Ex.: retornar com amostras" />
        </Field>
        <Field label="Data da próxima ação" htmlFor="v-next-date">
          <TextInput id="v-next-date" name="next_action_date" type="date" />
        </Field>
      </div>
      <div className="flex justify-end">
        <Button type="submit" disabled={pending}>
          {pending ? 'Registrando…' : 'Registrar visita'}
        </Button>
      </div>
    </form>
  )
}
