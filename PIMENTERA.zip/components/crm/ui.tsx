import Link from 'next/link'
import { cn } from '@/lib/utils'
import type { StatusTone } from '@/lib/constants'

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string
  description?: string
  actions?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-3 border-b border-border pb-4 md:flex-row md:items-end md:justify-between">
      <div className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold tracking-tight text-balance md:text-2xl">{title}</h1>
        {description ? <p className="text-sm text-muted-foreground text-pretty">{description}</p> : null}
      </div>
      {actions ? <div className="no-print flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  )
}

const toneClass: Record<StatusTone, string> = {
  neutral: 'bg-muted text-muted-foreground border-border',
  info: 'bg-foreground/5 text-foreground border-foreground/15',
  warn: 'bg-mustard/25 text-foreground border-mustard/60',
  ok: 'bg-success/12 text-success border-success/30',
  bad: 'bg-destructive/10 text-destructive border-destructive/30',
}

export function StatusBadge({ tone, children }: { tone: StatusTone; children: React.ReactNode }) {
  return (
    <span
      className={cn(
        'inline-flex h-6 items-center whitespace-nowrap rounded-sm border px-2 text-xs font-medium',
        toneClass[tone],
      )}
    >
      {children}
    </span>
  )
}

export function BrandTag({ code }: { code: string }) {
  return (
    <span
      className={cn(
        'inline-flex h-5 items-center rounded-sm px-1.5 font-mono text-[11px] font-medium uppercase tracking-wide',
        code === 'pimentera' ? 'bg-primary text-primary-foreground' : 'bg-foreground text-mustard',
      )}
    >
      {code === 'pimentera' ? 'Pimentera' : 'Mixx'}
    </span>
  )
}

export function EmptyState({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border bg-card px-6 py-12 text-center">
      <p className="font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground text-pretty">{description}</p> : null}
      {action ? <div className="pt-2">{action}</div> : null}
    </div>
  )
}

export function Panel({
  title,
  description,
  actions,
  children,
  className,
}: {
  title?: string
  description?: string
  actions?: React.ReactNode
  children: React.ReactNode
  className?: string
}) {
  return (
    <section className={cn('flex flex-col rounded-md border border-border bg-card', className)}>
      {title ? (
        <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-2.5">
          <div className="flex flex-col">
            <h2 className="text-sm font-semibold">{title}</h2>
            {description ? <p className="text-xs text-muted-foreground">{description}</p> : null}
          </div>
          {actions}
        </div>
      ) : null}
      <div className="flex flex-col p-4">{children}</div>
    </section>
  )
}

export function DataTable({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('overflow-x-auto rounded-md border border-border bg-card', className)}>
      <table className="w-full min-w-max border-collapse text-sm [&_td]:border-t [&_td]:border-border [&_td]:px-3 [&_td]:py-2 [&_th]:bg-muted [&_th]:px-3 [&_th]:py-2 [&_th]:text-left [&_th]:text-xs [&_th]:font-medium [&_th]:uppercase [&_th]:tracking-wide [&_th]:text-muted-foreground [&_tbody_tr:hover]:bg-accent/50">
        {children}
      </table>
    </div>
  )
}

export function DefList({ items }: { items: [string, React.ReactNode][] }) {
  return (
    <dl className="grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-2">
      {items.map(([k, v]) => (
        <div key={k} className="flex flex-col gap-0.5">
          <dt className="text-xs uppercase tracking-wide text-muted-foreground">{k}</dt>
          <dd className="text-sm">{v || '—'}</dd>
        </div>
      ))}
    </dl>
  )
}

export function LinkButton({
  href,
  children,
  variant = 'primary',
  className,
}: {
  href: string
  children: React.ReactNode
  variant?: 'primary' | 'outline' | 'ghost'
  className?: string
}) {
  return (
    <Link
      href={href}
      className={cn(
        'inline-flex h-9 items-center justify-center gap-1.5 whitespace-nowrap rounded-md px-3 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-ring [&_svg]:size-4',
        variant === 'primary' && 'bg-primary text-primary-foreground hover:bg-primary/90',
        variant === 'outline' && 'border border-input bg-card hover:bg-accent',
        variant === 'ghost' && 'hover:bg-accent',
        className,
      )}
    >
      {children}
    </Link>
  )
}

export const fieldClass =
  'h-9 w-full rounded-md border border-input bg-card px-2.5 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/25 disabled:opacity-60 aria-invalid:border-destructive'

export function Field({
  label,
  htmlFor,
  hint,
  error,
  required,
  className,
  children,
}: {
  label: string
  htmlFor?: string
  hint?: string
  error?: string
  required?: boolean
  className?: string
  children: React.ReactNode
}) {
  return (
    <div className={cn('flex flex-col gap-1', className)}>
      <label htmlFor={htmlFor} className="text-xs font-medium text-foreground">
        {label}
        {required ? (
          <span aria-hidden="true" className="text-destructive">
            {' *'}
          </span>
        ) : null}
      </label>
      {children}
      {error ? (
        <p className="text-xs text-destructive">{error}</p>
      ) : hint ? (
        <p className="text-xs text-muted-foreground">{hint}</p>
      ) : null}
    </div>
  )
}

export function Select({ className, ...props }: React.ComponentProps<'select'>) {
  return <select className={cn(fieldClass, 'pr-7', className)} {...props} />
}

export function TextInput({ className, ...props }: React.ComponentProps<'input'>) {
  return <input className={cn(fieldClass, className)} {...props} />
}

export function TextArea({ className, ...props }: React.ComponentProps<'textarea'>) {
  return <textarea className={cn(fieldClass, 'h-auto min-h-20 py-2 leading-relaxed', className)} {...props} />
}
