'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { TextArea } from '@/components/crm/ui'
import { changeOrderStatus } from '@/lib/actions/orders'

export type TransitionOption = { to: string; label: string; destructive?: boolean; needsNotes?: boolean }

export function OrderStatusActions({ orderId, options }: { orderId: string; options: TransitionOption[] }) {
  const router = useRouter()
  const [pending, start] = useTransition()
  const [active, setActive] = useState<TransitionOption | null>(null)
  const [notes, setNotes] = useState('')

  if (!options.length) return null

  function run(opt: TransitionOption, n?: string) {
    start(async () => {
      const r = await changeOrderStatus(orderId, opt.to, n)
      if (r.ok) {
        toast.success(r.message ?? 'Status atualizado.')
        setActive(null)
        setNotes('')
        router.refresh()
      } else toast.error(r.error)
    })
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <Button
            key={o.to}
            type="button"
            variant={o.destructive ? 'outline' : 'default'}
            className={o.destructive ? 'text-destructive hover:text-destructive' : undefined}
            disabled={pending}
            onClick={() => (o.needsNotes || o.destructive ? setActive(o) : run(o))}
          >
            {o.label}
          </Button>
        ))}
      </div>
      {active ? (
        <div className="flex flex-col gap-2 rounded-md border border-border bg-muted/50 p-3">
          <label htmlFor="st_notes" className="text-sm font-medium">
            {active.destructive ? 'Motivo (obrigatório)' : 'Observação'}
          </label>
          <TextArea id="st_notes" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} autoFocus />
          <div className="flex gap-2">
            <Button
              type="button"
              variant={active.destructive ? 'destructive' : 'default'}
              disabled={pending || (active.destructive && !notes.trim())}
              onClick={() => run(active, notes)}
            >
              {pending ? 'Processando…' : `Confirmar: ${active.label}`}
            </Button>
            <Button type="button" variant="ghost" onClick={() => setActive(null)}>
              Voltar
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
