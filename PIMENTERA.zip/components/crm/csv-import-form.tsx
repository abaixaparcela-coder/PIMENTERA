'use client'

import { useActionState, useEffect } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { importProductsCsv } from '@/lib/actions/products'
import type { ActionResult } from '@/lib/auth'

export function CsvImportForm() {
  const [state, action, pending] = useActionState<ActionResult | undefined, FormData>(importProductsCsv, undefined)
  useEffect(() => {
    if (!state) return
    if (state.ok) toast.success(state.message ?? 'Importado.')
    else toast.error(state.error)
  }, [state])
  return (
    <details className="no-print rounded-md border border-border bg-card px-4 py-2 text-sm">
      <summary className="cursor-pointer font-medium">Importar produtos por CSV</summary>
      <div className="flex flex-col gap-3 py-3">
        <p className="text-muted-foreground leading-relaxed">
          Separador ponto e vírgula ou vírgula. Colunas: <code className="font-mono text-xs">sku; nome; marca; categoria; descricao; conteudo; unidade; codigo_barras; custo; preco; preco_minimo; estoque_minimo; ativo; observacoes</code>.
          Produtos com SKU existente são atualizados. O estoque não é importado — registre entradas no módulo Estoque.
        </p>
        <form action={action} className="flex flex-wrap items-center gap-2">
          <input type="file" name="file" accept=".csv,text/csv" required className="text-sm file:mr-2 file:rounded-md file:border file:border-input file:bg-card file:px-3 file:py-1.5" />
          <Button type="submit" size="sm" disabled={pending}>
            {pending ? 'Importando…' : 'Importar'}
          </Button>
          {state && state.ok && state.message?.includes('erro') ? <p className="text-xs text-muted-foreground">{state.message}</p> : null}
        </form>
      </div>
    </details>
  )
}
