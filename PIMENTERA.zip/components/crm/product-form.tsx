'use client'

import { useActionState, useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Field, Panel, Select, TextArea, TextInput } from '@/components/crm/ui'
import { saveProduct, type ProductActionState } from '@/lib/actions/products'
import { money as formatBRL } from '@/lib/format'

export type ProductFormValues = {
  id?: string
  sku?: string
  name?: string
  brand_id?: number
  category_id?: string | null
  description?: string | null
  net_content?: string | null
  unit?: string
  barcode?: string | null
  cost?: number | null
  price?: number | null
  min_price?: number | null
  stock_min?: number
  active?: boolean
  notes?: string | null
}

const toInput = (v: number | null | undefined) => (v === null || v === undefined ? '' : String(v).replace('.', ','))
const toNum = (v: string) => (v.trim() ? Number(v.replace(/\./g, '').replace(',', '.')) : null)

export function ProductForm({
  initial,
  brands,
  categories,
  units,
}: {
  initial: ProductFormValues
  brands: { id: number; name: string }[]
  categories: { id: string; name: string }[]
  units: { code: string; description: string }[]
}) {
  const router = useRouter()
  const action = saveProduct.bind(null, initial.id ?? null)
  const [state, formAction, pending] = useActionState<ProductActionState | undefined, FormData>(action, undefined)
  const [cost, setCost] = useState(toInput(initial.cost))
  const [price, setPrice] = useState(toInput(initial.price))
  const fe = state && !state.ok ? state.fieldErrors : undefined

  useEffect(() => {
    if (!state) return
    if (state.ok) {
      toast.success(state.message ?? 'Salvo.')
      router.push(`/produtos/${state.data?.id}`)
    } else toast.error(state.error)
  }, [state, router])

  const margin = useMemo(() => {
    const c = toNum(cost)
    const p = toNum(price)
    if (c === null || p === null || p === 0) return null
    return ((p - c) / p) * 100
  }, [cost, price])

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <Panel title="Identificação">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="SKU / código interno *" htmlFor="sku" error={fe?.sku}>
            <TextInput id="sku" name="sku" defaultValue={initial.sku} required className="font-mono uppercase" aria-invalid={!!fe?.sku} />
          </Field>
          <Field label="Nome comercial *" htmlFor="name" error={fe?.name} className="sm:col-span-2">
            <TextInput id="name" name="name" defaultValue={initial.name} required aria-invalid={!!fe?.name} />
          </Field>
          <Field label="Marca *" htmlFor="brand_id">
            <Select id="brand_id" name="brand_id" defaultValue={initial.brand_id ?? brands[0]?.id}>
              {brands.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Categoria" htmlFor="category_id">
            <Select id="category_id" name="category_id" defaultValue={initial.category_id ?? ''}>
              <option value="">—</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Conteúdo líquido / peso" htmlFor="net_content" hint="Ex.: 150 ml, 60 g">
            <TextInput id="net_content" name="net_content" defaultValue={initial.net_content ?? ''} />
          </Field>
          <Field label="Unidade de venda" htmlFor="unit">
            <Select id="unit" name="unit" defaultValue={initial.unit ?? 'UN'}>
              {units.map((u) => (
                <option key={u.code} value={u.code}>
                  {u.code} — {u.description}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Código de barras (EAN)" htmlFor="barcode" error={fe?.barcode}>
            <TextInput id="barcode" name="barcode" inputMode="numeric" defaultValue={initial.barcode ?? ''} className="font-mono" aria-invalid={!!fe?.barcode} />
          </Field>
          <Field label="Descrição" htmlFor="description" className="sm:col-span-2 lg:col-span-4">
            <TextArea id="description" name="description" defaultValue={initial.description ?? ''} rows={2} />
          </Field>
        </div>
      </Panel>

      <Panel title="Preços e estoque">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="Custo (R$)" htmlFor="cost" error={fe?.cost}>
            <TextInput id="cost" name="cost" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="Não informado" />
          </Field>
          <Field label="Preço de venda (R$)" htmlFor="price" error={fe?.price}>
            <TextInput id="price" name="price" inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Não informado" />
          </Field>
          <Field label="Preço mínimo (R$)" htmlFor="min_price" error={fe?.min_price}>
            <TextInput id="min_price" name="min_price" inputMode="decimal" defaultValue={toInput(initial.min_price)} placeholder="Não informado" />
          </Field>
          <Field label="Margem calculada">
            <p className="flex h-9 items-center rounded-md border border-dashed border-border px-2.5 font-mono text-sm tabular-nums">
              {margin === null ? '—' : `${margin.toFixed(1).replace('.', ',')}%`}
              {margin !== null && toNum(price) !== null ? (
                <span className="ml-2 text-xs text-muted-foreground">({formatBRL((toNum(price) ?? 0) - (toNum(cost) ?? 0))})</span>
              ) : null}
            </p>
          </Field>
          <Field label="Estoque mínimo" htmlFor="stock_min">
            <TextInput id="stock_min" name="stock_min" type="number" min={0} step={1} defaultValue={initial.stock_min ?? 0} />
          </Field>
          <Field label="Situação" htmlFor="active">
            <Select id="active" name="active" defaultValue={initial.active === false ? 'false' : 'true'}>
              <option value="true">Ativo</option>
              <option value="false">Inativo</option>
            </Select>
          </Field>
          <Field label="Observações" htmlFor="notes" className="sm:col-span-2 lg:col-span-4">
            <TextArea id="notes" name="notes" defaultValue={initial.notes ?? ''} rows={2} />
          </Field>
        </div>
        <p className="pt-3 text-xs text-muted-foreground">
          O estoque físico não é editado aqui: use Entradas/Ajustes no módulo Estoque para manter o histórico.
        </p>
      </Panel>

      <div className="flex flex-wrap justify-end gap-2">
        <Button type="button" variant="outline" onClick={() => router.back()}>
          Cancelar
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? 'Salvando…' : 'Salvar produto'}
        </Button>
      </div>
    </form>
  )
}
