import { Field, Select, TextInput } from '@/components/crm/ui'
import { Button } from '@/components/ui/button'

export type FilterDef =
  | { type: 'date'; name: string; label: string; value?: string }
  | { type: 'text'; name: string; label: string; value?: string; placeholder?: string }
  | { type: 'select'; name: string; label: string; value?: string; options: { value: string; label: string }[] }

/** GET form — filters live in the URL so results are shareable and server-rendered. */
export function FilterBar({ filters, children }: { filters: FilterDef[]; children?: React.ReactNode }) {
  return (
    <form method="get" className="no-print flex flex-wrap items-end gap-3 rounded-md border border-border bg-card p-3">
      {filters.map((f) => (
        <Field key={f.name} label={f.label} htmlFor={`f-${f.name}`} className={f.type === 'text' ? 'min-w-56 flex-1' : 'w-40'}>
          {f.type === 'select' ? (
            <Select id={`f-${f.name}`} name={f.name} defaultValue={f.value ?? ''}>
              <option value="">Todos</option>
              {f.options.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </Select>
          ) : (
            <TextInput
              id={`f-${f.name}`}
              name={f.name}
              type={f.type === 'date' ? 'date' : 'search'}
              defaultValue={f.value ?? ''}
              placeholder={f.type === 'text' ? f.placeholder : undefined}
            />
          )}
        </Field>
      ))}
      <Button type="submit" variant="outline" className="h-9">
        Filtrar
      </Button>
      {children}
    </form>
  )
}
