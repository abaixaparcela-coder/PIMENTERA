'use client'

import { useMemo, useState, useTransition } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Minus, Plus, Search, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { BrandTag, Field, Panel, Select, TextArea, TextInput } from '@/components/crm/ui'
import { saveOrder, saveTemplate } from '@/lib/actions/orders'
import { money, num } from '@/lib/format'

export type BuilderCustomer = { id: string; label: string; sub: string; address: string; payment_term_id: string | null; status: string }
export type BuilderProduct = {
  id: string
  sku: string
  name: string
  net_content: string | null
  brand: string
  category: string | null
  unit: string
  price: number | null
  min_price: number | null
  available: number
}
export type BuilderTemplate = { id: string; name: string; items: { product_id: string; quantity: number }[] }
type Line = { product_id: string; quantity: number; unit_price: string; discount_pct: string }

export type BuilderInitial = {
  id?: string | null
  customer_id?: string
  delivery_address?: string
  payment_term_id?: string | null
  freight?: number
  tax_total?: number
  expected_delivery?: string | null
  notes?: string | null
  items?: { product_id: string; quantity: number; unit_price: number | null; discount_pct: number }[]
}

const parseNum = (v: string) => {
  const t = v.trim()
  if (!t) return null
  const n = Number(t.replace(/\./g, '').replace(',', '.'))
  return Number.isFinite(n) ? n : NaN
}
const fmtInput = (n: number | null | undefined) => (n === null || n === undefined ? '' : String(n).replace('.', ','))

export function OrderBuilder({
  customers,
  products,
  terms,
  templates,
  initial,
  maxDiscount,
  canEditPrice,
  canSaveTemplate,
}: {
  customers: BuilderCustomer[]
  products: BuilderProduct[]
  terms: { id: string; name: string; days: number[] }[]
  templates: BuilderTemplate[]
  initial: BuilderInitial
  maxDiscount: number
  canEditPrice: boolean
  canSaveTemplate: boolean
}) {
  const router = useRouter()
  const [pending, start] = useTransition()
  const [idemKey] = useState(() => crypto.randomUUID())
  const [customerId, setCustomerId] = useState(initial.customer_id ?? '')
  const [custQuery, setCustQuery] = useState('')
  const [address, setAddress] = useState(initial.delivery_address ?? customers.find((c) => c.id === initial.customer_id)?.address ?? '')
  const [termId, setTermId] = useState(initial.payment_term_id ?? '')
  const [freight, setFreight] = useState(fmtInput(initial.freight || null))
  const [tax, setTax] = useState(fmtInput(initial.tax_total || null))
  const [expected, setExpected] = useState(initial.expected_delivery ?? '')
  const [notes, setNotes] = useState(initial.notes ?? '')
  const [brandFilter, setBrandFilter] = useState<'todas' | 'pimentera' | 'mixx'>('todas')
  const [prodQuery, setProdQuery] = useState('')
  const [lines, setLines] = useState<Line[]>(
    (initial.items ?? []).map((i) => ({
      product_id: i.product_id,
      quantity: i.quantity,
      unit_price: fmtInput(i.unit_price),
      discount_pct: i.discount_pct ? fmtInput(i.discount_pct) : '',
    })),
  )

  const prodMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products])
  const customer = customers.find((c) => c.id === customerId)

  const custMatches = useMemo(() => {
    const t = custQuery.trim().toLowerCase()
    if (!t) return []
    const digits = t.replace(/\D/g, '')
    return customers
      .filter((c) => c.label.toLowerCase().includes(t) || c.sub.toLowerCase().includes(t) || (digits.length >= 3 && c.sub.replace(/\D/g, '').includes(digits)))
      .slice(0, 8)
  }, [custQuery, customers])

  const visibleProducts = useMemo(() => {
    const t = prodQuery.trim().toLowerCase()
    return products.filter(
      (p) =>
        (brandFilter === 'todas' || p.brand === brandFilter) &&
        (!t || p.name.toLowerCase().includes(t) || p.sku.toLowerCase().includes(t) || (p.category ?? '').toLowerCase().includes(t)),
    )
  }, [products, prodQuery, brandFilter])

  const calc = useMemo(() => {
    let subtotal = 0
    let gross = 0
    let units = 0
    const byBrand: Record<string, { units: number; total: number }> = {}
    const rows = lines.map((l) => {
      const p = prodMap.get(l.product_id)
      const price = parseNum(l.unit_price) ?? p?.price ?? null
      const disc = parseNum(l.discount_pct) ?? 0
      const net = price === null || Number.isNaN(price) ? null : Math.round(price * (1 - disc / 100) * 100) / 100
      const total = net === null ? null : Math.round(net * l.quantity * 100) / 100
      const warnings: string[] = []
      if (price === null) warnings.push('sem preço')
      if (p && net !== null && p.min_price !== null && net < p.min_price) warnings.push('abaixo do mínimo')
      if (p && net !== null && p.price && (1 - net / p.price) * 100 > maxDiscount + 0.001) warnings.push('desconto acima do seu limite')
      if (p && l.quantity > p.available) warnings.push(`estoque disponível: ${num(p.available)}`)
      if (price !== null && !Number.isNaN(price)) subtotal += Math.round(price * l.quantity * 100) / 100
      if (total !== null) gross += total
      units += l.quantity
      if (p) {
        byBrand[p.brand] ??= { units: 0, total: 0 }
        byBrand[p.brand].units += l.quantity
        byBrand[p.brand].total += total ?? 0
      }
      return { line: l, product: p, price, net, total, warnings }
    })
    const f = parseNum(freight) ?? 0
    const tx = parseNum(tax) ?? 0
    return { rows, subtotal, discount: subtotal - gross, gross, units, byBrand, freight: f, tax: tx, total: gross + (Number.isNaN(f) ? 0 : f) + (Number.isNaN(tx) ? 0 : tx) }
  }, [lines, prodMap, freight, tax, maxDiscount])

  const needsApproval = calc.rows.some((r) => r.warnings.some((w) => w.includes('mínimo') || w.includes('limite')))
  const missingPrice = calc.rows.some((r) => r.price === null)

  function addProduct(id: string, qty = 1) {
    setLines((prev) => {
      const ex = prev.find((l) => l.product_id === id)
      if (ex) return prev.map((l) => (l.product_id === id ? { ...l, quantity: l.quantity + qty } : l))
      return [...prev, { product_id: id, quantity: qty, unit_price: '', discount_pct: '' }]
    })
  }
  function updateLine(id: string, patch: Partial<Line>) {
    setLines((prev) => prev.map((l) => (l.product_id === id ? { ...l, ...patch } : l)))
  }
  function applyTemplate(tid: string) {
    const t = templates.find((x) => x.id === tid)
    if (!t) return
    if (lines.length && !confirm('Substituir os itens atuais pelos itens do modelo?')) return
    setLines(t.items.filter((i) => prodMap.has(i.product_id)).map((i) => ({ product_id: i.product_id, quantity: i.quantity, unit_price: '', discount_pct: '' })))
    toast.success(`Modelo "${t.name}" aplicado. Revise as quantidades antes de salvar.`)
  }
  function selectCustomer(c: BuilderCustomer) {
    setCustomerId(c.id)
    setCustQuery('')
    if (!address.trim()) setAddress(c.address)
    if (!termId && c.payment_term_id) setTermId(c.payment_term_id)
  }

  function submit(send: boolean) {
    if (!customerId) return toast.error('Selecione o cliente.')
    if (!lines.length) return toast.error('Adicione ao menos um item.')
    const items: { product_id: string; quantity: number; unit_price: number | null; discount_pct: number }[] = []
    for (const r of calc.rows) {
      const up = parseNum(r.line.unit_price)
      const dp = parseNum(r.line.discount_pct)
      if (Number.isNaN(up) || Number.isNaN(dp)) return toast.error(`Valor inválido no item ${r.product?.sku}.`)
      if (!Number.isInteger(r.line.quantity) || r.line.quantity <= 0) return toast.error(`Quantidade inválida no item ${r.product?.sku}.`)
      items.push({ product_id: r.line.product_id, quantity: r.line.quantity, unit_price: up, discount_pct: dp ?? 0 })
    }
    const f = parseNum(freight)
    const tx = parseNum(tax)
    if (Number.isNaN(f) || Number.isNaN(tx)) return toast.error('Frete ou impostos inválidos.')
    start(async () => {
      const r = await saveOrder({
        id: initial.id ?? null,
        idempotency_key: idemKey,
        customer_id: customerId,
        delivery_address: address,
        payment_term_id: termId || null,
        freight: f ?? 0,
        tax_total: tx ?? 0,
        expected_delivery: expected || null,
        notes,
        submit: send,
        items,
      })
      if (!r.ok) {
        toast.error(r.error)
        return
      }
      toast.success(r.message ?? 'Salvo.')
      router.push(`/pedidos/${r.data!.id}`)
    })
  }

  function saveAsTemplate() {
    const name = prompt('Nome do modelo de pedido:')
    if (!name) return
    start(async () => {
      const r = await saveTemplate({ id: null, name, items: lines.map((l) => ({ product_id: l.product_id, quantity: l.quantity })) })
      if (r.ok) {
        toast.success(r.message ?? 'Modelo salvo.')
        router.refresh()
      } else toast.error(r.error)
    })
  }

  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1fr_360px]">
      <div className="flex min-w-0 flex-col gap-4">
        <Panel title="1. Cliente e entrega">
          <div className="flex flex-col gap-3">
            {customer ? (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border bg-muted/50 p-3">
                <div>
                  <p className="font-medium">{customer.label}</p>
                  <p className="text-xs text-muted-foreground">{customer.sub}</p>
                  {customer.status === 'bloqueado' ? <p className="text-xs font-medium text-destructive">Cliente bloqueado — pedidos não são permitidos.</p> : null}
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => setCustomerId('')}>
                  Trocar cliente
                </Button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <div className="flex flex-col gap-2 sm:flex-row">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute left-2.5 top-2.5 size-4 text-muted-foreground" aria-hidden />
                    <TextInput
                      aria-label="Buscar cliente"
                      placeholder="Buscar cliente por nome, CNPJ/CPF, cidade ou código"
                      className="pl-8"
                      value={custQuery}
                      onChange={(e) => setCustQuery(e.target.value)}
                      autoFocus
                    />
                  </div>
                  <Link href="/clientes/novo?voltar=pedido" className="inline-flex h-9 items-center justify-center rounded-md border border-input bg-card px-3 text-sm font-medium hover:bg-accent">
                    Cadastrar novo cliente
                  </Link>
                </div>
                {custMatches.length ? (
                  <ul className="flex flex-col divide-y divide-border rounded-md border border-border bg-card">
                    {custMatches.map((c) => (
                      <li key={c.id}>
                        <button type="button" onClick={() => selectCustomer(c)} className="flex w-full flex-col items-start px-3 py-2 text-left hover:bg-accent">
                          <span className="text-sm font-medium">{c.label}</span>
                          <span className="text-xs text-muted-foreground">{c.sub}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : custQuery.trim() ? (
                  <p className="text-sm text-muted-foreground">Nenhum cliente encontrado.</p>
                ) : null}
              </div>
            )}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <Field label="Endereço de entrega" htmlFor="o_addr" className="sm:col-span-3">
                <TextInput id="o_addr" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Confirme o endereço de entrega" />
              </Field>
              <Field label="Condição de pagamento" htmlFor="o_term">
                <Select id="o_term" value={termId} onChange={(e) => setTermId(e.target.value)}>
                  <option value="">Selecione…</option>
                  {terms.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Previsão de entrega" htmlFor="o_exp">
                <TextInput id="o_exp" type="date" value={expected} onChange={(e) => setExpected(e.target.value)} />
              </Field>
              <Field label="Modelo de pedido" htmlFor="o_tpl">
                <Select id="o_tpl" value="" onChange={(e) => applyTemplate(e.target.value)}>
                  <option value="">Aplicar modelo…</option>
                  {templates.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          </div>
        </Panel>

        <Panel title="2. Produtos">
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-2.5 top-2.5 size-4 text-muted-foreground" aria-hidden />
                <TextInput aria-label="Buscar produto" placeholder="Buscar por nome, SKU ou categoria" className="pl-8" value={prodQuery} onChange={(e) => setProdQuery(e.target.value)} />
              </div>
              <div role="group" aria-label="Filtrar marca" className="inline-flex rounded-md border border-input bg-card p-0.5">
                {(['todas', 'pimentera', 'mixx'] as const).map((b) => (
                  <button
                    key={b}
                    type="button"
                    aria-pressed={brandFilter === b}
                    onClick={() => setBrandFilter(b)}
                    className={`h-8 rounded px-3 text-sm ${brandFilter === b ? 'bg-foreground text-background' : 'hover:bg-accent'}`}
                  >
                    {b === 'todas' ? 'Todas' : b === 'pimentera' ? 'Pimentera' : 'Mixx'}
                  </button>
                ))}
              </div>
            </div>
            <ul className="grid max-h-80 grid-cols-1 gap-1.5 overflow-y-auto sm:grid-cols-2 lg:grid-cols-3">
              {visibleProducts.map((p) => {
                const inOrder = lines.find((l) => l.product_id === p.id)
                return (
                  <li key={p.id}>
                    <button
                      type="button"
                      onClick={() => addProduct(p.id)}
                      className={`flex w-full items-center justify-between gap-2 rounded-md border px-2.5 py-2 text-left transition-colors hover:border-primary ${inOrder ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}
                    >
                      <span className="flex min-w-0 flex-col">
                        <span className="truncate text-sm font-medium">{p.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {p.net_content} · {p.price === null ? 'sem preço' : money(p.price)} · disp. {num(p.available)}
                        </span>
                      </span>
                      <span className="flex shrink-0 items-center gap-1.5">
                        {inOrder ? <span className="font-mono text-xs font-semibold text-primary">{inOrder.quantity}</span> : null}
                        <Plus className="size-4 text-muted-foreground" aria-hidden />
                        <span className="sr-only">Adicionar {p.name}</span>
                      </span>
                    </button>
                  </li>
                )
              })}
            </ul>
          </div>
        </Panel>

        <Panel title={`3. Itens do pedido (${lines.length})`}>
          {lines.length === 0 ? (
            <p className="text-sm text-muted-foreground">Toque nos produtos acima ou aplique um modelo para adicionar itens.</p>
          ) : (
            <div className="flex flex-col divide-y divide-border">
              {calc.rows.map((r) => (
                <div key={r.line.product_id} className="flex flex-col gap-2 py-2.5 md:flex-row md:items-center">
                  <div className="flex min-w-0 flex-1 flex-col">
                    <span className="flex items-center gap-2 text-sm font-medium">
                      <BrandTag code={r.product?.brand ?? ''} />
                      <span className="truncate">{r.product?.name}</span>
                    </span>
                    <span className="font-mono text-xs text-muted-foreground">
                      {r.product?.sku} · {r.product?.net_content} · {r.product?.unit}
                    </span>
                    {r.warnings.length ? <span className="text-xs text-destructive">{r.warnings.join(' · ')}</span> : null}
                  </div>
                  <div className="flex flex-wrap items-end gap-2">
                    <div className="flex items-center">
                      <Button type="button" variant="outline" size="icon" className="size-9 rounded-r-none" aria-label="Diminuir" onClick={() => updateLine(r.line.product_id, { quantity: Math.max(1, r.line.quantity - 1) })}>
                        <Minus />
                      </Button>
                      <input
                        aria-label={`Quantidade de ${r.product?.name}`}
                        inputMode="numeric"
                        className="h-9 w-16 border-y border-input bg-card text-center font-mono text-sm tabular-nums outline-none focus-visible:border-ring"
                        value={r.line.quantity}
                        onChange={(e) => {
                          const v = parseInt(e.target.value.replace(/\D/g, ''), 10)
                          updateLine(r.line.product_id, { quantity: Number.isFinite(v) && v > 0 ? v : 1 })
                        }}
                      />
                      <Button type="button" variant="outline" size="icon" className="size-9 rounded-l-none" aria-label="Aumentar" onClick={() => updateLine(r.line.product_id, { quantity: r.line.quantity + 1 })}>
                        <Plus />
                      </Button>
                    </div>
                    <label className="flex flex-col gap-0.5 text-xs">
                      <span className="text-muted-foreground">Preço un.</span>
                      <input
                        inputMode="decimal"
                        disabled={!canEditPrice && r.product?.price !== null}
                        placeholder={r.product?.price === null ? 'informar' : money(r.product?.price).replace('R$', '').trim()}
                        className="h-9 w-24 rounded-md border border-input bg-card px-2 text-right font-mono text-sm tabular-nums outline-none focus-visible:border-ring disabled:opacity-60"
                        value={r.line.unit_price}
                        onChange={(e) => updateLine(r.line.product_id, { unit_price: e.target.value })}
                      />
                    </label>
                    <label className="flex flex-col gap-0.5 text-xs">
                      <span className="text-muted-foreground">Desc. %</span>
                      <input
                        inputMode="decimal"
                        placeholder="0"
                        className="h-9 w-16 rounded-md border border-input bg-card px-2 text-right font-mono text-sm tabular-nums outline-none focus-visible:border-ring"
                        value={r.line.discount_pct}
                        onChange={(e) => updateLine(r.line.product_id, { discount_pct: e.target.value })}
                      />
                    </label>
                    <div className="flex w-28 flex-col items-end text-xs">
                      <span className="text-muted-foreground">Total</span>
                      <span className="flex h-9 items-center font-mono text-sm font-semibold tabular-nums">{r.total === null ? '—' : money(r.total)}</span>
                    </div>
                    <Button type="button" variant="ghost" size="icon" className="size-9 text-muted-foreground hover:text-destructive" aria-label={`Remover ${r.product?.name}`} onClick={() => setLines((p) => p.filter((l) => l.product_id !== r.line.product_id))}>
                      <Trash2 />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>

      <aside className="flex flex-col gap-4 xl:sticky xl:top-4 xl:self-start">
        <Panel title="Resumo">
          <dl className="flex flex-col gap-1.5 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Unidades</dt>
              <dd className="font-mono tabular-nums">{num(calc.units)}</dd>
            </div>
            {Object.entries(calc.byBrand).map(([b, v]) => (
              <div key={b} className="flex justify-between text-xs">
                <dt className="flex items-center gap-1.5">
                  <BrandTag code={b} /> {num(v.units)} un.
                </dt>
                <dd className="font-mono tabular-nums">{money(v.total)}</dd>
              </div>
            ))}
            <div className="mt-1 flex justify-between border-t border-border pt-2">
              <dt className="text-muted-foreground">Subtotal</dt>
              <dd className="font-mono tabular-nums">{money(calc.subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Descontos</dt>
              <dd className="font-mono tabular-nums">− {money(calc.discount)}</dd>
            </div>
            <div className="flex items-center justify-between gap-2">
              <dt>
                <label htmlFor="o_freight" className="text-muted-foreground">
                  Frete
                </label>
              </dt>
              <dd>
                <input id="o_freight" inputMode="decimal" placeholder="0,00" value={freight} onChange={(e) => setFreight(e.target.value)} className="h-8 w-24 rounded-md border border-input bg-card px-2 text-right font-mono text-sm tabular-nums" />
              </dd>
            </div>
            <div className="flex items-center justify-between gap-2">
              <dt>
                <label htmlFor="o_tax" className="text-muted-foreground">
                  Impostos (se aplicável)
                </label>
              </dt>
              <dd>
                <input id="o_tax" inputMode="decimal" placeholder="0,00" value={tax} onChange={(e) => setTax(e.target.value)} className="h-8 w-24 rounded-md border border-input bg-card px-2 text-right font-mono text-sm tabular-nums" />
              </dd>
            </div>
            <div className="mt-1 flex items-baseline justify-between border-t border-border pt-2">
              <dt className="font-semibold">Total</dt>
              <dd className="font-mono text-xl font-semibold tabular-nums">{money(calc.total)}</dd>
            </div>
          </dl>
          <p className="pt-2 text-xs text-muted-foreground">Seu limite de desconto: {num(maxDiscount)}%. Valores finais são recalculados no servidor.</p>
        </Panel>
        <Panel title="Observações">
          <TextArea aria-label="Observações do pedido" value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="Instruções de entrega, combinados com o comprador…" />
        </Panel>
        {missingPrice ? <p className="rounded-md border border-mustard/60 bg-mustard/20 p-3 text-xs">Há itens sem preço cadastrado. Informe o preço unitário ou peça ao administrador para cadastrá-lo.</p> : null}
        {needsApproval ? <p className="rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">Preço abaixo do mínimo ou desconto acima do limite: o pedido exigirá autorização de outro responsável.</p> : null}
        <div className="flex flex-col gap-2">
          <Button type="button" size="lg" disabled={pending} onClick={() => submit(true)}>
            {pending ? 'Enviando…' : 'Enviar para aprovação'}
          </Button>
          <Button type="button" variant="outline" disabled={pending} onClick={() => submit(false)}>
            Salvar rascunho
          </Button>
          {canSaveTemplate && lines.length ? (
            <Button type="button" variant="ghost" size="sm" disabled={pending} onClick={saveAsTemplate}>
              Salvar itens como modelo
            </Button>
          ) : null}
        </div>
      </aside>
    </div>
  )
}
