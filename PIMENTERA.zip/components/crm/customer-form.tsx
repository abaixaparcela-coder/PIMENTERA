'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useActionState, useEffect, useState, useTransition } from 'react'
import { Button } from '@/components/ui/button'
import { Field, Panel, Select, TextArea, TextInput } from '@/components/crm/ui'
import { lookupCep, saveCustomer, type CustomerActionState } from '@/lib/actions/customers'
import { CHANNEL_LABEL, CUSTOMER_STATUS_LABEL, UF } from '@/lib/constants'
import { customerCode } from '@/lib/format'

export type CustomerValues = Partial<Record<string, string | number | string[] | null>>

export function Notice({ kind, children }: { kind: 'ok' | 'error' | 'warn'; children: React.ReactNode }) {
  const cls =
    kind === 'ok'
      ? 'border-success/30 bg-success/10 text-success'
      : kind === 'warn'
        ? 'border-mustard/60 bg-mustard/20 text-foreground'
        : 'border-destructive/30 bg-destructive/10 text-destructive'
  return (
    <div role={kind === 'error' ? 'alert' : 'status'} className={`rounded-md border px-3 py-2 text-sm ${cls}`}>
      {children}
    </div>
  )
}

export function CustomerForm({
  id,
  initial,
  reps,
  terms,
  isComercial,
}: {
  id: string | null
  initial: CustomerValues
  reps: { id: string; full_name: string }[]
  terms: { id: string; name: string }[]
  isComercial: boolean
}) {
  const router = useRouter()
  const [state, action, pending] = useActionState<CustomerActionState | undefined, FormData>(saveCustomer.bind(null, id), undefined)
  const [personType, setPersonType] = useState(String(initial.person_type ?? 'PJ'))
  const [addr, setAddr] = useState({
    street: String(initial.street ?? ''),
    district: String(initial.district ?? ''),
    city: String(initial.city ?? ''),
    state: String(initial.state ?? ''),
  })
  const [cepPending, startCep] = useTransition()
  const fe = (state && !state.ok ? state.fieldErrors : undefined) ?? {}
  const brands = (initial.brands as string[] | undefined) ?? []

  useEffect(() => {
    if (state?.ok && state.data?.id) {
      if (!id) router.push(`/clientes/${state.data.id}`)
      else router.refresh()
    }
  }, [state, id, router])

  const v = (k: string) => (initial[k] === null || initial[k] === undefined ? '' : String(initial[k]))

  return (
    <form action={action} className="flex flex-col gap-4" noValidate>
      {state && !state.ok ? (
        <Notice kind={state.duplicates?.length ? 'warn' : 'error'}>
          <p className="font-medium">{state.error}</p>
          {state.duplicates?.length ? (
            <ul className="mt-1 flex flex-col gap-0.5">
              {state.duplicates.map((d) => (
                <li key={d.id}>
                  <Link href={`/clientes/${d.id}`} className="underline underline-offset-2" target="_blank">
                    {customerCode(d.code)} — {d.display_name}
                    {d.city ? ` (${d.city})` : ''}
                  </Link>{' '}
                  · {d.reason === 'documento' ? 'mesmo documento' : 'nome semelhante'}
                </li>
              ))}
            </ul>
          ) : null}
          {state.duplicates?.length && !state.duplicates.some((d) => d.reason === 'documento') ? (
            <Button type="submit" name="$confirm_similar" value="1" size="sm" variant="outline" className="mt-2">
              Não é duplicado — salvar mesmo assim
            </Button>
          ) : null}
        </Notice>
      ) : null}
      {state?.ok ? <Notice kind="ok">{state.message}</Notice> : null}

      <Panel title="Identificação">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Tipo de pessoa" htmlFor="person_type">
            <Select id="person_type" name="person_type" value={personType} onChange={(e) => setPersonType(e.target.value)}>
              <option value="PJ">Jurídica</option>
              <option value="PF">Física</option>
            </Select>
          </Field>
          <Field label={personType === 'PJ' ? 'Razão social *' : 'Nome completo *'} htmlFor="legal_name" error={fe.legal_name} className="sm:col-span-2 lg:col-span-3">
            <TextInput id="legal_name" name="legal_name" defaultValue={v('legal_name')} required aria-invalid={!!fe.legal_name} />
          </Field>
          <Field label="Nome fantasia" htmlFor="trade_name" className="sm:col-span-2">
            <TextInput id="trade_name" name="trade_name" defaultValue={v('trade_name')} />
          </Field>
          <Field label={personType === 'PJ' ? 'CNPJ' : 'CPF'} htmlFor="document" error={fe.document} hint="Opcional para prospects.">
            <TextInput id="document" name="document" inputMode="numeric" defaultValue={v('document')} aria-invalid={!!fe.document} />
          </Field>
          <Field label="Situação" htmlFor="status">
            <Select id="status" name="status" defaultValue={v('status') || 'prospect'}>
              {Object.entries(CUSTOMER_STATUS_LABEL).map(([k, l]) => (
                <option key={k} value={k}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          {personType === 'PJ' ? (
            <>
              <Field label="Inscrição estadual" htmlFor="state_registration">
                <TextInput id="state_registration" name="state_registration" defaultValue={v('state_registration')} />
              </Field>
              <Field label="Indicador de IE" htmlFor="ie_indicator">
                <Select id="ie_indicator" name="ie_indicator" defaultValue={v('ie_indicator')}>
                  <option value="">Não informado</option>
                  <option value="contribuinte">Contribuinte</option>
                  <option value="isento">Isento</option>
                  <option value="nao_contribuinte">Não contribuinte</option>
                </Select>
              </Field>
            </>
          ) : (
            <input type="hidden" name="ie_indicator" value="" />
          )}
          <Field label="Canal" htmlFor="channel">
            <Select id="channel" name="channel" defaultValue={v('channel') || 'supermercado'}>
              {Object.entries(CHANNEL_LABEL).map(([k, l]) => (
                <option key={k} value={k}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <fieldset className="flex flex-col gap-1">
            <legend className="text-xs font-medium">Marcas com que trabalha</legend>
            <div className="flex h-9 items-center gap-4">
              {(['pimentera', 'mixx'] as const).map((b) => (
                <label key={b} className="flex items-center gap-1.5 text-sm">
                  <input type="checkbox" name="brands" value={b} defaultChecked={brands.includes(b)} className="size-4 accent-primary" />
                  {b === 'pimentera' ? 'Pimentera' : 'Mixx'}
                </label>
              ))}
            </div>
          </fieldset>
        </div>
      </Panel>

      <Panel title="Contato">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Comprador / responsável" htmlFor="buyer_name">
            <TextInput id="buyer_name" name="buyer_name" defaultValue={v('buyer_name')} />
          </Field>
          <Field label="Telefone" htmlFor="phone">
            <TextInput id="phone" name="phone" type="tel" inputMode="tel" defaultValue={v('phone')} placeholder="(62) 99999-9999" />
          </Field>
          <Field label="WhatsApp" htmlFor="whatsapp">
            <TextInput id="whatsapp" name="whatsapp" type="tel" inputMode="tel" defaultValue={v('whatsapp')} />
          </Field>
          <Field label="E-mail" htmlFor="email" error={fe.email}>
            <TextInput id="email" name="email" type="email" defaultValue={v('email')} aria-invalid={!!fe.email} />
          </Field>
        </div>
      </Panel>

      <Panel title="Endereço">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <Field label="CEP" htmlFor="cep" hint={cepPending ? 'Buscando…' : 'Preenche o endereço automaticamente.'}>
            <TextInput
              id="cep"
              name="cep"
              inputMode="numeric"
              defaultValue={v('cep')}
              onBlur={(e) => {
                const val = e.target.value
                startCep(async () => {
                  const r = await lookupCep(val)
                  if (r) setAddr((a) => ({ street: r.street || a.street, district: r.district || a.district, city: r.city, state: r.state }))
                })
              }}
            />
          </Field>
          <Field label="Logradouro" htmlFor="street" className="sm:col-span-2 lg:col-span-3">
            <TextInput id="street" name="street" value={addr.street} onChange={(e) => setAddr({ ...addr, street: e.target.value })} />
          </Field>
          <Field label="Número" htmlFor="number">
            <TextInput id="number" name="number" defaultValue={v('number')} />
          </Field>
          <Field label="Complemento" htmlFor="complement" className="lg:col-span-2">
            <TextInput id="complement" name="complement" defaultValue={v('complement')} />
          </Field>
          <Field label="Bairro" htmlFor="district" className="lg:col-span-2">
            <TextInput id="district" name="district" value={addr.district} onChange={(e) => setAddr({ ...addr, district: e.target.value })} />
          </Field>
          <Field label="Cidade" htmlFor="city">
            <TextInput id="city" name="city" value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} />
          </Field>
          <Field label="UF" htmlFor="state" error={fe.state}>
            <Select id="state" name="state" value={addr.state} onChange={(e) => setAddr({ ...addr, state: e.target.value })}>
              <option value="">—</option>
              {UF.map((u) => (
                <option key={u}>{u}</option>
              ))}
            </Select>
          </Field>
          <Field label="Endereço de cobrança" htmlFor="billing_address" hint="Deixe em branco se for o mesmo." className="sm:col-span-2 lg:col-span-3">
            <TextInput id="billing_address" name="billing_address" defaultValue={v('billing_address')} />
          </Field>
          <Field label="Endereço de entrega" htmlFor="delivery_address" hint="Deixe em branco se for o mesmo." className="sm:col-span-2 lg:col-span-3">
            <TextInput id="delivery_address" name="delivery_address" defaultValue={v('delivery_address')} />
          </Field>
          <Field label="Responsável pelo recebimento" htmlFor="receiver_name" className="lg:col-span-3">
            <TextInput id="receiver_name" name="receiver_name" defaultValue={v('receiver_name')} />
          </Field>
          <Field label="Contato do recebimento" htmlFor="receiver_phone" className="lg:col-span-3">
            <TextInput id="receiver_phone" name="receiver_phone" type="tel" defaultValue={v('receiver_phone')} />
          </Field>
        </div>
      </Panel>

      <Panel title="Comercial">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Vendedor responsável" htmlFor="sales_rep_id" hint={isComercial ? 'Atribuído a você.' : undefined}>
            <Select id="sales_rep_id" name="sales_rep_id" defaultValue={v('sales_rep_id')} disabled={isComercial}>
              <option value="">Sem vendedor</option>
              {reps.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.full_name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Condição de pagamento" htmlFor="payment_term_id">
            <Select id="payment_term_id" name="payment_term_id" defaultValue={v('payment_term_id')}>
              <option value="">Não definida</option>
              {terms.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Limite de crédito (R$)" htmlFor="credit_limit" error={fe.credit_limit} hint={isComercial ? 'Definido pelo financeiro.' : undefined}>
            <TextInput id="credit_limit" name="credit_limit" inputMode="decimal" defaultValue={v('credit_limit')} readOnly={isComercial} />
          </Field>
          <Field label="Observações comerciais" htmlFor="commercial_notes" className="sm:col-span-2 lg:col-span-4">
            <TextArea id="commercial_notes" name="commercial_notes" defaultValue={v('commercial_notes')} rows={3} />
          </Field>
        </div>
      </Panel>

      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-border bg-background/95 px-4 py-3 backdrop-blur md:mx-0 md:rounded-md md:border">
        <Button type="button" variant="outline" onClick={() => router.back()}>
          Cancelar
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? 'Salvando…' : 'Salvar cliente'}
        </Button>
      </div>
    </form>
  )
}
