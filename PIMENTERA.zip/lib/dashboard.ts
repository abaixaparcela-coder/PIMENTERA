import 'server-only'
import { createClient } from '@/lib/supabase/server'
import { addDaysISO, todayISO } from '@/lib/format'

export type DashFilters = { from: string; to: string; brand?: string; rep?: string; status?: string }

const SOLD_EXCLUDED = ['rascunho', 'cancelado']
const DELIVERY_DONE = ['entregue', 'recusada']

export function openBalance(i: { amount: number; interest: number; discount: number; paid_amount: number }) {
  return Math.max(0, Number(i.amount) + Number(i.interest) - Number(i.discount) - Number(i.paid_amount))
}

export async function loadDashboard(f: DashFilters) {
  const supabase = await createClient()
  const today = todayISO()
  const fromTs = `${f.from}T00:00:00-03:00`
  const toTs = `${f.to}T23:59:59-03:00`

  let ordersQ = supabase
    .from('orders')
    .select('id, status, total, rep_id, customer_id, created_at')
    .gte('created_at', fromTs)
    .lte('created_at', toTs)
    .limit(5000)
  if (f.rep) ordersQ = ordersQ.eq('rep_id', f.rep)
  if (f.status) ordersQ = ordersQ.eq('status', f.status)

  let itemsQ = supabase
    .from('order_items')
    .select('product_id, sku, product_name, brand_code, quantity, line_total, orders!inner(status, created_at, rep_id)')
    .gte('orders.created_at', fromTs)
    .lte('orders.created_at', toTs)
    .not('orders.status', 'in', `(${SOLD_EXCLUDED.join(',')})`)
    .limit(20000)
  if (f.rep) itemsQ = itemsQ.eq('orders.rep_id', f.rep)
  if (f.brand) itemsQ = itemsQ.eq('brand_code', f.brand)

  const [orders, items, pipeline, invoices, payments, installments, deliveries, products, newCustomers, activeCustomers, recentOrders] =
    await Promise.all([
      ordersQ,
      itemsQ,
      supabase.from('orders').select('status').in('status', ['aguardando_aprovacao', 'em_separacao', 'aguardando_faturamento']).limit(5000),
      supabase.from('invoices').select('amount').eq('status', 'emitida').gte('issue_date', f.from).lte('issue_date', f.to),
      supabase.from('payments').select('amount').gte('paid_at', f.from).lte('paid_at', f.to),
      supabase.from('receivable_installments').select('amount, interest, discount, paid_amount, due_date').in('status', ['pendente', 'parcial']).limit(10000),
      supabase.from('deliveries').select('status, scheduled_date').not('status', 'in', `(${DELIVERY_DONE.join(',')})`).limit(5000),
      supabase.from('products').select('id, stock_physical, stock_reserved, stock_min').eq('active', true),
      supabase.from('customers').select('id', { count: 'exact', head: true }).gte('created_at', fromTs).lte('created_at', toTs),
      supabase.from('customers').select('id').eq('status', 'ativo').limit(10000),
      supabase.from('orders').select('customer_id').gte('created_at', `${addDaysISO(today, -60)}T00:00:00-03:00`).not('status', 'in', `(${SOLD_EXCLUDED.join(',')})`).limit(10000),
    ])

  const sold = (orders.data ?? []).filter((o) => !SOLD_EXCLUDED.includes(o.status))
  const soldValue = sold.reduce((s, o) => s + Number(o.total), 0)
  const pipe = (s: string) => (pipeline.data ?? []).filter((o) => o.status === s).length
  const openInst = installments.data ?? []
  const buyers = new Set((recentOrders.data ?? []).map((o) => o.customer_id))

  const byProduct = new Map<string, { sku: string; name: string; brand: string; qty: number; value: number }>()
  const byBrand: Record<string, number> = { pimentera: 0, mixx: 0 }
  for (const it of items.data ?? []) {
    const cur = byProduct.get(it.product_id) ?? { sku: it.sku, name: it.product_name, brand: it.brand_code, qty: 0, value: 0 }
    cur.qty += it.quantity
    cur.value += Number(it.line_total)
    byProduct.set(it.product_id, cur)
    byBrand[it.brand_code] = (byBrand[it.brand_code] ?? 0) + Number(it.line_total)
  }

  return {
    soldValue,
    ordersCreated: (orders.data ?? []).filter((o) => o.status !== 'cancelado').length,
    awaitingApproval: pipe('aguardando_aprovacao'),
    picking: pipe('em_separacao'),
    awaitingInvoice: pipe('aguardando_faturamento'),
    invoiced: (invoices.data ?? []).reduce((s, i) => s + Number(i.amount), 0),
    received: (payments.data ?? []).reduce((s, p) => s + Number(p.amount), 0),
    receivable: openInst.reduce((s, i) => s + openBalance(i), 0),
    overdue: openInst.filter((i) => i.due_date < today).reduce((s, i) => s + openBalance(i), 0),
    deliveriesPending: (deliveries.data ?? []).length,
    deliveriesLate: (deliveries.data ?? []).filter((d) => d.scheduled_date && d.scheduled_date < today).length,
    lowStock: (products.data ?? []).filter((p) => p.stock_physical - p.stock_reserved <= p.stock_min).length,
    newCustomers: newCustomers.count ?? 0,
    inactiveBuyers: (activeCustomers.data ?? []).filter((c) => !buyers.has(c.id)).length,
    avgTicket: sold.length ? soldValue / sold.length : 0,
    topProducts: [...byProduct.values()].sort((a, b) => b.qty - a.qty).slice(0, 8),
    byBrand,
  }
}
