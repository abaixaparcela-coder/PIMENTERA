import 'server-only'
import { cache } from 'react'
import { createAdminClient } from '@/lib/supabase/admin'
import { createClient } from '@/lib/supabase/server'

export const getCompany = cache(async () => {
  const supabase = await createClient()
  const { data } = await supabase.from('company_settings').select('*').eq('id', 1).maybeSingle()
  const logos: { pimentera: string | null; mixx: string | null } = { pimentera: null, mixx: null }
  if (data?.logo_pimentera_path || data?.logo_mixx_path) {
    // Logos live in the private bucket; short-lived signed URLs are issued only to signed-in users.
    const admin = createAdminClient()
    const paths = [data.logo_pimentera_path, data.logo_mixx_path].filter(Boolean) as string[]
    const { data: signed } = await admin.storage.from('arquivos').createSignedUrls(paths, 60 * 60)
    for (const s of signed ?? []) {
      if (s.path === data.logo_pimentera_path) logos.pimentera = s.signedUrl
      if (s.path === data.logo_mixx_path) logos.mixx = s.signedUrl
    }
  }
  return { company: data, logos }
})
