'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { assertRoles, toError, type ActionResult } from '@/lib/auth'
import { audit } from '@/lib/audit'
import { createClient } from '@/lib/supabase/server'

const money = z
  .string()
  .optional()
  .transform((v) => (v && v.trim() ? Number(v.replace(/\./g, '').replace(',', '.')) : null))
  .refine((v) => v === null || (Number.isFinite(v) && v >= 0 && v < 1e9), 'Valor inválido.')

const optText = (max = 300) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((v) => v || null)

const productSchema = z
  .object({
    sku: z.string().trim().toUpperCase().min(2, 'Informe o SKU.').max(40).regex(/^[A-Z0-9._-]+$/, 'Use letras, números, ponto, hífen ou sublinhado.'),
    name: z.string().trim().min(2, 'Informe o nome.').max(200),
    brand_id: z.coerce.number().int().min(1),
    category_id: z.string().uuid().optional().or(z.literal('')).transform((v) => v || null),
    description: optText(2000),
    net_content: optText(40),
    unit: z.string().trim().min(1).max(10),
    barcode: optText(20).refine((v) => !v || /^\d{8,14}$/.test(v), 'Código de barras deve ter 8 a 14 dígitos.'),
    cost: money,
    price: money,
    min_price: money,
    stock_min: z.coerce.number().int().min(0).max(1e7),
    active: z.enum(['true', 'false']).transform((v) => v === 'true'),
    notes: optText(2000),
  })
  .superRefine((v, ctx) => {
    if (v.min_price !== null && v.price !== null && v.min_price > v.price)
      ctx.addIssue({ code: 'custom', path: ['min_price'], message: 'Preço mínimo maior que o preço de venda.' })
  })

export type ProductActionState = ActionResult<{ id: string }> & { fieldErrors?: Record<string, string> }

export async function saveProduct(id: string | null, _prev: ProductActionState | undefined, fd: FormData): Promise<ProductActionState> {
  try {
    const profile = await assertRoles(['admin'])
    const parsed = productSchema.safeParse(Object.fromEntries(fd))
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {}
      for (const i of parsed.error.issues) fieldErrors[String(i.path[0])] ??= i.message
      return { ok: false, error: 'Revise os campos destacados.', fieldErrors }
    }
    const supabase = await createClient()
    if (id) {
      const { data: before } = await supabase.from('products').select('price, min_price, cost').eq('id', id).single()
      const { error } = await supabase.from('products').update(parsed.data).eq('id', id)
      if (error) throw error
      await audit(profile.id, 'editar_produto', 'products', id, { sku: parsed.data.sku, antes: before, depois: { price: parsed.data.price, min_price: parsed.data.min_price, cost: parsed.data.cost } })
      revalidatePath('/produtos')
      return { ok: true, data: { id }, message: 'Produto atualizado.' }
    }
    const { data, error } = await supabase.from('products').insert(parsed.data).select('id').single()
    if (error) throw error
    await audit(profile.id, 'criar_produto', 'products', data.id, { sku: parsed.data.sku })
    revalidatePath('/produtos')
    return { ok: true, data: { id: data.id }, message: 'Produto cadastrado.' }
  } catch (e) {
    return toError(e)
  }
}

export async function uploadProductImage(id: string, fd: FormData): Promise<ActionResult> {
  try {
    await assertRoles(['admin'])
    const file = fd.get('file')
    if (!(file instanceof File) || file.size === 0) return { ok: false, error: 'Selecione uma imagem.' }
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) return { ok: false, error: 'Use PNG, JPG ou WEBP.' }
    if (file.size > 3 * 1024 * 1024) return { ok: false, error: 'Imagem acima de 3 MB.' }
    const supabase = await createClient()
    const path = `produtos/${id}/${Date.now()}.${file.type.split('/')[1]}`
    const { error: upErr } = await supabase.storage.from('arquivos').upload(path, file, { contentType: file.type })
    if (upErr) throw upErr
    const { error } = await supabase.from('products').update({ image_path: path }).eq('id', id)
    if (error) throw error
    revalidatePath(`/produtos/${id}`)
    return { ok: true, message: 'Imagem enviada.' }
  } catch (e) {
    return toError(e)
  }
}

const moveSchema = z.object({
  product_id: z.string().uuid(),
  type: z.enum(['entrada', 'saida', 'ajuste']),
  quantity: z.coerce.number().int('Quantidade deve ser inteira.').refine((v) => v !== 0, 'Quantidade não pode ser zero.'),
  reason: z.string().trim().max(500).optional(),
  lot: z.string().trim().max(60).optional(),
  expiry_date: z.string().optional(),
})

export async function moveStock(_prev: ActionResult | undefined, fd: FormData): Promise<ActionResult> {
  try {
    await assertRoles(['admin', 'estoque'])
    const parsed = moveSchema.safeParse(Object.fromEntries(fd))
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
    const m = parsed.data
    const supabase = await createClient()
    const { error } = await supabase.rpc('stock_adjust', {
      p_product: m.product_id,
      p_type: m.type,
      p_qty: m.quantity,
      p_reason: m.reason || null,
      p_lot: m.lot || null,
      p_expiry: m.expiry_date || null,
    })
    if (error) throw error
    revalidatePath('/estoque')
    revalidatePath(`/produtos/${m.product_id}`)
    return { ok: true, message: 'Movimentação registrada.' }
  } catch (e) {
    return toError(e)
  }
}

function parseCsv(text: string) {
  const rows: string[][] = []
  const sep = (text.split('\n')[0].match(/;/g)?.length ?? 0) >= (text.split('\n')[0].match(/,/g)?.length ?? 0) ? ';' : ','
  let row: string[] = []
  let cur = ''
  let q = false
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]
    if (q) {
      if (ch === '"' && text[i + 1] === '"') {
        cur += '"'
        i++
      } else if (ch === '"') q = false
      else cur += ch
    } else if (ch === '"') q = true
    else if (ch === sep) {
      row.push(cur)
      cur = ''
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++
      row.push(cur)
      if (row.some((c) => c.trim())) rows.push(row)
      row = []
      cur = ''
    } else cur += ch
  }
  row.push(cur)
  if (row.some((c) => c.trim())) rows.push(row)
  return rows
}

/** Upserts product master data by SKU. Stock is never imported — use stock movements. */
export async function importProductsCsv(_prev: ActionResult | undefined, fd: FormData): Promise<ActionResult> {
  try {
    const profile = await assertRoles(['admin'])
    const file = fd.get('file')
    if (!(file instanceof File) || file.size === 0) return { ok: false, error: 'Selecione um arquivo CSV.' }
    if (file.size > 2 * 1024 * 1024) return { ok: false, error: 'Arquivo acima de 2 MB.' }
    const rows = parseCsv((await file.text()).replace(/^\uFEFF/, ''))
    if (rows.length < 2) return { ok: false, error: 'O arquivo não contém linhas de dados.' }
    const header = rows[0].map((h) => h.trim().toLowerCase())
    const idx = (k: string) => header.indexOf(k)
    if (idx('sku') < 0 || idx('nome') < 0 || idx('marca') < 0) return { ok: false, error: 'Cabeçalho deve conter ao menos: sku; nome; marca.' }
    const supabase = await createClient()
    const { data: brands } = await supabase.from('brands').select('id, code, name')
    const { data: cats } = await supabase.from('product_categories').select('id, name')
    const brandOf = (v: string) => brands?.find((b) => b.code === v.trim().toLowerCase() || b.name.toLowerCase() === v.trim().toLowerCase())?.id
    const catOf = (v: string) => cats?.find((c) => c.name.toLowerCase() === v.trim().toLowerCase())?.id ?? null
    const errors: string[] = []
    let ok = 0
    for (let r = 1; r < rows.length && r <= 2000; r++) {
      const c = rows[r]
      const get = (k: string) => (idx(k) >= 0 ? (c[idx(k)] ?? '').trim() : '')
      const brand = brandOf(get('marca'))
      if (!brand) {
        errors.push(`Linha ${r + 1}: marca inválida`)
        continue
      }
      const parsed = productSchema.safeParse({
        sku: get('sku'),
        name: get('nome'),
        brand_id: String(brand),
        category_id: get('categoria') ? (catOf(get('categoria')) ?? '') : '',
        description: get('descricao'),
        net_content: get('conteudo'),
        unit: get('unidade') || 'UN',
        barcode: get('codigo_barras'),
        cost: get('custo'),
        price: get('preco'),
        min_price: get('preco_minimo'),
        stock_min: get('estoque_minimo') || '0',
        active: get('ativo').toLowerCase() === 'nao' || get('ativo').toLowerCase() === 'false' ? 'false' : 'true',
        notes: get('observacoes'),
      })
      if (!parsed.success) {
        errors.push(`Linha ${r + 1}: ${parsed.error.issues[0].message}`)
        continue
      }
      const { error } = await supabase.from('products').upsert(parsed.data, { onConflict: 'sku' })
      if (error) errors.push(`Linha ${r + 1}: ${error.message}`)
      else ok++
    }
    await audit(profile.id, 'importar_produtos', 'products', null, { importados: ok, erros: errors.length })
    revalidatePath('/produtos')
    if (errors.length) {
      const msg = `${ok} importados, ${errors.length} com erro: ${errors.slice(0, 5).join(' | ')}${errors.length > 5 ? '…' : ''}`
      return ok > 0 ? { ok: true, message: msg } : { ok: false, error: msg }
    }
    return { ok: true, message: `${ok} produtos importados/atualizados.` }
  } catch (e) {
    return toError(e)
  }
}
