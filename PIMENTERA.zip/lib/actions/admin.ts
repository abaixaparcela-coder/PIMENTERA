'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { assertRoles, toError, type ActionResult } from '@/lib/auth'
import { audit } from '@/lib/audit'
import { createAdminClient } from '@/lib/supabase/admin'
import { createClient } from '@/lib/supabase/server'

const roleEnum = z.enum(['admin', 'comercial', 'estoque', 'faturamento', 'entregador', 'gerente'])

const newUserSchema = z.object({
  full_name: z.string().trim().min(2, 'Informe o nome.').max(120),
  email: z.string().trim().toLowerCase().email('E-mail inválido.'),
  phone: z.string().trim().max(20).optional(),
  password: z.string().min(8, 'A senha deve ter ao menos 8 caracteres.').max(72),
  role: roleEnum,
  max_discount_pct: z.coerce.number().min(0).max(100),
})

export async function createUser(fd: FormData): Promise<ActionResult> {
  try {
    const me = await assertRoles(['admin'])
    const parsed = newUserSchema.safeParse(Object.fromEntries(fd))
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const v = parsed.data
    const admin = createAdminClient()
    const { data, error } = await admin.auth.admin.createUser({
      email: v.email,
      password: v.password,
      email_confirm: true,
      user_metadata: { full_name: v.full_name },
      app_metadata: { role: v.role },
    })
    if (error || !data.user) {
      return { ok: false, error: error?.message?.includes('already') ? 'Já existe um usuário com este e-mail.' : 'Não foi possível criar o usuário.' }
    }
    const { error: upErr } = await admin
      .from('profiles')
      .update({ full_name: v.full_name, phone: v.phone || null, role: v.role, active: true, max_discount_pct: v.max_discount_pct })
      .eq('id', data.user.id)
    if (upErr) return toError(upErr)
    await audit(me.id, 'criar_usuario', 'profiles', data.user.id, { email: v.email, role: v.role })
    revalidatePath('/configuracoes/usuarios')
    return { ok: true, message: 'Usuário criado. Informe a senha inicial ao colaborador.' }
  } catch (e) {
    return toError(e)
  }
}

const updateUserSchema = z.object({
  id: z.string().uuid(),
  full_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().max(20).optional(),
  role: roleEnum,
  active: z.enum(['true', 'false']).transform((v) => v === 'true'),
  max_discount_pct: z.coerce.number().min(0).max(100),
  allow_negative_stock: z.enum(['true', 'false']).transform((v) => v === 'true'),
})

export async function updateUser(fd: FormData): Promise<ActionResult> {
  try {
    const me = await assertRoles(['admin'])
    const parsed = updateUserSchema.safeParse(Object.fromEntries(fd))
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const v = parsed.data
    if (v.id === me.id && (!v.active || v.role !== 'admin')) {
      return { ok: false, error: 'Você não pode remover seu próprio acesso de administrador.' }
    }
    const admin = createAdminClient()
    const { error } = await admin
      .from('profiles')
      .update({
        full_name: v.full_name,
        phone: v.phone || null,
        role: v.role,
        active: v.active,
        max_discount_pct: v.max_discount_pct,
        allow_negative_stock: v.allow_negative_stock,
      })
      .eq('id', v.id)
    if (error) return toError(error)
    if (!v.active) await admin.auth.admin.signOut(v.id).catch(() => null)
    await audit(me.id, 'alterar_usuario', 'profiles', v.id, { role: v.role, active: v.active, max_discount_pct: v.max_discount_pct })
    revalidatePath('/configuracoes/usuarios')
    return { ok: true, message: 'Usuário atualizado.' }
  } catch (e) {
    return toError(e)
  }
}

export async function resetUserPassword(userId: string, password: string): Promise<ActionResult> {
  try {
    const me = await assertRoles(['admin'])
    if (password.length < 8) return { ok: false, error: 'A senha deve ter ao menos 8 caracteres.' }
    const { error } = await createAdminClient().auth.admin.updateUserById(userId, { password })
    if (error) return { ok: false, error: 'Não foi possível redefinir a senha.' }
    await audit(me.id, 'redefinir_senha', 'profiles', userId)
    return { ok: true, message: 'Senha redefinida.' }
  } catch (e) {
    return toError(e)
  }
}

const opt = (max: number) => z.string().trim().max(max).optional().transform((v) => v || null)
const settingsSchema = z.object({
  company_name: z.string().trim().min(2).max(120),
  legal_name: opt(160),
  cnpj: opt(20),
  state_registration: opt(30),
  address: opt(200),
  city: opt(80),
  state: opt(2),
  phone: opt(20),
  email: z.string().trim().email('E-mail inválido.').or(z.literal('')).optional().transform((v) => v || null),
  website_pimentera: opt(120),
  website_mixx: opt(120),
  instagram_pimentera: opt(60),
  instagram_mixx: opt(60),
  order_footer_notes: opt(1000),
  default_freight: z.coerce.number().min(0),
})

export async function updateSettings(fd: FormData): Promise<ActionResult> {
  try {
    await assertRoles(['admin'])
    const raw = Object.fromEntries(fd)
    raw.default_freight = String(raw.default_freight ?? '0').replace(',', '.')
    const parsed = settingsSchema.safeParse(raw)
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const supabase = await createClient()
    const { error } = await supabase.from('company_settings').update(parsed.data).eq('id', 1)
    if (error) return toError(error)
    revalidatePath('/', 'layout')
    return { ok: true, message: 'Configurações salvas.' }
  } catch (e) {
    return toError(e)
  }
}

const LOGO_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml']

export async function uploadLogo(fd: FormData): Promise<ActionResult> {
  try {
    const me = await assertRoles(['admin'])
    const brand = fd.get('brand')
    const file = fd.get('file')
    if (brand !== 'pimentera' && brand !== 'mixx') return { ok: false, error: 'Marca inválida.' }
    if (!(file instanceof File) || file.size === 0) return { ok: false, error: 'Selecione um arquivo.' }
    if (!LOGO_TYPES.includes(file.type)) return { ok: false, error: 'Use PNG, JPG, WEBP ou SVG.' }
    if (file.size > 2 * 1024 * 1024) return { ok: false, error: 'Arquivo acima de 2 MB.' }
    const ext = file.name.split('.').pop()?.toLowerCase().replace(/[^a-z0-9]/g, '') || 'png'
    const path = `logos/${brand}-${Date.now()}.${ext}`
    const admin = createAdminClient()
    const { error } = await admin.storage.from('arquivos').upload(path, file, { contentType: file.type, upsert: false })
    if (error) return { ok: false, error: 'Falha no upload do arquivo.' }
    const column = brand === 'pimentera' ? 'logo_pimentera_path' : 'logo_mixx_path'
    const { data: prev } = await admin.from('company_settings').select(column).eq('id', 1).single()
    const { error: upErr } = await admin.from('company_settings').update({ [column]: path }).eq('id', 1)
    if (upErr) return toError(upErr)
    const oldPath = (prev as Record<string, string | null> | null)?.[column]
    if (oldPath) await admin.storage.from('arquivos').remove([oldPath])
    await audit(me.id, 'logo_atualizada', 'company_settings', '1', { brand })
    revalidatePath('/', 'layout')
    return { ok: true, message: 'Logo atualizada.' }
  } catch (e) {
    return toError(e)
  }
}

const termSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome.').max(60),
  days: z
    .string()
    .trim()
    .transform((v) => v.split(/[\s,;/]+/).filter(Boolean).map(Number))
    .refine((a) => a.length >= 1 && a.length <= 24 && a.every((n) => Number.isInteger(n) && n >= 0 && n <= 365), 'Prazos inválidos. Ex.: 0 ou 28,56'),
})

export async function addPaymentTerm(fd: FormData): Promise<ActionResult> {
  try {
    await assertRoles(['admin'])
    const parsed = termSchema.safeParse(Object.fromEntries(fd))
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const supabase = await createClient()
    const { error } = await supabase.from('payment_terms').insert({ name: parsed.data.name, days: parsed.data.days.sort((a, b) => a - b) })
    if (error) return { ok: false, error: error.code === '23505' ? 'Já existe uma condição com este nome.' : error.message }
    revalidatePath('/configuracoes')
    return { ok: true, message: 'Condição de pagamento adicionada.' }
  } catch (e) {
    return toError(e)
  }
}

export async function togglePaymentTerm(id: string, active: boolean): Promise<ActionResult> {
  try {
    await assertRoles(['admin'])
    const supabase = await createClient()
    const { error } = await supabase.from('payment_terms').update({ active }).eq('id', id)
    if (error) return toError(error)
    revalidatePath('/configuracoes')
    return { ok: true, message: active ? 'Condição ativada.' : 'Condição desativada.' }
  } catch (e) {
    return toError(e)
  }
}

export async function addPaymentMethod(fd: FormData): Promise<ActionResult> {
  try {
    await assertRoles(['admin'])
    const name = String(fd.get('name') ?? '').trim()
    if (name.length < 2 || name.length > 60) return { ok: false, error: 'Nome inválido.' }
    const supabase = await createClient()
    const { error } = await supabase.from('payment_methods').insert({ name })
    if (error) return { ok: false, error: error.code === '23505' ? 'Forma já cadastrada.' : error.message }
    revalidatePath('/configuracoes')
    return { ok: true, message: 'Forma de pagamento adicionada.' }
  } catch (e) {
    return toError(e)
  }
}

export async function togglePaymentMethod(id: string, active: boolean): Promise<ActionResult> {
  try {
    await assertRoles(['admin'])
    const supabase = await createClient()
    const { error } = await supabase.from('payment_methods').update({ active }).eq('id', id)
    if (error) return toError(error)
    revalidatePath('/configuracoes')
    return { ok: true }
  } catch (e) {
    return toError(e)
  }
}
