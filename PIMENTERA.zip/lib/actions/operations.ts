'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { requireProfile, toError, type ActionResult } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
import { createClient } from '@/lib/supabase/server'

const uuid = z.string().uuid()
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/)

function refreshOps(orderId?: string) {
  for (const p of ['/', '/expedicao', '/entregas', '/minhas-entregas', '/faturamento', '/financeiro', '/pedidos']) revalidatePath(p)
  if (orderId) revalidatePath(`/pedidos/${orderId}`)
}

// ---------- Deliveries ----------
export async function createDelivery(orderId: string, driverId: string | null, scheduled: string | null, notes: string): Promise<ActionResult<{ id: string }>> {
  try {
    await requireProfile()
    if (!uuid.safeParse(orderId).success || (driverId && !uuid.safeParse(driverId).success)) return { ok: false, error: 'Dados inválidos.' }
    if (scheduled && !isoDate.safeParse(scheduled).success) return { ok: false, error: 'Data inválida.' }
    const supabase = await createClient()
    const { data, error } = await supabase.rpc('create_delivery', { p_order: orderId, p_driver: driverId || null, p_date: scheduled || null, p_notes: notes.trim() || null })
    if (error) return toError(error)
    refreshOps(orderId)
    return { ok: true, data: { id: data as string }, message: 'Entrega criada.' }
  } catch (e) {
    return toError(e)
  }
}

export async function assignDelivery(deliveryId: string, driverId: string | null, scheduled: string | null): Promise<ActionResult> {
  try {
    await requireProfile()
    const supabase = await createClient()
    const { error } = await supabase.rpc('assign_delivery', { p_delivery: deliveryId, p_driver: driverId || null, p_date: scheduled || null })
    if (error) return toError(error)
    refreshOps()
    revalidatePath(`/entregas/${deliveryId}`)
    return { ok: true, message: 'Entrega atualizada.' }
  } catch (e) {
    return toError(e)
  }
}

const deliveryStatuses = ['em_rota', 'entregue', 'entrega_parcial', 'cliente_ausente', 'endereco_incorreto', 'recusada', 'reagendada'] as const

export async function updateDelivery(fd: FormData): Promise<ActionResult> {
  try {
    await requireProfile()
    const parsed = z
      .object({
        delivery_id: uuid,
        status: z.enum(deliveryStatuses),
        received_by: z.string().max(120).optional(),
        notes: z.string().max(1000).optional(),
        scheduled_date: z.string().optional(),
        items: z.string().optional(),
      })
      .safeParse(Object.fromEntries([...fd.entries()].filter(([, v]) => typeof v === 'string')))
    if (!parsed.success) return { ok: false, error: 'Dados inválidos.' }
    const supabase = await createClient()

    // RLS on deliveries guarantees the caller can see (and therefore act on) this delivery.
    const { data: del } = await supabase.from('deliveries').select('id, order_id').eq('id', parsed.data.delivery_id).maybeSingle()
    if (!del) return { ok: false, error: 'Entrega não encontrada.' }

    let proofPath: string | null = null
    const file = fd.get('proof')
    if (file instanceof File && file.size > 0) {
      if (!file.type.startsWith('image/')) return { ok: false, error: 'O comprovante deve ser uma imagem.' }
      if (file.size > 8 * 1024 * 1024) return { ok: false, error: 'Imagem acima de 8 MB.' }
      const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '')
      proofPath = `entregas/${del.id}/${Date.now()}.${ext}`
      const { error: upErr } = await createAdminClient().storage.from('arquivos').upload(proofPath, file, { contentType: file.type })
      if (upErr) return { ok: false, error: 'Falha ao enviar comprovante.' }
    }

    let items: unknown = []
    if (parsed.data.items) {
      try {
        items = JSON.parse(parsed.data.items)
      } catch {
        return { ok: false, error: 'Itens inválidos.' }
      }
    }
    const { error } = await supabase.rpc('update_delivery', {
      p: {
        delivery_id: del.id,
        status: parsed.data.status,
        received_by: parsed.data.received_by ?? '',
        notes: parsed.data.notes ?? '',
        scheduled_date: parsed.data.scheduled_date ?? '',
        proof_path: proofPath ?? '',
        items,
      },
    })
    if (error) {
      if (proofPath) await createAdminClient().storage.from('arquivos').remove([proofPath])
      return toError(error)
    }
    refreshOps(del.order_id)
    revalidatePath(`/entregas/${del.id}`)
    return { ok: true, message: 'Entrega atualizada.' }
  } catch (e) {
    return toError(e)
  }
}

// ---------- Invoicing ----------
const invoiceSchema = z.object({
  order_id: uuid,
  idempotency_key: uuid,
  doc_type: z.enum(['NF-e', 'NFC-e', 'Recibo', 'Outro']),
  number: z.string().trim().min(1, 'Informe o número do documento.').max(30),
  series: z.string().trim().max(10).optional(),
  access_key: z
    .string()
    .transform((v) => v.replace(/\D/g, ''))
    .refine((v) => v === '' || v.length === 44, 'A chave de acesso deve ter 44 dígitos.')
    .optional(),
  issue_date: isoDate,
  amount: z.number().positive('Valor faturado inválido.'),
  payment_method: z.string().max(60).optional(),
  notes: z.string().max(1000).optional(),
})

export async function registerInvoice(input: z.input<typeof invoiceSchema>): Promise<ActionResult> {
  try {
    await requireProfile()
    const parsed = invoiceSchema.safeParse(input)
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const supabase = await createClient()
    const { error } = await supabase.rpc('register_invoice', { p: parsed.data })
    if (error) return toError(error)
    refreshOps(parsed.data.order_id)
    return { ok: true, message: 'Faturamento registrado e contas a receber geradas.' }
  } catch (e) {
    return toError(e)
  }
}

export async function cancelInvoice(invoiceId: string, reason: string): Promise<ActionResult> {
  try {
    await requireProfile()
    const supabase = await createClient()
    const { error } = await supabase.rpc('cancel_invoice', { p_invoice: invoiceId, p_reason: reason })
    if (error) return toError(error)
    refreshOps()
    return { ok: true, message: 'Documento cancelado. O pedido voltou para aguardando faturamento.' }
  } catch (e) {
    return toError(e)
  }
}

// ---------- Payments ----------
const paymentSchema = z.object({
  installment_id: uuid,
  idempotency_key: uuid,
  amount: z.number().positive('Valor inválido.'),
  interest: z.number().min(0),
  discount: z.number().min(0),
  paid_at: isoDate,
  method: z.string().trim().min(1, 'Informe a forma de pagamento.').max(60),
  notes: z.string().max(500).optional(),
})

export async function registerPayment(input: z.input<typeof paymentSchema>): Promise<ActionResult> {
  try {
    await requireProfile()
    const parsed = paymentSchema.safeParse(input)
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const supabase = await createClient()
    const { error } = await supabase.rpc('register_payment', { p: parsed.data })
    if (error) return toError(error)
    refreshOps()
    return { ok: true, message: 'Pagamento registrado.' }
  } catch (e) {
    return toError(e)
  }
}

export async function proofUrl(deliveryId: string): Promise<ActionResult<{ url: string }>> {
  try {
    await requireProfile()
    const supabase = await createClient()
    const { data } = await supabase.from('deliveries').select('proof_path').eq('id', deliveryId).maybeSingle()
    if (!data?.proof_path) return { ok: false, error: 'Sem comprovante.' }
    const { data: s, error } = await createAdminClient().storage.from('arquivos').createSignedUrl(data.proof_path, 300)
    if (error || !s) return { ok: false, error: 'Não foi possível gerar o link.' }
    return { ok: true, data: { url: s.signedUrl } }
  } catch (e) {
    return toError(e)
  }
}
