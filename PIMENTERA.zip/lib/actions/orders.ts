'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { requireProfile, toError, type ActionResult } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'

const itemSchema = z.object({
  product_id: z.string().uuid(),
  quantity: z.number().int().positive().max(100000),
  unit_price: z.number().nonnegative().nullable(),
  discount_pct: z.number().min(0).max(100),
})

const orderSchema = z.object({
  id: z.string().uuid().nullable(),
  idempotency_key: z.string().uuid(),
  customer_id: z.string().uuid({ message: 'Selecione o cliente.' }),
  delivery_address: z.string().max(500).optional().default(''),
  payment_term_id: z.string().uuid().nullable(),
  freight: z.number().nonnegative(),
  tax_total: z.number().nonnegative(),
  expected_delivery: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable(),
  notes: z.string().max(2000).optional().default(''),
  submit: z.boolean(),
  items: z.array(itemSchema).min(1, 'Adicione ao menos um item.').max(200),
})

export type OrderPayload = z.input<typeof orderSchema>

export async function saveOrder(payload: OrderPayload): Promise<ActionResult<{ id: string; number: number }>> {
  try {
    await requireProfile()
    const parsed = orderSchema.safeParse(payload)
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }
    const ids = parsed.data.items.map((i) => i.product_id)
    if (new Set(ids).size !== ids.length) return { ok: false, error: 'Há produtos repetidos no pedido.' }
    const supabase = await createClient()
    const { data, error } = await supabase.rpc('save_order', { p: parsed.data })
    if (error) return toError(error)
    const r = data as { id: string; number: number; replay: boolean }
    revalidatePath('/pedidos')
    revalidatePath('/')
    return {
      ok: true,
      data: { id: r.id, number: r.number },
      message: r.replay ? 'Este pedido já havia sido registrado.' : parsed.data.submit ? 'Pedido enviado para aprovação.' : 'Rascunho salvo.',
    }
  } catch (e) {
    return toError(e)
  }
}

export async function changeOrderStatus(orderId: string, to: string, notes?: string): Promise<ActionResult<{ status: string }>> {
  try {
    await requireProfile()
    if (!z.string().uuid().safeParse(orderId).success) return { ok: false, error: 'Pedido inválido.' }
    const supabase = await createClient()
    const { data, error } = await supabase.rpc('change_order_status', { p_order: orderId, p_to: to, p_notes: notes?.trim() || null })
    if (error) return toError(error)
    revalidatePath(`/pedidos/${orderId}`)
    revalidatePath('/pedidos')
    revalidatePath('/expedicao')
    revalidatePath('/faturamento')
    revalidatePath('/')
    const final = data as string
    return {
      ok: true,
      data: { status: final },
      message: final === 'aguardando_estoque' ? 'Aprovado, mas sem estoque disponível: pedido aguardando estoque.' : 'Status atualizado.',
    }
  } catch (e) {
    return toError(e)
  }
}

const pickSchema = z.array(z.object({ id: z.string().uuid(), picked_qty: z.number().int().min(0), lot: z.string().max(60).optional() }))

export async function savePicking(orderId: string, items: z.input<typeof pickSchema>, conclude: boolean): Promise<ActionResult> {
  try {
    await requireProfile()
    const parsed = pickSchema.safeParse(items)
    if (!parsed.success) return { ok: false, error: 'Quantidades inválidas.' }
    const supabase = await createClient()
    const { error } = await supabase.rpc('save_picking', { p_order: orderId, p_items: parsed.data })
    if (error) return toError(error)
    if (conclude) {
      const { error: e2 } = await supabase.rpc('change_order_status', { p_order: orderId, p_to: 'separado', p_notes: 'Separação conferida' })
      if (e2) return toError(e2)
    }
    revalidatePath('/expedicao')
    revalidatePath(`/pedidos/${orderId}`)
    return { ok: true, message: conclude ? 'Separação conferida e baixa de estoque registrada.' : 'Quantidades salvas.' }
  } catch (e) {
    return toError(e)
  }
}

const templateSchema = z.object({
  id: z.string().uuid().nullable(),
  name: z.string().trim().min(3).max(120),
  description: z.string().max(500).optional(),
  items: z.array(z.object({ product_id: z.string().uuid(), quantity: z.number().int().positive().max(100000) })).min(1),
})

export async function saveTemplate(input: z.input<typeof templateSchema>): Promise<ActionResult<{ id: string }>> {
  try {
    const profile = await requireProfile()
    if (!['admin', 'gerente'].includes(profile.role)) return { ok: false, error: 'Somente administrador ou gerente pode salvar modelos.' }
    const parsed = templateSchema.safeParse(input)
    if (!parsed.success) return { ok: false, error: 'Modelo inválido: informe nome e itens.' }
    const supabase = await createClient()
    let id = parsed.data.id
    if (id) {
      const { error } = await supabase.from('order_templates').update({ name: parsed.data.name, description: parsed.data.description ?? null }).eq('id', id)
      if (error) return toError(error)
      await supabase.from('order_template_items').delete().eq('template_id', id)
    } else {
      const { data, error } = await supabase.from('order_templates').insert({ name: parsed.data.name, description: parsed.data.description ?? null }).select('id').single()
      if (error) return toError(error)
      id = data.id
    }
    const { error } = await supabase.from('order_template_items').insert(parsed.data.items.map((i) => ({ ...i, template_id: id })))
    if (error) return toError(error)
    revalidatePath('/pedidos/novo')
    return { ok: true, data: { id: id! }, message: 'Modelo salvo.' }
  } catch (e) {
    return toError(e)
  }
}
