'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { assertRoles, toError, type ActionResult } from '@/lib/auth'
import { audit } from '@/lib/audit'
import { isValidCNPJ, isValidCPF, onlyDigits } from '@/lib/format'
import { createClient } from '@/lib/supabase/server'

const opt = (max = 200) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((v) => (v ? v : null))

const customerSchema = z
  .object({
    person_type: z.enum(['PJ', 'PF']),
    legal_name: z.string().trim().min(2, 'Informe a razão social ou nome.').max(200),
    trade_name: opt(),
    document: opt(20).transform((v) => (v ? onlyDigits(v) : null)),
    state_registration: opt(30),
    ie_indicator: z.enum(['contribuinte', 'isento', 'nao_contribuinte', '']).transform((v) => v || null),
    buyer_name: opt(),
    phone: opt(20).transform((v) => (v ? onlyDigits(v) : null)),
    whatsapp: opt(20).transform((v) => (v ? onlyDigits(v) : null)),
    email: z
      .string()
      .trim()
      .max(200)
      .optional()
      .refine((v) => !v || z.string().email().safeParse(v).success, 'E-mail inválido.')
      .transform((v) => (v ? v.toLowerCase() : null)),
    cep: opt(9).transform((v) => (v ? onlyDigits(v) : null)),
    street: opt(),
    number: opt(20),
    complement: opt(),
    district: opt(),
    city: opt(),
    state: z
      .string()
      .trim()
      .toUpperCase()
      .optional()
      .refine((v) => !v || /^[A-Z]{2}$/.test(v), 'UF inválida.')
      .transform((v) => v || null),
    billing_address: opt(400),
    delivery_address: opt(400),
    receiver_name: opt(),
    receiver_phone: opt(20).transform((v) => (v ? onlyDigits(v) : null)),
    sales_rep_id: z.string().uuid().optional().or(z.literal('')).transform((v) => v || null),
    channel: z.enum(['supermercado', 'restaurante', 'bar', 'mercearia', 'distribuidor', 'outro']),
    payment_term_id: z.string().uuid().optional().or(z.literal('')).transform((v) => v || null),
    credit_limit: z
      .string()
      .optional()
      .transform((v) => (v ? Number(v.replace(',', '.')) : null))
      .refine((v) => v === null || (Number.isFinite(v) && v >= 0), 'Limite inválido.'),
    commercial_notes: opt(2000),
    status: z.enum(['prospect', 'ativo', 'inativo', 'bloqueado']),
    brands: z.array(z.enum(['pimentera', 'mixx'])),
  })
  .superRefine((v, ctx) => {
    if (!v.document) return
    const ok = v.person_type === 'PJ' ? isValidCNPJ(v.document) : isValidCPF(v.document)
    if (!ok) ctx.addIssue({ code: 'custom', path: ['document'], message: v.person_type === 'PJ' ? 'CNPJ inválido.' : 'CPF inválido.' })
  })

function readForm(fd: FormData) {
  const o: Record<string, unknown> = {}
  for (const [k, v] of fd.entries()) if (k !== 'brands' && !k.startsWith('$')) o[k] = typeof v === 'string' ? v : ''
  o.brands = fd.getAll('brands')
  return o
}

export type CustomerActionState = ActionResult<{ id: string }> & { fieldErrors?: Record<string, string>; duplicates?: { id: string; code: number; display_name: string; city: string | null; reason: string }[] }

export async function saveCustomer(id: string | null, _prev: CustomerActionState | undefined, fd: FormData): Promise<CustomerActionState> {
  try {
    const profile = await assertRoles(['admin', 'gerente', 'comercial', 'faturamento'])
    const parsed = customerSchema.safeParse(readForm(fd))
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {}
      for (const i of parsed.error.issues) fieldErrors[String(i.path[0])] ??= i.message
      return { ok: false, error: 'Revise os campos destacados.', fieldErrors }
    }
    const data = parsed.data
    if (profile.role === 'comercial') {
      data.sales_rep_id = profile.id
      if (data.credit_limit !== null && !id) data.credit_limit = null
    }
    const supabase = await createClient()

    const { data: dups } = await supabase.rpc('find_customer_duplicates', {
      p_document: data.document ?? '',
      p_name: data.trade_name || data.legal_name,
      p_exclude: id,
    })
    const docDup = (dups ?? []).filter((d: { reason: string }) => d.reason === 'documento')
    if (docDup.length) return { ok: false, error: 'Já existe cliente com este CPF/CNPJ.', duplicates: docDup }
    if ((dups ?? []).length && fd.get('$confirm_similar') !== '1') {
      return { ok: false, error: 'Encontramos cadastros com nome semelhante. Confira antes de salvar.', duplicates: dups }
    }

    if (id) {
      const { error } = await supabase.from('customers').update(data).eq('id', id)
      if (error) throw error
      await audit(profile.id, 'editar_cliente', 'customers', id, { nome: data.legal_name, status: data.status })
      revalidatePath(`/clientes/${id}`)
      return { ok: true, data: { id }, message: 'Cliente atualizado.' }
    }
    const { data: row, error } = await supabase
      .from('customers')
      .insert({ ...data, created_by: profile.id })
      .select('id')
      .single()
    if (error) throw error
    await audit(profile.id, 'criar_cliente', 'customers', row.id, { nome: data.legal_name })
    revalidatePath('/clientes')
    return { ok: true, data: { id: row.id }, message: 'Cliente cadastrado.' }
  } catch (e) {
    return toError(e)
  }
}

const visitSchema = z.object({
  customer_id: z.string().uuid(),
  visited_at: z.string().min(10),
  result: z.enum(['pedido', 'retorno', 'sem_interesse', 'prospeccao', 'outro']),
  notes: z.string().trim().max(2000).optional(),
  next_action: z.string().trim().max(500).optional(),
  next_action_date: z.string().optional(),
})

export async function saveVisit(_prev: ActionResult | undefined, fd: FormData): Promise<ActionResult> {
  try {
    const profile = await assertRoles(['admin', 'gerente', 'comercial'])
    const parsed = visitSchema.safeParse(Object.fromEntries(fd))
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
    const v = parsed.data
    const supabase = await createClient()
    const { error } = await supabase.from('visits').insert({
      customer_id: v.customer_id,
      rep_id: profile.id,
      visited_at: new Date(`${v.visited_at}:00-03:00`).toISOString(),
      result: v.result,
      notes: v.notes || null,
      next_action: v.next_action || null,
      next_action_date: v.next_action_date || null,
    })
    if (error) throw error
    revalidatePath('/visitas')
    revalidatePath(`/clientes/${v.customer_id}`)
    return { ok: true, message: 'Visita registrada.' }
  } catch (e) {
    return toError(e)
  }
}

export async function lookupCep(cep: string) {
  const d = onlyDigits(cep)
  if (d.length !== 8) return null
  try {
    const res = await fetch(`https://viacep.com.br/ws/${d}/json/`, { next: { revalidate: 86400 } })
    const j = await res.json()
    if (j.erro) return null
    return { street: j.logradouro as string, district: j.bairro as string, city: j.localidade as string, state: j.uf as string }
  } catch {
    return null
  }
}
