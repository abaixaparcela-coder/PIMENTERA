const TZ = 'America/Sao_Paulo'

const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })
const int = new Intl.NumberFormat('pt-BR')

export function money(v: number | string | null | undefined) {
  if (v === null || v === undefined || v === '') return '—'
  return brl.format(Number(v))
}

export function num(v: number | string | null | undefined) {
  if (v === null || v === undefined) return '—'
  return int.format(Number(v))
}

export function date(v: string | Date | null | undefined) {
  if (!v) return '—'
  // date-only strings (YYYY-MM-DD) must not shift timezone
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) {
    const [y, m, d] = v.split('-')
    return `${d}/${m}/${y}`
  }
  return new Intl.DateTimeFormat('pt-BR', { timeZone: TZ, day: '2-digit', month: '2-digit', year: 'numeric' }).format(
    new Date(v),
  )
}

export function dateTime(v: string | Date | null | undefined) {
  if (!v) return '—'
  return new Intl.DateTimeFormat('pt-BR', {
    timeZone: TZ,
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(v))
}

/** Today's date in Brasília as YYYY-MM-DD */
export function todayISO() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date())
}

export function addDaysISO(iso: string, days: number) {
  const d = new Date(`${iso}T12:00:00Z`)
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}

export const onlyDigits = (v: string | null | undefined) => (v ?? '').replace(/\D/g, '')

export function phone(v: string | null | undefined) {
  const d = onlyDigits(v)
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`
  return v || '—'
}

export function doc(v: string | null | undefined) {
  const d = onlyDigits(v)
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5')
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')
  return v || '—'
}

export function cep(v: string | null | undefined) {
  const d = onlyDigits(v)
  return d.length === 8 ? `${d.slice(0, 5)}-${d.slice(5)}` : v || ''
}

export function isValidCPF(value: string) {
  const c = onlyDigits(value)
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false
  let s = 0
  for (let i = 0; i < 9; i++) s += Number(c[i]) * (10 - i)
  let r = (s * 10) % 11
  if (r === 10) r = 0
  if (r !== Number(c[9])) return false
  s = 0
  for (let i = 0; i < 10; i++) s += Number(c[i]) * (11 - i)
  r = (s * 10) % 11
  if (r === 10) r = 0
  return r === Number(c[10])
}

export function isValidCNPJ(value: string) {
  const c = onlyDigits(value)
  if (c.length !== 14 || /^(\d)\1+$/.test(c)) return false
  const calc = (len: number) => {
    const weights = len === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    const sum = weights.reduce((acc, w, i) => acc + Number(c[i]) * w, 0)
    const r = sum % 11
    return r < 2 ? 0 : 11 - r
  }
  return calc(12) === Number(c[12]) && calc(13) === Number(c[13])
}

export const orderNumber = (n: number | string) => `PED-${String(n).padStart(6, '0')}`
export const deliveryNumber = (n: number | string) => `ENT-${String(n).padStart(6, '0')}`
export const customerCode = (n: number | string) => `CLI-${String(n).padStart(5, '0')}`

export function formatAddress(a: {
  street?: string | null
  number?: string | null
  complement?: string | null
  district?: string | null
  city?: string | null
  state?: string | null
  cep?: string | null
}) {
  const line1 = [a.street, a.number].filter(Boolean).join(', ')
  const parts = [line1, a.complement, a.district, [a.city, a.state].filter(Boolean).join('/'), a.cep ? `CEP ${cep(a.cep)}` : '']
  return parts.filter(Boolean).join(' — ')
}
