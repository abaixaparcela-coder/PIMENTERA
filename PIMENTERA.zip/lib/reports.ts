import 'server-only'
import { createClient } from '@/lib/supabase/server'
import { CHANNEL_LABEL, CUSTOMER_STATUS_LABEL, DELIVERY_STATUS_LABEL, ORDER_STATUS_LABEL, RECEIVABLE_STATUS_LABEL } from '@/lib/constants'
import { customerCode, date, deliveryNumber, doc, orderNumber, todayISO } from '@/lib/format'

export type ReportFilters = { de?: string; ate?: string; marca?: string }
export type Cell = string | number | null
export type Column = { key: string; label: string; kind?: 'money' | 'int' | 'text' }
export type Report = { columns: Column[]; rows: Record<string, Cell>[]; note?: string }

export const REPORTS: { key: string; label: string; description: string; period: boolean }[] = [
  { key: 'clientes', label: 'Cadastro de clientes', description: 'Todos os clientes com cidade, canal, vendedor e situação.', period: false },
  { key: 'pedidos', label: 'Pedidos por período', description: 'Pedidos criados no período, com status e valores.', period: true },
  { key: 'vendas_produto', label: 'Vendas por produto', description: 'Quantidade e valor vendido por produto (pedidos aprovados em diante).', period: true },
  { key: 'vendas_marca', label: 'Vendas por marca', description: 'Totais vendidos por marca (Pimentera / Mixx).', period: true },
  { key: 'vendas_representante', label: 'Vendas por representante', description: 'Pedidos e valor por representante.', period: true },
  { key: 'sem_movimento', label: 'Produtos sem movimentação', description: 'Produtos ativos sem venda no período.', period: true },
  { key: 'estoque', label: 'Estoque atual', description: 'Físico, reservado, disponível e mínimo por produto.', period: false },
  { key: 'movimentacoes', label: 'Histórico de estoque', description: 'Movimentações no período.', period: true },
  { key: 'faturamento', label: 'Faturamento por período', description: 'Documentos registrados por data de emissão.', period: true },
  { key: 'receber', label: 'Contas a receber / inadimplência', description: 'Parcelas em aberto, com indicação de vencidas.', period: false },
  { key: 'recebimentos', label: 'Recebimentos por período', description: 'Pagamentos registrados por data.', period: true },
  { key: 'entregas', label: 'Entregas', description: 'Entregas criadas no período e seus resultados.', period: true },
  { key: 'cancelamentos', label: 'Cancelamentos', description: 'Pedidos cancelados com motivo e responsável.', period: true },
]

const SOLD = ['aprovado', 'aguardando_estoque', 'em_separacao', 'separado', 'aguardando_faturamento', 'faturado', 'pronto_expedicao', 'em_rota', 'entregue', 'entrega_parcial', 'entrega_nao_realizada']

function range(f: ReportFilters) {
  const de = f.de || `${todayISO().slice(0, 8)}01`
  const ate = f.ate || todayISO()
  return { de, ate, from: `${de}T00:00:00-03:00`, to: `${ate}T23:59:59.999-03:00` }
}

export async function runReport(key: string, f: ReportFilters): Promise<Report | null> {
  const supabase = await createClient()
  const r = range(f)

  switch (key) {
    case 'clientes': {
      const { data } = await supabase
        .from('customers')
        .select('code, trade_name, legal_name, document, city, state, channel, status, phone, rep:profiles!customers_sales_rep_id_fkey(full_name), created_at')
        .order('trade_name')
      return {
        columns: [
          { key: 'code', label: 'Código' },
          { key: 'name', label: 'Nome fantasia' },
          { key: 'legal', label: 'Razão social' },
          { key: 'doc', label: 'CPF/CNPJ' },
          { key: 'city', label: 'Cidade/UF' },
          { key: 'channel', label: 'Canal' },
          { key: 'rep', label: 'Vendedor' },
          { key: 'status', label: 'Situação' },
          { key: 'created', label: 'Cadastro' },
        ],
        rows: (data ?? []).map((c) => ({
          code: customerCode(c.code),
          name: c.trade_name,
          legal: c.legal_name,
          doc: doc(c.document),
          city: [c.city, c.state].filter(Boolean).join('/'),
          channel: CHANNEL_LABEL[c.channel] ?? c.channel,
          rep: (c.rep as unknown as { full_name: string } | null)?.full_name ?? '',
          status: CUSTOMER_STATUS_LABEL[c.status] ?? c.status,
          created: date(c.created_at),
        })),
      }
    }
    case 'pedidos':
    case 'cancelamentos': {
      let q = supabase
        .from('orders')
        .select('number, status, total, created_at, customer_snapshot, cancel_reason, cancelled_at, rep:profiles!orders_rep_id_fkey(full_name), canceller:profiles!orders_cancelled_by_fkey(full_name)')
        .order('number')
      if (key === 'cancelamentos') q = q.eq('status', 'cancelado').gte('cancelled_at', r.from).lte('cancelled_at', r.to)
      else q = q.gte('created_at', r.from).lte('created_at', r.to)
      const { data } = await q
      const rows = (data ?? []).map((o) => {
        const c = (o.customer_snapshot ?? {}) as { trade_name?: string; legal_name?: string }
        return {
          number: orderNumber(o.number),
          date: date(key === 'cancelamentos' ? o.cancelled_at : o.created_at),
          customer: c.trade_name || c.legal_name || '',
          rep: (o.rep as unknown as { full_name: string } | null)?.full_name ?? '',
          status: ORDER_STATUS_LABEL[o.status] ?? o.status,
          total: Number(o.total),
          reason: o.cancel_reason ?? '',
          by: (o.canceller as unknown as { full_name: string } | null)?.full_name ?? '',
        }
      })
      const columns: Column[] = [
        { key: 'number', label: 'Pedido' },
        { key: 'date', label: key === 'cancelamentos' ? 'Cancelado em' : 'Criado em' },
        { key: 'customer', label: 'Cliente' },
        { key: 'rep', label: 'Representante' },
        { key: 'status', label: 'Status' },
        { key: 'total', label: 'Total', kind: 'money' },
      ]
      if (key === 'cancelamentos') columns.push({ key: 'reason', label: 'Motivo' }, { key: 'by', label: 'Responsável' })
      return { columns, rows }
    }
    case 'vendas_produto':
    case 'vendas_marca':
    case 'sem_movimento': {
      let q = supabase
        .from('order_items')
        .select('product_id, sku, product_name, brand_code, quantity, line_total, order:orders!inner(status, created_at)')
        .in('order.status', SOLD)
        .gte('order.created_at', r.from)
        .lte('order.created_at', r.to)
      if (f.marca) q = q.eq('brand_code', f.marca)
      const { data } = await q
      if (key === 'sem_movimento') {
        const sold = new Set((data ?? []).map((i) => i.product_id))
        let pq = supabase.from('products').select('id, sku, name, stock_physical, brand:brands(code, name)').eq('active', true).order('name')
        const { data: products } = await pq
        void pq
        return {
          columns: [
            { key: 'sku', label: 'SKU' },
            { key: 'name', label: 'Produto' },
            { key: 'brand', label: 'Marca' },
            { key: 'stock', label: 'Estoque físico', kind: 'int' },
          ],
          rows: (products ?? [])
            .filter((p) => !sold.has(p.id))
            .filter((p) => !f.marca || (p.brand as unknown as { code: string } | null)?.code === f.marca)
            .map((p) => ({ sku: p.sku, name: p.name, brand: (p.brand as unknown as { name: string } | null)?.name ?? '', stock: p.stock_physical })),
        }
      }
      const groups = new Map<string, Record<string, Cell>>()
      for (const i of data ?? []) {
        const k = key === 'vendas_marca' ? i.brand_code : i.sku
        const g = groups.get(k) ?? (key === 'vendas_marca' ? { brand: k === 'pimentera' ? 'Pimentera' : 'Mixx', qty: 0, total: 0 } : { sku: i.sku, name: i.product_name, brand: i.brand_code === 'pimentera' ? 'Pimentera' : 'Mixx', qty: 0, total: 0 })
        g.qty = Number(g.qty) + i.quantity
        g.total = Number(g.total) + Number(i.line_total)
        groups.set(k, g)
      }
      const rows = [...groups.values()].sort((a, b) => Number(b.qty) - Number(a.qty))
      return {
        columns:
          key === 'vendas_marca'
            ? [
                { key: 'brand', label: 'Marca' },
                { key: 'qty', label: 'Unidades', kind: 'int' },
                { key: 'total', label: 'Valor vendido', kind: 'money' },
              ]
            : [
                { key: 'sku', label: 'SKU' },
                { key: 'name', label: 'Produto' },
                { key: 'brand', label: 'Marca' },
                { key: 'qty', label: 'Unidades', kind: 'int' },
                { key: 'total', label: 'Valor vendido', kind: 'money' },
              ],
        rows,
        note: 'Considera pedidos aprovados ou em etapas posteriores (exclui rascunhos, aguardando aprovação e cancelados). Valores de linha já com desconto, sem frete.',
      }
    }
    case 'vendas_representante': {
      const { data } = await supabase
        .from('orders')
        .select('total, rep:profiles!orders_rep_id_fkey(full_name)')
        .in('status', SOLD)
        .gte('created_at', r.from)
        .lte('created_at', r.to)
      const g = new Map<string, { rep: string; orders: number; total: number }>()
      for (const o of data ?? []) {
        const name = (o.rep as unknown as { full_name: string } | null)?.full_name ?? '—'
        const cur = g.get(name) ?? { rep: name, orders: 0, total: 0 }
        cur.orders += 1
        cur.total += Number(o.total)
        g.set(name, cur)
      }
      return {
        columns: [
          { key: 'rep', label: 'Representante' },
          { key: 'orders', label: 'Pedidos', kind: 'int' },
          { key: 'total', label: 'Valor vendido', kind: 'money' },
          { key: 'ticket', label: 'Ticket médio', kind: 'money' },
        ],
        rows: [...g.values()].sort((a, b) => b.total - a.total).map((x) => ({ ...x, ticket: x.orders ? x.total / x.orders : 0 })),
        note: 'Pedidos aprovados ou em etapas posteriores, valor total do pedido.',
      }
    }
    case 'estoque': {
      let q = supabase.from('products').select('sku, name, stock_physical, stock_reserved, stock_min, lot, expiry_date, active, brand:brands!inner(code, name)').order('name')
      if (f.marca) q = q.eq('brand.code', f.marca)
      const { data } = await q
      return {
        columns: [
          { key: 'sku', label: 'SKU' },
          { key: 'name', label: 'Produto' },
          { key: 'brand', label: 'Marca' },
          { key: 'physical', label: 'Físico', kind: 'int' },
          { key: 'reserved', label: 'Reservado', kind: 'int' },
          { key: 'available', label: 'Disponível', kind: 'int' },
          { key: 'min', label: 'Mínimo', kind: 'int' },
          { key: 'lot', label: 'Lote' },
          { key: 'expiry', label: 'Validade' },
        ],
        rows: (data ?? []).map((p) => ({
          sku: p.sku,
          name: p.name + (p.active ? '' : ' (inativo)'),
          brand: (p.brand as unknown as { name: string }).name,
          physical: p.stock_physical,
          reserved: p.stock_reserved,
          available: p.stock_physical - p.stock_reserved,
          min: p.stock_min,
          lot: p.lot ?? '',
          expiry: p.expiry_date ? date(p.expiry_date) : '',
        })),
      }
    }
    case 'movimentacoes': {
      const { data } = await supabase
        .from('inventory_movements')
        .select('created_at, type, quantity, physical_after, reserved_after, lot, reason, product:products(sku, name), user:profiles(full_name), order:orders(number)')
        .gte('created_at', r.from)
        .lte('created_at', r.to)
        .order('created_at', { ascending: false })
        .limit(2000)
      return {
        columns: [
          { key: 'date', label: 'Data' },
          { key: 'sku', label: 'SKU' },
          { key: 'product', label: 'Produto' },
          { key: 'type', label: 'Tipo' },
          { key: 'qty', label: 'Qtd.', kind: 'int' },
          { key: 'physical', label: 'Físico após', kind: 'int' },
          { key: 'reserved', label: 'Reservado após', kind: 'int' },
          { key: 'order', label: 'Pedido' },
          { key: 'reason', label: 'Justificativa' },
          { key: 'user', label: 'Usuário' },
        ],
        rows: (data ?? []).map((m) => {
          const p = m.product as unknown as { sku: string; name: string } | null
          const o = m.order as unknown as { number: number } | null
          return {
            date: date(m.created_at),
            sku: p?.sku ?? '',
            product: p?.name ?? '',
            type: m.type,
            qty: m.quantity,
            physical: m.physical_after,
            reserved: m.reserved_after,
            order: o ? orderNumber(o.number) : '',
            reason: m.reason ?? '',
            user: (m.user as unknown as { full_name: string } | null)?.full_name ?? '',
          }
        }),
      }
    }
    case 'faturamento': {
      const { data } = await supabase
        .from('invoices')
        .select('doc_type, number, series, issue_date, amount, status, order:orders(number, customer_snapshot)')
        .gte('issue_date', r.de)
        .lte('issue_date', r.ate)
        .order('issue_date')
      return {
        columns: [
          { key: 'date', label: 'Emissão' },
          { key: 'doc', label: 'Documento' },
          { key: 'order', label: 'Pedido' },
          { key: 'customer', label: 'Cliente' },
          { key: 'status', label: 'Status' },
          { key: 'amount', label: 'Valor', kind: 'money' },
        ],
        rows: (data ?? []).map((i) => {
          const o = i.order as unknown as { number: number; customer_snapshot: { trade_name?: string; legal_name?: string } } | null
          return {
            date: date(i.issue_date),
            doc: `${i.doc_type} ${i.number}${i.series ? '/' + i.series : ''}`,
            order: o ? orderNumber(o.number) : '',
            customer: o?.customer_snapshot?.trade_name || o?.customer_snapshot?.legal_name || '',
            status: i.status === 'emitida' ? 'Emitido' : 'Cancelado',
            amount: i.status === 'emitida' ? Number(i.amount) : 0,
          }
        }),
        note: 'Documentos cancelados aparecem com valor zero.',
      }
    }
    case 'receber': {
      const today = todayISO()
      const { data } = await supabase
        .from('receivable_installments')
        .select('number, due_date, amount, interest, discount, paid_amount, status, receivable:receivables(customer:customers(trade_name, legal_name), order:orders(number))')
        .in('status', ['pendente', 'parcial'])
        .order('due_date')
      return {
        columns: [
          { key: 'due', label: 'Vencimento' },
          { key: 'customer', label: 'Cliente' },
          { key: 'order', label: 'Pedido' },
          { key: 'inst', label: 'Parcela', kind: 'int' },
          { key: 'amount', label: 'Valor', kind: 'money' },
          { key: 'paid', label: 'Recebido', kind: 'money' },
          { key: 'balance', label: 'Saldo', kind: 'money' },
          { key: 'days', label: 'Dias em atraso', kind: 'int' },
          { key: 'status', label: 'Status' },
        ],
        rows: (data ?? []).map((i) => {
          const rc = i.receivable as unknown as { customer: { trade_name: string | null; legal_name: string } | null; order: { number: number } | null } | null
          const overdue = i.due_date < today
          return {
            due: date(i.due_date),
            customer: rc?.customer?.trade_name || rc?.customer?.legal_name || '',
            order: rc?.order ? orderNumber(rc.order.number) : '',
            inst: i.number,
            amount: Number(i.amount),
            paid: Number(i.paid_amount),
            balance: Math.max(0, Number(i.amount) + Number(i.interest) - Number(i.discount) - Number(i.paid_amount)),
            days: overdue ? Math.round((Date.parse(today) - Date.parse(i.due_date)) / 86400000) : 0,
            status: overdue ? 'Vencido' : (RECEIVABLE_STATUS_LABEL[i.status] ?? i.status),
          }
        }),
      }
    }
    case 'recebimentos': {
      const { data } = await supabase
        .from('payments')
        .select('paid_at, amount, interest, discount, method, receivable:receivables(customer:customers(trade_name, legal_name), order:orders(number))')
        .gte('paid_at', r.de)
        .lte('paid_at', r.ate)
        .order('paid_at')
      return {
        columns: [
          { key: 'date', label: 'Data' },
          { key: 'customer', label: 'Cliente' },
          { key: 'order', label: 'Pedido' },
          { key: 'method', label: 'Forma' },
          { key: 'interest', label: 'Juros', kind: 'money' },
          { key: 'discount', label: 'Desconto', kind: 'money' },
          { key: 'amount', label: 'Valor recebido', kind: 'money' },
        ],
        rows: (data ?? []).map((p) => {
          const rc = p.receivable as unknown as { customer: { trade_name: string | null; legal_name: string } | null; order: { number: number } | null } | null
          return {
            date: date(p.paid_at),
            customer: rc?.customer?.trade_name || rc?.customer?.legal_name || '',
            order: rc?.order ? orderNumber(rc.order.number) : '',
            method: p.method,
            interest: Number(p.interest),
            discount: Number(p.discount),
            amount: Number(p.amount),
          }
        }),
      }
    }
    case 'entregas': {
      const { data } = await supabase
        .from('deliveries')
        .select('number, status, customer_name, scheduled_date, completed_at, received_by, created_at, driver:profiles!deliveries_driver_id_fkey(full_name), order:orders(number)')
        .gte('created_at', r.from)
        .lte('created_at', r.to)
        .order('number')
      return {
        columns: [
          { key: 'number', label: 'Entrega' },
          { key: 'order', label: 'Pedido' },
          { key: 'customer', label: 'Cliente' },
          { key: 'driver', label: 'Entregador' },
          { key: 'scheduled', label: 'Prevista' },
          { key: 'completed', label: 'Concluída' },
          { key: 'received', label: 'Recebido por' },
          { key: 'status', label: 'Status' },
        ],
        rows: (data ?? []).map((d) => ({
          number: deliveryNumber(d.number),
          order: (d.order as unknown as { number: number } | null) ? orderNumber((d.order as unknown as { number: number }).number) : '',
          customer: d.customer_name,
          driver: (d.driver as unknown as { full_name: string } | null)?.full_name ?? '',
          scheduled: d.scheduled_date ? date(d.scheduled_date) : '',
          completed: d.completed_at ? date(d.completed_at) : '',
          received: d.received_by ?? '',
          status: DELIVERY_STATUS_LABEL[d.status] ?? d.status,
        })),
      }
    }
  }
  return null
}

export function toCSV(report: Report) {
  const esc = (v: Cell) => {
    if (v === null || v === undefined) return ''
    const s = typeof v === 'number' ? v.toFixed(Number.isInteger(v) ? 0 : 2).replace('.', ',') : String(v)
    return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }
  const lines = [report.columns.map((c) => esc(c.label)).join(';'), ...report.rows.map((r) => report.columns.map((c) => esc(r[c.key])).join(';'))]
  return '\uFEFF' + lines.join('\r\n')
}

export { range as reportRange }
