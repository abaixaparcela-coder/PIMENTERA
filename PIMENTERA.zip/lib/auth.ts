import 'server-only'
import { cache } from 'react'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { MODULE_ROLES, type ModuleKey, type Role } from '@/lib/constants'

export type Profile = {
  id: string
  full_name: string
  email: string
  phone: string | null
  role: Role
  active: boolean
  max_discount_pct: number
  allow_negative_stock: boolean
}

export const getProfile = cache(async (): Promise<Profile | null> => {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return null
  const { data } = await supabase
    .from('profiles')
    .select('id, full_name, email, phone, role, active, max_discount_pct, allow_negative_stock')
    .eq('id', user.id)
    .single()
  return (data as Profile) ?? null
})

export async function requireProfile() {
  const profile = await getProfile()
  if (!profile) redirect('/login')
  if (!profile.active) redirect('/login?inativo=1')
  return profile
}

export function canAccess(role: Role, module: ModuleKey) {
  return MODULE_ROLES[module].includes(role)
}

export async function requireModule(module: ModuleKey) {
  const profile = await requireProfile()
  if (!canAccess(profile.role, module)) redirect('/sem-permissao')
  return profile
}

/** For server actions: returns profile or throws a user-facing error. */
export async function assertRoles(roles: Role[]) {
  const profile = await getProfile()
  if (!profile || !profile.active) throw new Error('Sessão expirada. Entre novamente.')
  if (!roles.includes(profile.role)) throw new Error('Sem permissão para esta operação.')
  return profile
}

export type ActionResult<T = undefined> = { ok: true; data?: T; message?: string } | { ok: false; error: string }

export function toError(err: unknown): { ok: false; error: string } {
  const raw = err instanceof Error ? err.message : typeof err === 'object' && err && 'message' in err ? String((err as { message: string }).message) : 'Erro inesperado.'
  return { ok: false, error: raw.replace(/^ERROR:\s*/, '') }
}
