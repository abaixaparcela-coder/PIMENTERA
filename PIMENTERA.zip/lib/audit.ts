import 'server-only'
import { createAdminClient } from '@/lib/supabase/admin'

/** Writes an audit row with the service role (audit_logs is not writable by end users). */
export async function audit(userId: string, action: string, entity: string, entityId: string | null, details?: Record<string, unknown>) {
  const admin = createAdminClient()
  const { error } = await admin.from('audit_logs').insert({ user_id: userId, action, entity, entity_id: entityId, details: details ?? null })
  if (error) console.error('[audit] failed', action, error.message)
}
