export type Role = 'admin' | 'comercial' | 'estoque' | 'faturamento' | 'entregador' | 'gerente'

export const ROLE_LABEL: Record<Role, string> = {
  admin: 'Administrador',
  comercial: 'Comercial / Representante',
  estoque: 'Estoque / Expedição',
  faturamento: 'Faturamento / Financeiro',
  entregador: 'Entregador',
  gerente: 'Gerente',
}

export type ModuleKey =
  | 'dashboard'
  | 'clientes'
  | 'visitas'
  | 'produtos'
  | 'pedidos'
  | 'estoque'
  | 'expedicao'
  | 'faturamento'
  | 'financeiro'
  | 'entregas'
  | 'minhas-entregas'
  | 'relatorios'
  | 'configuracoes'
  | 'auditoria'

// Server-enforced module access per role (pages call requireModule; DB enforces again via RLS/RPC).
export const MODULE_ROLES: Record<ModuleKey, Role[]> = {
  dashboard: ['admin', 'gerente', 'comercial', 'estoque', 'faturamento'],
  clientes: ['admin', 'gerente', 'comercial', 'faturamento'],
  visitas: ['admin', 'gerente', 'comercial'],
  produtos: ['admin', 'gerente', 'comercial', 'estoque', 'faturamento'],
  pedidos: ['admin', 'gerente', 'comercial', 'estoque', 'faturamento'],
  estoque: ['admin', 'gerente', 'estoque'],
  expedicao: ['admin', 'gerente', 'estoque'],
  faturamento: ['admin', 'gerente', 'faturamento'],
  financeiro: ['admin', 'gerente', 'faturamento'],
  entregas: ['admin', 'gerente', 'estoque'],
  'minhas-entregas': ['entregador', 'admin'],
  relatorios: ['admin', 'gerente', 'faturamento'],
  configuracoes: ['admin'],
  auditoria: ['admin'],
}

export const ORDER_STATUS_LABEL: Record<string, string> = {
  rascunho: 'Rascunho',
  aguardando_aprovacao: 'Aguardando aprovação',
  aprovado: 'Aprovado',
  aguardando_estoque: 'Aguardando estoque',
  em_separacao: 'Em separação',
  separado: 'Separado e conferido',
  aguardando_faturamento: 'Aguardando faturamento',
  faturado: 'Faturado',
  pronto_expedicao: 'Pronto para expedição',
  em_rota: 'Em rota de entrega',
  entregue: 'Entregue',
  entrega_parcial: 'Entrega parcial',
  entrega_nao_realizada: 'Entrega não realizada',
  cancelado: 'Cancelado',
}

export const ORDER_STATUSES = Object.keys(ORDER_STATUS_LABEL)

export const DELIVERY_STATUS_LABEL: Record<string, string> = {
  aguardando_expedicao: 'Aguardando expedição',
  pronta: 'Pronta para entrega',
  em_rota: 'Em rota',
  entregue: 'Entregue',
  entrega_parcial: 'Entrega parcial',
  cliente_ausente: 'Cliente ausente',
  endereco_incorreto: 'Endereço incorreto',
  recusada: 'Recusada',
  reagendada: 'Reagendada',
}

export const CUSTOMER_STATUS_LABEL: Record<string, string> = {
  prospect: 'Prospect',
  ativo: 'Ativo',
  inativo: 'Inativo',
  bloqueado: 'Bloqueado',
}

export const CHANNEL_LABEL: Record<string, string> = {
  supermercado: 'Supermercado',
  restaurante: 'Restaurante',
  bar: 'Bar',
  mercearia: 'Mercearia',
  distribuidor: 'Distribuidor',
  outro: 'Outro',
}

export const VISIT_RESULT_LABEL: Record<string, string> = {
  pedido: 'Pedido realizado',
  retorno: 'Retornar depois',
  prospeccao: 'Prospecção / apresentação',
  sem_interesse: 'Sem interesse',
  outro: 'Outro',
}

export const RECEIVABLE_STATUS_LABEL: Record<string, string> = {
  pendente: 'Pendente',
  parcial: 'Parcial',
  pago: 'Pago',
  vencido: 'Vencido',
  cancelado: 'Cancelado',
}

export const BRAND_LABEL: Record<string, string> = { pimentera: 'Pimentera', mixx: 'Mixx' }

export const UF = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
  'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO',
]

export type StatusTone = 'neutral' | 'info' | 'warn' | 'ok' | 'bad'

export function orderTone(s: string): StatusTone {
  if (['cancelado', 'entrega_nao_realizada'].includes(s)) return 'bad'
  if (['entregue'].includes(s)) return 'ok'
  if (['aguardando_aprovacao', 'aguardando_estoque', 'aguardando_faturamento', 'entrega_parcial'].includes(s)) return 'warn'
  if (s === 'rascunho') return 'neutral'
  return 'info'
}

export function deliveryTone(s: string): StatusTone {
  if (s === 'entregue') return 'ok'
  if (['cliente_ausente', 'endereco_incorreto', 'recusada'].includes(s)) return 'bad'
  if (['entrega_parcial', 'reagendada', 'aguardando_expedicao'].includes(s)) return 'warn'
  return 'info'
}

export function receivableTone(s: string): StatusTone {
  if (s === 'pago') return 'ok'
  if (s === 'vencido' || s === 'cancelado') return 'bad'
  if (s === 'parcial') return 'warn'
  return 'neutral'
}
